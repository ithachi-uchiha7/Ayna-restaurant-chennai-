import { z } from "zod";

const name = z.string().trim().min(2, "Please enter your full name").max(160);
const email = z.email("Enter a valid e-mail address").trim().toLowerCase().max(320);
const phone = z
  .string()
  .trim()
  .min(8, "Enter a reachable phone number")
  .max(32)
  .regex(/^[+()\-\s\d]{8,32}$/, "Phone number can only contain digits, spaces and + ( ) -");
const isoDate = z
  .string()
  .regex(/^\d{4}-\d{2}-\d{2}$/, "Use the date picker (YYYY-MM-DD)");
const time = z.string().regex(/^\d{2}:\d{2}$/, "Use the time picker (HH:MM)");

export const registerSchema = z.object({
  fullName: name,
  email,
  phone: phone.optional().or(z.literal("")),
  password: z
    .string()
    .min(10, "Use at least 10 characters")
    .max(200)
    .regex(/[a-z]/, "Include a lowercase letter")
    .regex(/[A-Z]/, "Include an uppercase letter")
    .regex(/\d/, "Include a number"),
  marketingOptIn: z.boolean().optional().default(false),
});

export const loginSchema = z.object({
  email,
  password: z.string().min(1, "Enter your password").max(200),
});

export const forgotPasswordSchema = z.object({ email });

export const resetPasswordSchema = z.object({
  token: z.string().min(20).max(120),
  password: z
    .string()
    .min(10, "Use at least 10 characters")
    .max(200)
    .regex(/[a-z]/, "Include a lowercase letter")
    .regex(/[A-Z]/, "Include an uppercase letter")
    .regex(/\d/, "Include a number"),
});

export const profileSchema = z.object({
  fullName: name,
  phone: phone.optional().or(z.literal("")),
  dietaryPreference: z.enum(["none", "vegetarian", "vegan", "gluten-free", "halal", "jain", "other"]).optional(),
  marketingOptIn: z.boolean().optional().default(false),
  notes: z.string().max(500).optional().or(z.literal("")),
});

export const reservationSchema = z.object({
  fullName: name,
  email,
  phone,
  date: isoDate,
  time,
  guests: z.coerce.number().int().min(1, "At least 1 guest").max(40, "For 40+ guests use the Events form"),
  occasion: z.enum(["none", "birthday", "anniversary", "business", "family", "date", "celebration", "other"]).optional(),
  seating: z.enum(["no-preference", "indoor", "private-dining", "window", "booth"]).optional(),
  message: z.string().max(1000).optional().or(z.literal("")),
  items: z
    .array(z.object({ slug: z.string().min(1).max(120), qty: z.coerce.number().int().min(1).max(50) }))
    .max(40)
    .optional(),
  acknowledgeExternal: z.literal(true, {
    error: "Please acknowledge that this is an enquiry, not a confirmed booking.",
  }),
});

export const preOrderSchema = z.object({
  fullName: name,
  email,
  phone,
  serviceType: z.enum(["dine-in-preorder", "takeaway-enquiry"]).default("dine-in-preorder"),
  preferredDate: isoDate.optional().or(z.literal("")),
  preferredTime: time.optional().or(z.literal("")),
  guests: z.coerce.number().int().min(1).max(40).optional(),
  notes: z.string().max(1000).optional().or(z.literal("")),
  items: z
    .array(z.object({ slug: z.string().min(1).max(120), qty: z.coerce.number().int().min(1).max(50) }))
    .min(1, "Add at least one dish to your pre-order")
    .max(40),
});

export const contactSchema = z.object({
  fullName: name,
  email,
  phone: phone.optional().or(z.literal("")),
  topic: z.enum(["general", "reservation", "feedback", "private-dining", "press", "careers", "accessibility"]),
  message: z.string().trim().min(10, "Please add a little more detail").max(2000),
});

export const eventSchema = z.object({
  fullName: name,
  email,
  phone,
  eventType: z.enum(["birthday", "anniversary", "corporate-dinner", "family-gathering", "wedding-related", "other"]),
  preferredDate: isoDate.optional().or(z.literal("")),
  guests: z.coerce.number().int().min(2, "Minimum 2 guests").max(200, "Please call us for very large groups"),
  budget: z.enum(["unsure", "under-25k", "25k-50k", "50k-100k", "100k-plus"]).optional(),
  message: z.string().max(1500).optional().or(z.literal("")),
});

export const newsletterSchema = z.object({
  email,
  source: z.string().max(48).optional(),
});

export type FieldErrors = Record<string, string>;

export function zodErrors(error: z.ZodError): FieldErrors {
  const out: FieldErrors = {};
  for (const issue of error.issues) {
    const key = issue.path.join(".") || "form";
    if (!out[key]) out[key] = issue.message;
  }
  return out;
}
