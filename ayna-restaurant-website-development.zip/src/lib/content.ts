export type GalleryItem = {
  src: string;
  alt: string;
  caption: string;
  /** "ai" = AI-generated illustrative visual. "link" = real photos hosted elsewhere. */
  kind: "ai" | "link";
  href?: string;
  span?: "wide" | "tall" | "normal";
};

/**
 * Transparency: every image served from /images/* on this site is AI-GENERATED
 * illustrative artwork created for this project — it is NOT a photograph of Ayna
 * or of Hilton Chennai. Genuine photographs of the restaurant are linked out to
 * the platforms that host them (Tripadvisor has 91 candid guest photos).
 */
export const gallery: GalleryItem[] = [
  {
    src: "/images/hero-interior.jpg",
    alt: "AI-generated illustration of a luxurious Indian fine-dining room in deep green and gold",
    caption: "Dining room mood — AI-generated illustrative visual",
    kind: "ai",
    span: "wide",
  },
  {
    src: "/images/dish-dal-ayna.jpg",
    alt: "AI-generated illustration of creamy black dal in a brass bowl",
    caption: "Dal Ayna — AI-generated illustrative visual",
    kind: "ai",
  },
  {
    src: "/images/dish-biryani.jpg",
    alt: "AI-generated illustration of Hyderabadi lamb biryani in a copper handi",
    caption: "Kacche Gosht ki Biryani — AI-generated illustrative visual",
    kind: "ai",
  },
  {
    src: "/images/dish-kebab-platter.jpg",
    alt: "AI-generated illustration of an Indian tandoor kebab platter with smoke",
    caption: "Tandoor platter — AI-generated illustrative visual",
    kind: "ai",
  },
  {
    src: "/images/dish-seafood.jpg",
    alt: "AI-generated illustration of charred kasundi king prawns",
    caption: "Tandoori Kasundi Jheenga — AI-generated illustrative visual",
    kind: "ai",
  },
  {
    src: "/images/ambience-table.jpg",
    alt: "AI-generated illustration of a candle-lit fine dining table setting",
    caption: "Table setting — AI-generated illustrative visual",
    kind: "ai",
  },
  {
    src: "/images/private-dining.jpg",
    alt: "AI-generated illustration of an elegant private dining room",
    caption: "Private dining mood — AI-generated illustrative visual",
    kind: "ai",
    span: "tall",
  },
  {
    src: "/images/bar-wine.jpg",
    alt: "AI-generated illustration of a luxury hotel wine and cocktail bar",
    caption: "Bar & wine mood — AI-generated illustrative visual",
    kind: "ai",
  },
  {
    src: "/images/tandoor-chef.jpg",
    alt: "AI-generated illustration of skewers going into a glowing clay tandoor",
    caption: "The tandoor — AI-generated illustrative visual",
    kind: "ai",
    span: "wide",
  },
  {
    src: "/images/dish-dessert.jpg",
    alt: "AI-generated illustration of phirni in clay sakoras with rose petals",
    caption: "Sakora Phirni — AI-generated illustrative visual",
    kind: "ai",
  },
];

export const realPhotoSources = [
  {
    label: "Tripadvisor — 91 candid guest photos of Ayna",
    url: "https://www.tripadvisor.com/Restaurant_Review-g304556-d3588786-Reviews-or20-Ayna-Chennai_Madras_Chennai_District_Tamil_Nadu.html#photos",
  },
  {
    label: "Zomato — Ayna photo gallery (real diner photos)",
    url: "https://www.zomato.com/chennai/ayna-hilton-chennai-guindy/photos",
  },
  {
    label: "EazyDiner — restaurant photography (banner images)",
    url: "https://www.eazydiner.com/chennai/ayna-hilton-guindy-612366",
  },
  {
    label: "Justdial — 31 photos of Ayna (Hilton)",
    url: "https://www.justdial.com/Chennai/Ayna-Restaurant-hilton-Near-Olympia-Tech-Park-Guindy-Guindy/044PXX44-XX44-111229174953-Q4R1_BZDET/photos",
  },
];

export type Faq = { q: string; a: string; source?: string };

export const faqs: Faq[] = [
  {
    q: "Where exactly is Ayna?",
    a: "On the 3rd floor of Hilton Chennai, 124/1 Jawaharlal Nehru Salai (J.N. Salai), Guindy, Chennai 600032 — near Olympia Tech Park. Take the hotel lifts to the 3rd floor.",
    source: "Tripadvisor, Hilton.com, Zomato, Justdial",
  },
  {
    q: "What are the opening hours, and is Ayna open right now?",
    a: "Dinner is served 6:30 pm – 11:00 pm every day. Tripadvisor also lists lunch 12:30 pm – 3:00 pm; current Zomato and Swiggy listings advertise dinner only, so please confirm lunch by phone before you travel. The live open/closed badge on this site uses these hours in Indian Standard Time.",
  },
  {
    q: "How do I reserve a table?",
    a: "Use the official Google Dining reservation page — every 'Reserve a table' button on this site opens it in a new tab. Reservations are handled by that external service, not by this website. This site's own 'reservation enquiry' form only sends an enquiry to the restaurant team and is NOT a confirmed booking.",
  },
  {
    q: "Can I order Ayna food for delivery?",
    a: "Yes — Ayna's delivery is handled through its official Zomato listing. All 'Order online / Delivery' buttons on this site open that Zomato page. This website does not process or fulfil delivery orders and does not take payment for food.",
  },
  {
    q: "What cuisine is Ayna?",
    a: "Pan-Indian fine dining. Ayna was the first Hilton restaurant in India to offer pan-Indian cuisine, covering North, South, East and West India — Rajasthani, Bengali, Kashmiri, Goan, Awadhi, Hyderabadi, Chettinad, Malabar and Punjabi preparations — alongside a strong seafood section and desserts. Third-party listings summarise it as North Indian, Seafood and Desserts.",
    source: "IANS via Business Standard (2015); Zomato; Swiggy Dineout",
  },
  {
    q: "How much does a meal for two cost?",
    a: "Published guidance is ₹3,000 for two (Zomato and Swiggy), ₹3,100 (Justdial) and ₹3,500 for two (EazyDiner), excluding taxes and alcohol. Justdial lists a pint of beer at ₹500.",
  },
  {
    q: "Is there a dress code?",
    a: "No dress code is published for Ayna. As a hotel fine-dining restaurant, smart-casual is the safe choice; nothing on the official listings specifies a requirement.",
  },
  {
    q: "Is Ayna vegetarian friendly?",
    a: "Yes. Tripadvisor lists Ayna as vegetarian friendly with vegan options and gluten-free options. The menu includes a substantial vegetarian repertoire (Dal Ayna, Paneer Lazzat, Dilkush Kofta, Subz Makhana ki Seekh and more).",
  },
  {
    q: "Is there parking?",
    a: "Yes — Tripadvisor lists valet parking, validated parking and parking available at the Hilton Chennai property.",
  },
  {
    q: "Can Ayna host birthdays, anniversaries and private groups?",
    a: "Tripadvisor and Justdial both list a private dining area, and guests repeatedly mention celebrating special occasions at Ayna. For private dining, celebrations and group bookings, contact the hotel team on +91 44 2225 5555 or send an enquiry from this site's Events page. This website does not confirm event bookings.",
  },
  {
    q: "Does Ayna have a bar?",
    a: "Yes. Tripadvisor's description notes 'a selection of fine wines that pair perfectly with the cuisine', and Justdial categorises Ayna as a full bar / cocktail bar.",
  },
  {
    q: "Is Ayna inside a hotel? Can non-guests dine?",
    a: "Ayna is the Indian specialty restaurant of Hilton Chennai and is open to outside guests as well as hotel residents. Table booking is recommended (Justdial).",
  },
  {
    q: "Are the photographs on this website real?",
    a: "No. Every image on this website is AI-generated illustrative artwork created for this project and is labelled as such. Genuine photographs of Ayna are available on Tripadvisor (91 candid photos), Zomato, EazyDiner and Justdial — linked from the Gallery page.",
  },
  {
    q: "What is Ayna's e-mail address?",
    a: "No dedicated public e-mail address for Ayna is published on the sources we could verify (Tripadvisor, Hilton, Zomato, EazyDiner, Justdial, magicpin). Please use the phone numbers, WhatsApp, or the enquiry form on this site — we do not publish an address we cannot verify.",
  },
];

export const aboutFacts = [
  {
    label: "Cuisine",
    value: "Pan-Indian fine dining — North, South, East & West India",
  },
  { label: "Opened", value: "2011 (Justdial: year of establishment)" },
  { label: "Setting", value: "3rd floor of Hilton Chennai, Guindy" },
  { label: "Meal for two", value: "₹3,000 – ₹3,500 (excl. taxes & alcohol)" },
  { label: "Recognition", value: "Tripadvisor Travellers' Choice 2025" },
  { label: "Bar", value: "Full bar, fine wines & cocktails" },
] as const;

export const timeline = [
  {
    year: "2011",
    title: "Ayna opens at Hilton Chennai",
    body: "Justdial records Ayna's year of establishment as 2011, positioned as the hotel's Indian specialty restaurant.",
  },
  {
    year: "2012",
    title: "“A fitting reflection of Indian cuisine”",
    body: "The Hindu profiles Ayna's pan-regional repertoire — Goan curries, Bengali sweets, Kerala breads — and its old-world, velvet-and-brass dining room.",
  },
  {
    year: "2015",
    title: "The pan-Indian menu expansion",
    body: "Under sous chef M. T. Pauljoe, Ayna becomes the first Hilton restaurant in India to offer pan-Indian cuisine, adding Rajasthani, Bengali, Kashmiri, Goan and Awadhi sections to roughly 140 dishes.",
  },
  {
    year: "2016",
    title: "Tiffins of India",
    body: "Executive chef Achal Aggarwal launches the dabbawala-inspired tiffin lunch, serving home-style regional food in tiered steel dabbas.",
  },
  {
    year: "2021",
    title: "The 'Small Plates' rethink",
    body: "Executive chef Avijit Deb Sharma restructures the entire menu into compact small plates so a table can taste six or more dishes in one sitting.",
  },
  {
    year: "2025",
    title: "Tripadvisor Travellers' Choice",
    body: "Ayna earns Travellers' Choice 2025 and ranks #44 of 5,591 restaurants in Chennai with a 4.7/5 score from 169 reviews.",
  },
] as const;

export const experienceHighlights = [
  {
    title: "The tandoor & sigri",
    body: "Charcoal grills anchor the kitchen — kebabs, prawns and breads are finished to order, so the smokiest plates land at the table within minutes.",
  },
  {
    title: "Small plates, many regions",
    body: "Since 2021 the kitchen has plated dishes in compact portions, letting one table travel from Chettinad to Kashmir without filling up on two curries.",
  },
  {
    title: "Seafood from the Coromandel coast",
    body: "A dedicated seafood list — patrani macchi in mint foam, curry-leaf prawn kunufa, spiced lobster spring roll, Madras meen kozhambu.",
  },
  {
    title: "Wine & cocktails",
    body: "A curated wine list and a cocktail/mocktail programme designed to sit alongside strongly spiced food; the hotel's Vintage Bank wine-and-cheese bar is steps away.",
  },
  {
    title: "Occasions",
    body: "Private dining area, celebrations and group tables — guests repeatedly mark birthdays, anniversaries and work dinners here.",
  },
  {
    title: "Hotel-grade comfort",
    body: "Valet parking, wheelchair access, Wi-Fi, air-conditioned indoor seating and full hotel service standards.",
  },
] as const;
