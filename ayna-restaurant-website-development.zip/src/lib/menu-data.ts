/**
 * AYNA MENU — compiled from published sources only.
 *
 * Dish names and descriptions below are taken from Tripadvisor guest reviews,
 * The Hindu / The Hindu BusinessLine, Indian Express, Business Standard (IANS),
 * Indulge Express (The New Indian Express), Hoteliers Web, Hilton Chennai's own
 * dining page and Swiggy Dineout's "known for" list.
 *
 * IMPORTANT — PRICING: Ayna does not publish an official online à-la-carte price
 * list. Every price in this file is an INDICATIVE figure added so that the
 * pre-order basket can show a working order summary. They are clearly labelled
 * "Indicative" in the UI and are NOT official prices. The final bill is settled
 * at the restaurant. See README.md → "Menu & price accuracy".
 */

export type Diet = "veg" | "non-veg" | "vegan" | "egg";

export type MenuItem = {
  slug: string;
  name: string;
  category: MenuCategory;
  region: string;
  description: string;
  diet: Diet;
  spice: 0 | 1 | 2 | 3;
  /** Indicative price in INR — see file header. */
  price: number;
  signature?: boolean;
  source: string;
};

export const menuCategories = [
  "Small Plates",
  "Kebabs & Tandoor",
  "Seafood",
  "Vegetarian Mains",
  "Non-Vegetarian Mains",
  "Biryani & Rice",
  "Breads",
  "Desserts",
  "Beverages",
] as const;

export type MenuCategory = (typeof menuCategories)[number];

export const menu: MenuItem[] = [
  {
    slug: "kuzhi-paniyaram-manchurian",
    name: "Kuzhi Paniyaram ‘Manchurian’",
    category: "Small Plates",
    region: "Tamil Nadu",
    description:
      "Ayna's playful fusion small plate — saucy Schezwan-style paniyaram served with a manchow soup shooter and Chinese bhel for crunch.",
    diet: "veg",
    spice: 2,
    price: 495,
    source: "Indulge Express, Dec 2021 — Ayna 'Small Plates' menu review",
  },
  {
    slug: "chettinad-mutton-sukka-tartlets",
    name: "Chettinad Mutton Sukka Tartlets",
    category: "Small Plates",
    region: "Chettinad, Tamil Nadu",
    description:
      "Fiery Chettinad mutton sukka spooned into crisp bite-sized tartlets — the photograph that accompanied Indulge Express's review of the small-plates menu.",
    diet: "non-veg",
    spice: 3,
    price: 625,
    source: "Indulge Express, Dec 2021",
  },
  {
    slug: "suraputtu-samosa",
    name: "Suraputtu Samosa",
    category: "Small Plates",
    region: "Tamil Nadu",
    description:
      "A Tamil Muslim savoury pastry, listed on Ayna's seafood-forward small-plates selection.",
    diet: "non-veg",
    spice: 1,
    price: 445,
    source: "Hoteliers Web — Ayna exotic seafood menu coverage",
  },
  {
    slug: "spiced-lobster-spring-roll",
    name: "Spiced Lobster Spring Roll",
    category: "Small Plates",
    region: "Pan-Indian",
    description:
      "Lobster rolled with Indian spices, served with a carrot and cardamom purée.",
    diet: "non-veg",
    spice: 1,
    price: 895,
    source: "Hoteliers Web — Ayna exotic seafood menu coverage",
  },
  {
    slug: "dahi-ke-kebab",
    name: "Dahi ke Kebab",
    category: "Kebabs & Tandoor",
    region: "Awadh / North India",
    description:
      "Hung-curd kebabs, soft and flavourful — singled out by a Tripadvisor guest in their feast review.",
    diet: "veg",
    spice: 1,
    price: 525,
    signature: true,
    source: "Tripadvisor guest review, 'A Delightful Feast with Memorable Flavours'",
  },
  {
    slug: "smoked-mushroom-patties",
    name: "Smoked Mushroom Patties",
    category: "Kebabs & Tandoor",
    region: "Pan-Indian",
    description:
      "Finely chopped smoked mushrooms with caramelised onion — the dish The Hindu BusinessLine's reviewer said 'hits the palate immediately'.",
    diet: "veg",
    spice: 1,
    price: 545,
    source: "The Hindu BusinessLine, Ayna review",
  },
  {
    slug: "paneer-tikka",
    name: "Paneer Tikka",
    category: "Kebabs & Tandoor",
    region: "North India",
    description:
      "Cottage cheese from the charcoal tandoor — 'well cooked with a soft yet chewy consistency' per The Hindu BusinessLine.",
    diet: "veg",
    spice: 1,
    price: 575,
    source: "The Hindu BusinessLine, Ayna review",
  },
  {
    slug: "tandoori-kasundi-jheenga",
    name: "Tandoori Kasundi Jheenga",
    category: "Kebabs & Tandoor",
    region: "Bengal",
    description:
      "Curled king prawns in Bengali kasundi mustard, charcoal grilled — 'each prawn was juicy and mouthful' (IANS tasting).",
    diet: "non-veg",
    spice: 2,
    price: 895,
    signature: true,
    source: "Business Standard / IANS, Oct 2015 — new pan-Indian menu tasting",
  },
  {
    slug: "malabar-chemeen-fry",
    name: "Malabar Chemeen Fry",
    category: "Kebabs & Tandoor",
    region: "Kerala",
    description: "Kerala-style prawn fry, recommended for prawn lovers by the IANS tasting panel.",
    diet: "non-veg",
    spice: 2,
    price: 795,
    source: "Business Standard / IANS, Oct 2015",
  },
  {
    slug: "parde-jhinga-kebab",
    name: "Parda Jhinga Kebab",
    category: "Kebabs & Tandoor",
    region: "Hyderabad",
    description:
      "Prawns sealed in a veil ('parda') and finished in the tandoor — ordered and enjoyed by a February 2026 Tripadvisor guest.",
    diet: "non-veg",
    spice: 2,
    price: 875,
    source: "Tripadvisor guest review, Feb 2026 — 'Nice experience, Must Try'",
  },
  {
    slug: "gosht-noorani-seekh",
    name: "Gosht Noorani Seekh",
    category: "Kebabs & Tandoor",
    region: "North India",
    description:
      "Lamb seekh kebab off the charcoal; the same table called the accompanying scotched egg 'well cooked with a great taste'.",
    diet: "non-veg",
    spice: 2,
    price: 745,
    source: "Tripadvisor guest review, Feb 2026",
  },
  {
    slug: "subz-makhana-ki-seekh",
    name: "Subz Makhana ki Seekh",
    category: "Kebabs & Tandoor",
    region: "North India",
    description: "Foxnut and vegetable seekh kebab — the vegetarian starter a 2026 table chose.",
    diet: "veg",
    spice: 1,
    price: 545,
    source: "Tripadvisor guest review, Feb 2026",
  },
  {
    slug: "murgh-malai-kebab",
    name: "Murgh Malai Kebab",
    category: "Kebabs & Tandoor",
    region: "North India",
    description:
      "Cream, cheese and cardamom-marinated chicken tikka — a guest favourite from the 2023 reviews ('Murg kabab was my favourite').",
    diet: "non-veg",
    spice: 0,
    price: 695,
    source: "Tripadvisor guest review, Aug 2023",
  },
  {
    slug: "filo-wrapped-patrani-macchi",
    name: "Filo Wrapped Patrani Macchi",
    category: "Seafood",
    region: "Parsi / Gujarat",
    description:
      "Green-chutney marinated fish wrapped in filo, served with mint foam — part of Ayna's exotic seafood à-la-carte selection.",
    diet: "non-veg",
    spice: 1,
    price: 895,
    source: "Hoteliers Web — Ayna exotic seafood menu coverage",
  },
  {
    slug: "curry-leaf-prawn-kunufa",
    name: "Curry Leaf Prawn Kunufa",
    category: "Seafood",
    region: "South India",
    description: "Prawns tossed with curry leaf and served with a tangy chutney.",
    diet: "non-veg",
    spice: 2,
    price: 845,
    source: "Hoteliers Web — Ayna exotic seafood menu coverage",
  },
  {
    slug: "madras-meen-kozhambu",
    name: "Madras Meen Kozhambu",
    category: "Seafood",
    region: "Chennai",
    description: "Classic Tamil tamarind fish curry, added with the pan-Indian menu expansion.",
    diet: "non-veg",
    spice: 3,
    price: 825,
    source: "Business Standard / IANS, Oct 2015",
  },
  {
    slug: "alleppey-curry",
    name: "Alleppey Vegetable Curry",
    category: "Vegetarian Mains",
    region: "Kerala",
    description:
      "Crunchy vegetables in a coconut and raw-mango gravy — 'slightly sweet' in The Hindu BusinessLine's tasting.",
    diet: "veg",
    spice: 1,
    price: 625,
    source: "The Hindu BusinessLine, Ayna review",
  },
  {
    slug: "paneer-lazzat",
    name: "Paneer Lazzat",
    category: "Vegetarian Mains",
    region: "Hyderabad",
    description:
      "Baby spinach and cottage-cheese dumplings with button mushroom and tomato gravy — 'taste great with the accompanying tandoored paronthi naan'.",
    diet: "veg",
    spice: 1,
    price: 675,
    signature: true,
    source: "Business Standard / IANS, Oct 2015",
  },
  {
    slug: "alur-dum",
    name: "Alur Dum",
    category: "Vegetarian Mains",
    region: "Bengal",
    description:
      "Baby potatoes tossed in a ginger, garlic and mustard-seed curry — 'a spicy concoction' and 'a pungent hit'.",
    diet: "veg",
    spice: 2,
    price: 595,
    source: "The Hindu BusinessLine, Ayna review",
  },
  {
    slug: "southern-saag-burrata",
    name: "Southern Saag Burrata",
    category: "Vegetarian Mains",
    region: "South India",
    description:
      "A modern Ayna plate: southern greens finished with burrata — chosen by a February 2026 guest.",
    diet: "veg",
    spice: 1,
    price: 745,
    source: "Tripadvisor guest review, Feb 2026",
  },
  {
    slug: "dilkush-kofta",
    name: "Dilkush Kofta",
    category: "Vegetarian Mains",
    region: "North India",
    description:
      "Ayna's comfort kofta — 'comforting' in a Tripadvisor feast review and named by Swiggy Dineout among the dishes Ayna is known for.",
    diet: "veg",
    spice: 1,
    price: 645,
    signature: true,
    source: "Tripadvisor guest review + Swiggy Dineout 'known for' list",
  },
  {
    slug: "murgh-nawabi-kofta",
    name: "Murgh Nawabi Kofta Curry",
    category: "Non-Vegetarian Mains",
    region: "Awadh / Lucknow",
    description: "Nawabi-style chicken koftas in a rich gravy — ordered by a 2026 table.",
    diet: "non-veg",
    spice: 1,
    price: 795,
    source: "Tripadvisor guest review, Feb 2026",
  },
  {
    slug: "gosht-nalli-ka-salan",
    name: "Gosht Nalli ka Salan",
    category: "Non-Vegetarian Mains",
    region: "Hyderabad",
    description:
      "Lamb shank in salan gravy — 'the lamb was succulent and fell off the bone'.",
    diet: "non-veg",
    spice: 2,
    price: 895,
    source: "Tripadvisor guest review, Feb 2026",
  },
  {
    slug: "nalli-nihari",
    name: "Nalli Nihari",
    category: "Non-Vegetarian Mains",
    region: "Awadh / Delhi",
    description:
      "Slow-braised lamb shank 'quite literally falling off the bone', served with a saffron potato mash.",
    diet: "non-veg",
    spice: 2,
    price: 925,
    signature: true,
    source: "Indulge Express, Dec 2021 — Small Plates review",
  },
  {
    slug: "chettinad-chicken-curry",
    name: "Chettinad Style Chicken Curry",
    category: "Non-Vegetarian Mains",
    region: "Chettinad, Tamil Nadu",
    description: "Pepper-and-star-anise Chettinad chicken, added with the pan-Indian menu.",
    diet: "non-veg",
    spice: 3,
    price: 795,
    source: "Business Standard / IANS, Oct 2015",
  },
  {
    slug: "chicken-pallipalayam",
    name: "Chicken Pallipalayam",
    category: "Non-Vegetarian Mains",
    region: "Pallipalayam, Tamil Nadu",
    description:
      "Dry-roasted Kongu-style chicken with shallots and coconut — listed by Swiggy Dineout as a dish Ayna is known for.",
    diet: "non-veg",
    spice: 2,
    price: 765,
    signature: true,
    source: "Swiggy Dineout 'known for' list",
  },
  {
    slug: "pondicherry-duck",
    name: "Pondicherry Duck",
    category: "Non-Vegetarian Mains",
    region: "Puducherry",
    description: "French-influenced Tamil duck preparation from the expanded pan-Indian menu.",
    diet: "non-veg",
    spice: 2,
    price: 995,
    source: "Business Standard / IANS, Oct 2015",
  },
  {
    slug: "dal-ayna",
    name: "Dal Ayna",
    category: "Vegetarian Mains",
    region: "Ambala / North India",
    description:
      "The house signature dal — urad simmered for hours using the hand-blending technique used for haleem. 'Creamy, dreamy depths.'",
    diet: "veg",
    spice: 1,
    price: 625,
    signature: true,
    source: "indian-travel-places.com Ayna food review, 2019",
  },
  {
    slug: "kacche-gosht-ki-biryani",
    name: "Hyderabadi Kacche Gosht ki Biryani",
    category: "Biryani & Rice",
    region: "Hyderabad",
    description:
      "Raw lamb marinated for 24 hours, layered with saffron rice and dum-cooked — 'the flavours of the mutton reach every grain of rice'.",
    diet: "non-veg",
    spice: 2,
    price: 995,
    signature: true,
    source: "indian-travel-places.com Ayna food review, 2019",
  },
  {
    slug: "awadhi-biryani",
    name: "Awadhi Biryani",
    category: "Biryani & Rice",
    region: "Lucknow",
    description: "Fragrant, delicate Lucknowi biryani — a guest tagged photograph on Tripadvisor.",
    diet: "non-veg",
    spice: 1,
    price: 945,
    source: "Tripadvisor guest photo captions, Jan 2025",
  },
  {
    slug: "prawn-tawa-biryani",
    name: "Prawn Tawa Biryani",
    category: "Biryani & Rice",
    region: "South India",
    description: "Seafood biryani finished on the tawa — a Swiggy Dineout highlight dish.",
    diet: "non-veg",
    spice: 2,
    price: 925,
    source: "Swiggy Dineout 'known for' list",
  },
  {
    slug: "subz-biryani",
    name: "Subz Biryani",
    category: "Biryani & Rice",
    region: "North India",
    description: "Vegetable dum biryani — one of the varied biryani options on the menu.",
    diet: "veg",
    spice: 1,
    price: 745,
    source: "Business Standard / IANS, Oct 2015 (vegetable biryani)",
  },
  {
    slug: "pulleao-aap-ki-pasand",
    name: "Pulao (Aap ki Pasand)",
    category: "Biryani & Rice",
    region: "Pan-Indian",
    description:
      "Build-your-own pulao — 'aromatic and balanced' in a Tripadvisor guest review.",
    diet: "veg",
    spice: 0,
    price: 595,
    source: "Tripadvisor guest review, 'A Delightful Feast with Memorable Flavours'",
  },
  {
    slug: "garlic-naan",
    name: "Garlic Naan",
    category: "Breads",
    region: "North India",
    description: "Justdial's 'must order' at Ayna — leavened tandoor bread brushed with garlic butter.",
    diet: "veg",
    spice: 0,
    price: 225,
    signature: true,
    source: "Justdial listing — 'Must Order Garlic Naan'",
  },
  {
    slug: "tandoored-paronthi-naan",
    name: "Tandoored Paronthi Naan",
    category: "Breads",
    region: "Punjab",
    description: "Layered paratha-naan hybrid recommended alongside the dal and paneer preparations.",
    diet: "veg",
    spice: 0,
    price: 245,
    source: "Business Standard / IANS, Oct 2015",
  },
  {
    slug: "kashmiri-bakarkhani",
    name: "Kashmiri Bakarkhani",
    category: "Breads",
    region: "Kashmir",
    description: "Saffron-scented layered flatbread served with tangy pumpkin curry and mango chutney.",
    diet: "veg",
    spice: 1,
    price: 275,
    source: "HungryForever — Indian Curry Trail festival menu at Ayna",
  },
  {
    slug: "sakora-phirni",
    name: "Sakora Phirni",
    category: "Desserts",
    region: "North India",
    description:
      "Ground-rice milk pudding set in earthen sakoras — named by IANS as the dessert to order.",
    diet: "veg",
    spice: 0,
    price: 425,
    signature: true,
    source: "Business Standard / IANS, Oct 2015",
  },
  {
    slug: "rasmalai",
    name: "Rasmalai",
    category: "Desserts",
    region: "Bengal",
    description: "Chenna discs in saffron-cardamom milk — the second sweet named by IANS.",
    diet: "veg",
    spice: 0,
    price: 445,
    source: "Business Standard / IANS, Oct 2015",
  },
  {
    slug: "apple-halwa",
    name: "Apple Halwa",
    category: "Desserts",
    region: "North India",
    description: "Crunchy apple halwa from the 'Tiffins of India' festival — a DT Next 'must try'.",
    diet: "veg",
    spice: 0,
    price: 395,
    source: "DT Next, Tiffins of India review, 2016",
  },
  {
    slug: "bebinca",
    name: "Goan Bebinca",
    category: "Desserts",
    region: "Goa",
    description: "Layered Goan pudding from Ayna's western-Indian repertoire.",
    diet: "veg",
    spice: 0,
    price: 445,
    source: "Business Standard / IANS, Tiffins of India, 2016",
  },
  {
    slug: "litchee-mocktail",
    name: "Litchee Mocktail",
    category: "Beverages",
    region: "Pan-Indian",
    description: "The refreshing litchee mocktail served to The Hindu BusinessLine's reviewer.",
    diet: "veg",
    spice: 0,
    price: 375,
    source: "The Hindu BusinessLine, Ayna review",
  },
  {
    slug: "fine-wines",
    name: "Fine Wines by the Glass",
    category: "Beverages",
    region: "International",
    description:
      "Ayna offers 'a selection of fine wines that pair perfectly with the cuisine' (Tripadvisor listing). Ask for the current wine list.",
    diet: "veg",
    spice: 0,
    price: 695,
    source: "Tripadvisor restaurant description",
  },
  {
    slug: "tiffins-of-india-lunch-box",
    name: "Tiffins of India Lunch Box",
    category: "Small Plates",
    region: "Mumbai · Goa · Rajasthan · Punjab · Delhi · Hyderabad",
    description:
      "A tiered dabbawala-style tiffin with a dal, two sabzis or one sabzi and a non-veg gravy, rice/pulao/paratha and a dessert. Festival concept (2016) — availability is seasonal, please ask.",
    diet: "non-veg",
    spice: 2,
    price: 1699,
    source:
      "Indian Express & Business Standard (IANS), Jul 2016 — non-veg ₹1,699 / veg ₹1,499",
  },
  {
    slug: "tiffins-of-india-lunch-box-veg",
    name: "Tiffins of India Lunch Box (Vegetarian)",
    category: "Small Plates",
    region: "Mumbai · Goa · Rajasthan · Punjab · Delhi · Hyderabad",
    description: "The vegetarian tiffin — published festival price ₹1,499 (2016).",
    diet: "veg",
    spice: 1,
    price: 1499,
    source: "Indian Express & Business Standard (IANS), Jul 2016",
  },
];

export const signatureDishes = menu.filter((item) => item.signature);

export const dietaryLabels: Record<Diet, string> = {
  veg: "Vegetarian",
  "non-veg": "Non-vegetarian",
  vegan: "Vegan",
  egg: "Egg",
};

export function dietBadgeClass(diet: Diet): string {
  switch (diet) {
    case "veg":
      return "bg-emerald-500/15 text-emerald-200 ring-emerald-400/30";
    case "vegan":
      return "bg-teal-500/15 text-teal-200 ring-teal-400/30";
    case "non-veg":
      return "bg-rose-500/15 text-rose-200 ring-rose-400/30";
    default:
      return "bg-amber-500/15 text-amber-200 ring-amber-400/30";
  }
}

export function formatINR(value: number): string {
  return `₹${value.toLocaleString("en-IN")}`;
}

export const priceDisclaimer =
  "All prices shown are INDICATIVE figures compiled for this website's pre-order basket and are not official Ayna prices. Ayna does not publish an online à-la-carte price list. Published guidance is ₹3,000–₹3,500 for two (excluding taxes and alcohol). Final prices are as per the restaurant's current menu.";
