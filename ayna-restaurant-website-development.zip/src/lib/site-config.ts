/**
 * SINGLE SOURCE OF TRUTH for Ayna's business details and external destinations.
 * Update reservation / delivery / WhatsApp links here only — every button on the
 * site reads from this file.
 *
 * VERIFICATION NOTES (compiled from public sources, last checked 2026):
 *  - Address, floor and postcode: Tripadvisor, Hilton.com, Zomato, EazyDiner, Justdial.
 *  - Dinner hours 18:30–23:00: Tripadvisor / Zomato / magicpin / Justdial.
 *    EazyDiner lists 18:00–23:00. Tripadvisor also lists a lunch service 12:30–15:00;
 *    current third-party listings advertise dinner only, so lunch is flagged `historic`.
 *  - Phone +91 44 2225 5555 = Hilton Chennai switchboard (Tripadvisor / Hilton).
 *    044 3085 5566 is listed by magicpin / indian-travel-places as the restaurant line.
 *  - Ratings: Tripadvisor 4.7/5 (169 reviews), Google 4.2 (~279), Zomato 4.3,
 *    Justdial 4.2 (~763 ratings). See src/lib/reviews-data.ts for sources.
 *  - No public, individually verifiable restaurant e-mail address was found; the
 *    contact form + WhatsApp + hotel switchboard are the verified channels.
 */

export const site = {
  name: "Ayna",
  legalName: "Ayna — the Indian specialty restaurant at Hilton Chennai",
  tagline: "Pan-Indian fine dining, reflected in gold",
  shortDescription:
    "Ayna is the Indian specialty fine-dining restaurant on the 3rd floor of Hilton Chennai, serving pan-Indian cuisine from Kashmir to Kanyakumari.",
  hotel: "Hilton Chennai",
  established: 2011,
  url: process.env.NEXT_PUBLIC_SITE_URL ?? "https://ayna-chennai.example.com",
} as const;

export const address = {
  line1: "3rd Floor, Hilton Chennai",
  line2: "124/1 Jawaharlal Nehru Salai (J.N. Salai)",
  line3: "Guindy, Poomagal Nagar",
  city: "Chennai",
  state: "Tamil Nadu",
  postalCode: "600032",
  country: "India",
  countryCode: "IN",
  singleLine:
    "3rd Floor, Hilton Chennai, 124/1 J.N. Salai, Guindy, Chennai 600032, Tamil Nadu, India",
  /** Hilton Chennai entrance coordinates (EazyDiner directions target). */
  lat: 13.0167993,
  lng: 80.2046761,
} as const;

export const contact = {
  hotelPhoneDisplay: "+91 44 2225 5555",
  hotelPhoneHref: "tel:+914422255555",
  restaurantPhoneDisplay: "044 3085 5566",
  restaurantPhoneHref: "tel:+914430855566",
  whatsappDisplay: "+91 95000 11940",
  whatsappNumber: "919500011940",
  /** No individually verifiable public restaurant e-mail address is published.
   *  Guests are routed to the hotel switchboard, WhatsApp and the enquiry form. */
  email: null as string | null,
  emailNote:
    "Ayna does not publish a dedicated public e-mail address. Enquiries are handled by the Hilton Chennai team on the phone numbers above, on WhatsApp, or through this website's enquiry form.",
} as const;

/* ------------------------------------------------------------------ *
 * EXTERNAL DESTINATIONS — edit these three values to re-target the site
 * ------------------------------------------------------------------ */

export const externalLinks = {
  /** Official Google Dining reservation page supplied by the restaurant. */
  reservations:
    "https://www.google.com/maps/reserve/v/dine/c/rzlIakkqlvc?source=pa&opi=89978449&hl=hi-IN&gei=I0LSaqWtFcKa4-EPz46viQ4&sourceurl=https://www.google.com/search?q%3Dayna%2Brestaurant%2Bchennai%26client%3Dtablet-android-oppo-terr1-rso2%26hs%3DuYUB%26sca_esv%3D90c58dd08e43b2c3%26sxsrf%3DAPpeQnubYIr9BgBlJfLwpBaa7ZSuUEo26A:1792163945588%26ei%3DaUDSar3GI_aR4-EP7efPoQk%26bih%3D685%26gs_ssp%3DeJwFwUEOQDAQBdDYSqxtu7HumGZaHMEtvjHBpgkq4fbeqxu_-b5X4SFuelI1dfQGCMcUDIMyQDLRy3FJoyFhoTGuonOLL8Nddhc8F3JxulvOOH5vFhgf%26oq%3Dayna%2Brestaurant%2Bche%26gs_lp%3DEhNtb2JpbGUtZ3dzLXdpei1zZXJwIhNheW5hIHJlc3RhdXJhbnQgY2hlKg4IABiABBjHBRjHARivATIOEC4YgAQYxwUYxwEYrwEyBhAAGBYYHjIFECEYoAEyBRAhGKABMggQABiABBiiBDIIEAAYgAQYogQyBRAAGO8FSPAZUIAGWPkQcAF4AZABAJgB_gGgAY0HqgEDMi00uAEByAEA-AEBmAIFoALFB8ICChAAGEcY1gQYsAPCAg0QABiABBiKBRhDGLADwgIIEAAYgAQYxwWYAwCIBgGQBgySBwUxLjAuNKAHrx6yBwMyLTS4B68HwgcFMi0zLjLIBzOACAE%26sclient%3Dmobile-gws-wiz-serp",
  /** Official Zomato listing (delivery / order online + menus + photos). */
  zomato: "https://www.zomato.com/chennai/ayna-hilton-chennai-guindy",
  zomatoMenu:
    "https://www.zomato.com/chennai/ayna-hilton-chennai-guindy/menu",
  zomatoPhotos:
    "https://www.zomato.com/chennai/ayna-hilton-chennai-guindy/photos",
  tripadvisor:
    "https://www.tripadvisor.com/Restaurant_Review-g304556-d3588786-Reviews-Ayna-Chennai_Madras_Chennai_District_Tamil_Nadu.html",
  tripadvisorPhotos:
    "https://www.tripadvisor.com/Restaurant_Review-g304556-d3588786-Reviews-or20-Ayna-Chennai_Madras_Chennai_District_Tamil_Nadu.html#photos",
  justdial:
    "https://www.justdial.com/Chennai/Ayna-Hilton-Near-Olympia-Tech-Park-Guindy-Guindy/044PXX44-XX44-111229174953-Q4R1_BZDET",
  swiggyDineout:
    "https://www.swiggy.com/restaurants/ayna-hilton-guindy-chennai-600682/dineout",
  hiltonDining:
    "https://www.hilton.com/en/hotels/maahihi-hilton-chennai/dining/",
  googleMapsDirections:
    "https://www.google.com/maps/dir/?api=1&destination=13.0167993,80.2046761",
  googleMapsPlace:
    "https://www.google.com/maps/search/?api=1&query=13.0167993,80.2046761",
  instagram: null as string | null,
  facebook: null as string | null,
} as const;

export function whatsappLink(message?: string): string {
  const text =
    message ??
    `Hello Ayna (Hilton Chennai)! I would like to enquire about a table. Please share availability.`;
  return `https://wa.me/${contact.whatsappNumber}?text=${encodeURIComponent(text)}`;
}

/* ------------------------------------------------------------------ *
 * OPENING HOURS — Asia/Kolkata (IST, UTC+05:30). No DST in India.
 * ------------------------------------------------------------------ */

export type ServiceWindow = {
  id: string;
  label: string;
  /** Minutes from midnight, IST. */
  opens: number;
  closes: number;
  /** true = listed by Tripadvisor historically, not in current 3rd-party listings. */
  historic?: boolean;
};

/** 0 = Sunday … 6 = Saturday */
export const openingHours: Record<number, ServiceWindow[]> = {
  0: [
    { id: "lunch", label: "Lunch", opens: 12 * 60 + 30, closes: 15 * 60, historic: true },
    { id: "dinner", label: "Dinner", opens: 18 * 60 + 30, closes: 23 * 60 },
  ],
  1: [
    { id: "lunch", label: "Lunch", opens: 12 * 60 + 30, closes: 15 * 60, historic: true },
    { id: "dinner", label: "Dinner", opens: 18 * 60 + 30, closes: 23 * 60 },
  ],
  2: [
    { id: "lunch", label: "Lunch", opens: 12 * 60 + 30, closes: 15 * 60, historic: true },
    { id: "dinner", label: "Dinner", opens: 18 * 60 + 30, closes: 23 * 60 },
  ],
  3: [
    { id: "lunch", label: "Lunch", opens: 12 * 60 + 30, closes: 15 * 60, historic: true },
    { id: "dinner", label: "Dinner", opens: 18 * 60 + 30, closes: 23 * 60 },
  ],
  4: [
    { id: "lunch", label: "Lunch", opens: 12 * 60 + 30, closes: 15 * 60, historic: true },
    { id: "dinner", label: "Dinner", opens: 18 * 60 + 30, closes: 23 * 60 },
  ],
  5: [
    { id: "lunch", label: "Lunch", opens: 12 * 60 + 30, closes: 15 * 60, historic: true },
    { id: "dinner", label: "Dinner", opens: 18 * 60 + 30, closes: 23 * 60 },
  ],
  6: [
    { id: "lunch", label: "Lunch", opens: 12 * 60 + 30, closes: 15 * 60, historic: true },
    { id: "dinner", label: "Dinner", opens: 18 * 60 + 30, closes: 23 * 60 },
  ],
};

export const hoursSummary = [
  { label: "Lunch (see note)", value: "12:30 pm – 3:00 pm" },
  { label: "Dinner", value: "6:30 pm – 11:00 pm" },
  { label: "Days", value: "Open every day of the week" },
] as const;

export const hourNotes = [
  "Dinner 6:30 pm – 11:00 pm daily is consistent across Tripadvisor, Zomato, magicpin and Justdial. EazyDiner lists 6:00 pm – 11:00 pm.",
  "Tripadvisor lists a lunch service (12:30 pm – 3:00 pm) and Indian press coverage from 2015–2022 describes lunch at Ayna, but current Zomato and Swiggy listings advertise dinner only. Always confirm lunch availability before travelling.",
  "Hours can change for private events and festivals — please reconfirm by phone or WhatsApp.",
] as const;

export const facilities = [
  { icon: "🍷", label: "Full bar", detail: "Fine wines, cocktails and mocktails" },
  { icon: "🚗", label: "Valet parking", detail: "Hotel valet at the Hilton Chennai porch" },
  { icon: "♿", label: "Wheelchair accessible", detail: "Step-free access via hotel lifts" },
  { icon: "👨‍👩‍👧", label: "Kid friendly", detail: "High chairs and children's portions on request" },
  { icon: "🚭", label: "Designated smoking area", detail: "Listed by Justdial" },
  { icon: "🛜", label: "Wi-Fi", detail: "Hotel guest and dining-room Wi-Fi" },
  { icon: "🪑", label: "Private dining area", detail: "Listed on Tripadvisor and Justdial" },
  { icon: "💳", label: "Cards accepted", detail: "Amex, Mastercard, Visa (Tripadvisor)" },
  { icon: "🥗", label: "Vegetarian, vegan & gluten-free options", detail: "Tripadvisor features" },
  { icon: "🧑‍🍳", label: "Open tandoor kitchen", detail: "Charcoal grills and breads to order" },
  { icon: "🅿️", label: "On-site hotel parking", detail: "Tripadvisor: parking available" },
  { icon: "🎂", label: "Celebrations", detail: "Cakes and table décor arranged on request" },
] as const;

export const ratings = [
  {
    source: "Tripadvisor",
    score: "4.7 / 5",
    detail: "169 reviews · Travellers' Choice 2025 · #44 of 5,591 restaurants in Chennai",
    url: externalLinks.tripadvisor,
  },
  {
    source: "Google",
    score: "4.2 / 5",
    detail: "≈279 ratings (reported by EazyDiner / Swiggy Dineout)",
    url: externalLinks.googleMapsPlace,
  },
  {
    source: "Zomato",
    score: "4.3 / 5",
    detail: "Diner ratings, Zomato listing",
    url: externalLinks.zomato,
  },
  {
    source: "Justdial",
    score: "4.2 / 5",
    detail: "≈763 ratings · Est. 2011 · “Known for ambience”",
    url: externalLinks.justdial,
  },
] as const;

export const priceGuidance = {
  costForTwo: "₹3,000 for two (Zomato / Swiggy) · ₹3,500 for two (EazyDiner) · ₹3,100 (Justdial)",
  note: "Excludes taxes and beverages. A pint of beer is listed at ₹500 by Justdial.",
} as const;
