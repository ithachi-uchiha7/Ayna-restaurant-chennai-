import { z } from "zod";
import { zodErrors, type FieldErrors } from "./validation";

export async function readJson(request: Request): Promise<{ ok: true; data: unknown } | { ok: false; response: Response }> {
  try {
    const data = await request.json();
    return { ok: true, data };
  } catch {
    return {
      ok: false,
      response: Response.json({ ok: false, error: "Invalid request body." }, { status: 400 }),
    };
  }
}

export function invalid(error: z.ZodError): Response {
  const fields: FieldErrors = zodErrors(error);
  return Response.json(
    {
      ok: false,
      error: "Please check the highlighted fields.",
      fields,
    },
    { status: 422 },
  );
}

export function fail(message: string, status = 400): Response {
  return Response.json({ ok: false, error: message }, { status });
}

export function ok<T extends Record<string, unknown>>(payload: T, status = 200): Response {
  return Response.json({ ok: true, ...payload }, { status });
}
