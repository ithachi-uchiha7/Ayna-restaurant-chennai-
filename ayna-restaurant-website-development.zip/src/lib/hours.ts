import { openingHours, type ServiceWindow } from "./site-config";

/** IST is UTC+05:30 with no daylight saving. */
export const IST_OFFSET_MINUTES = 330;

export type Instant = { day: number; minutes: number };

/** Convert an absolute Date into { day, minutes } in Indian Standard Time. */
export function toIstInstant(date: Date): Instant {
  const ms = date.getTime() + IST_OFFSET_MINUTES * 60 * 1000;
  const shifted = new Date(ms);
  return {
    day: shifted.getUTCDay(),
    minutes: shifted.getUTCHours() * 60 + shifted.getUTCMinutes(),
  };
}

export function formatMinutes(total: number): string {
  const h24 = Math.floor(total / 60) % 24;
  const m = total % 60;
  const suffix = h24 >= 12 ? "pm" : "am";
  const h12 = h24 % 12 === 0 ? 12 : h24 % 12;
  return `${h12}:${String(m).padStart(2, "0")} ${suffix}`;
}

export type OpenStatus = {
  isOpen: boolean;
  label: string;
  detail: string;
  windows: ServiceWindow[];
  currentService?: ServiceWindow;
  nextService?: { window: ServiceWindow; day: number; startsInMinutes: number };
  /** Number of minutes until the current service closes (null if closed). */
  closesInMinutes: number | null;
};

/**
 * Pure open/closed calculator based on the verified hours in site-config.
 * `now` is injected so tests are deterministic and so the client can tick.
 */
export function computeOpenStatus(now: Date = new Date()): OpenStatus {
  const { day, minutes } = toIstInstant(now);
  const windows = openingHours[day] ?? [];
  const active = windows.find((w) => minutes >= w.opens && minutes < w.closes);

  if (active) {
    return {
      isOpen: true,
      label: "Open now",
      detail: `${active.label} service until ${formatMinutes(active.closes)} IST`,
      windows,
      currentService: active,
      closesInMinutes: active.closes - minutes,
    };
  }

  // Look ahead up to 7 days for the next service window.
  for (let offset = 0; offset <= 7; offset += 1) {
    const probeDay = (day + offset) % 7;
    const dayWindows = openingHours[probeDay] ?? [];
    const upcoming = dayWindows.find((w) => (offset === 0 ? w.opens > minutes : true));
    if (upcoming) {
      const startsInMinutes = offset * 1440 + upcoming.opens - minutes;
      const when =
        offset === 0
          ? `today at ${formatMinutes(upcoming.opens)} IST`
          : offset === 1
            ? `tomorrow at ${formatMinutes(upcoming.opens)} IST`
            : `on ${dayName(probeDay)} at ${formatMinutes(upcoming.opens)} IST`;
      return {
        isOpen: false,
        label: "Closed",
        detail: `Opens ${when}`,
        windows,
        nextService: { window: upcoming, day: probeDay, startsInMinutes },
        closesInMinutes: null,
      };
    }
  }

  return {
    isOpen: false,
    label: "Hours unavailable",
    detail: "Please call us to confirm today's hours",
    windows,
    closesInMinutes: null,
  };
}

export function dayName(day: number): string {
  return [
    "Sunday",
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday",
  ][day];
}

export const weekOrder = [1, 2, 3, 4, 5, 6, 0];

/** Reservation slots for a given service window, in 30-minute steps. */
export function slotsFor(window: ServiceWindow, step = 30): string[] {
  const out: string[] = [];
  for (let m = window.opens; m <= window.closes - 60; m += step) {
    const h = Math.floor(m / 60);
    const mm = m % 60;
    out.push(`${String(h).padStart(2, "0")}:${String(mm).padStart(2, "0")}`);
  }
  return out;
}

export function dinnerSlots(): string[] {
  const dinner = openingHours[5].find((w) => w.id === "dinner");
  return dinner ? slotsFor(dinner) : [];
}
