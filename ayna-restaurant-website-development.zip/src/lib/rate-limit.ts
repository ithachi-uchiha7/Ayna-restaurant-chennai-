type Bucket = { tokens: number; updated: number };

const buckets = new Map<string, Bucket>();

export type RateLimitResult = {
  ok: boolean;
  remaining: number;
  retryAfterSeconds: number;
};

/**
 * Small in-memory token bucket. Good enough for a single Node server instance;
 * swap for Redis/Upstash when you scale horizontally (see README).
 */
export function rateLimit(
  key: string,
  { limit, windowSeconds }: { limit: number; windowSeconds: number },
): RateLimitResult {
  const now = Date.now();
  const refillRate = limit / windowSeconds;
  const bucket = buckets.get(key) ?? { tokens: limit, updated: now };
  const elapsedSeconds = (now - bucket.updated) / 1000;
  bucket.tokens = Math.min(limit, bucket.tokens + elapsedSeconds * refillRate);
  bucket.updated = now;

  if (bucket.tokens < 1) {
    buckets.set(key, bucket);
    return {
      ok: false,
      remaining: 0,
      retryAfterSeconds: Math.ceil((1 - bucket.tokens) / refillRate),
    };
  }

  bucket.tokens -= 1;
  buckets.set(key, bucket);

  if (buckets.size > 5000) {
    for (const [k, v] of buckets) {
      if (now - v.updated > windowSeconds * 5000) buckets.delete(k);
    }
  }

  return { ok: true, remaining: Math.floor(bucket.tokens), retryAfterSeconds: 0 };
}

export function clientKey(request: Request, scope: string): string {
  const forwarded = request.headers.get("x-forwarded-for") ?? "";
  const ip = forwarded.split(",")[0].trim() || request.headers.get("x-real-ip") || "local";
  return `${scope}:${ip}`;
}

export function tooMany(result: RateLimitResult): Response {
  return Response.json(
    { ok: false, error: "Too many requests. Please try again shortly." },
    {
      status: 429,
      headers: { "Retry-After": String(Math.max(1, result.retryAfterSeconds)) },
    },
  );
}

export function safeError(message = "Something went wrong. Please try again."): Response {
  return Response.json({ ok: false, error: message }, { status: 500 });
}
