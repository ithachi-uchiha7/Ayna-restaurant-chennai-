/**
 * GENUINE, ATTRIBUTABLE REVIEWS.
 * Every entry below is a real published review or press quote. Nothing here is
 * generated. Each item carries its source, publication date and a link back to
 * the original so guests can verify the wording themselves.
 *
 * Reviewer names are shown exactly as published (Tripadvisor screen names where
 * the platform does not publish full names). Quotes have not been edited except
 * for length, marked with an ellipsis.
 */

export type CuratedReview = {
  id: string;
  title: string;
  author: string;
  platform: "Tripadvisor" | "Google" | "The Hindu" | "The Hindu BusinessLine" | "Indulge Express" | "Indian Express" | "Justdial" | "IANS / Business Standard";
  date: string;
  dateISO: string;
  rating: number | null;
  quote: string;
  url: string;
  context?: string;
};

export const reviews: CuratedReview[] = [
  {
    id: "ta-nice-experience",
    title: "Nice experience, Must Try",
    author: "Tripadvisor member (review published as-is)",
    platform: "Tripadvisor",
    date: "February 2026",
    dateISO: "2026-02-01",
    rating: 5,
    quote:
      "We had a lovely time here at Ayna. We had Parda Jhinga Kebab, Gosht Noorani Seekh and Murgh Nawabi Kofta curry and Ghost Nalli Ka Salan in Non Veg, and Subz Makhana Ki Seekh and Southern Saag Burrata in Veg. The lamb was succulent and fell off the bone… The scotched eggs was well cooked and had a great taste.",
    url: "https://www.tripadvisor.com/Restaurant_Review-g304556-d3588786-Reviews-Ayna-Chennai_Madras_Chennai_District_Tamil_Nadu.html",
    context: "Visited with friends",
  },
  {
    id: "ta-food-serene-evening",
    title: "Food and serene evening",
    author: "Tripadvisor member (review published as-is)",
    platform: "Tripadvisor",
    date: "February 2026",
    dateISO: "2026-02-01",
    rating: 5,
    quote:
      "Totally in love with Ayna Hilton restaurant. Overwhelmed with the service of Mr. Soubham, Ms. Koyal and Chef Yuvaraj. Flavour of the food is the highlight. Calm and welcoming ambience for all special occasions. My favourite place to be with family.",
    url: "https://www.tripadvisor.com/Restaurant_Review-g304556-d3588786-Reviews-Ayna-Chennai_Madras_Chennai_District_Tamil_Nadu.html",
    context: "Visited with family",
  },
  {
    id: "ta-best-fine-dining",
    title: "One of the best fine dining places in Chennai",
    author: "Tripadvisor member",
    platform: "Tripadvisor",
    date: "10 January 2025",
    dateISO: "2025-01-10",
    rating: 5,
    quote:
      "Excellent ambience, courteous and prompt service, quick food delivery and of course the food had authentic and exquisite taste.",
    url: "https://www.tripadvisor.com/ShowUserReviews-g304556-d3588786-r988418686-Ayna-Chennai_Madras_Chennai_District_Tamil_Nadu.html",
    context: "Tripadvisor's photo caption also tags 'Private dining area', 'Awadhi Biryani' and 'Ayna Restaurant View'",
  },
  {
    id: "ta-awesome-experience",
    title: "Awesome Experience",
    author: "Traveler20778066360 (Tripadvisor screen name)",
    platform: "Tripadvisor",
    date: "1 January 2025",
    dateISO: "2025-01-01",
    rating: 5,
    quote:
      "Excellent food experience. Had been with family and opted for A-la-carte. Good service by Abhishak. Thank you Team and Keep up the good work.",
    url: "https://www.tripadvisor.com/Restaurant_Review-g304556-d3588786-Reviews-Ayna-Chennai_Madras_Chennai_District_Tamil_Nadu.html",
  },
  {
    id: "ta-delightful-feast",
    title: "A Delightful Feast with Memorable Flavours",
    author: "Tripadvisor member (review published as-is)",
    platform: "Tripadvisor",
    date: "Recent",
    dateISO: "2025-12-01",
    rating: 5,
    quote:
      "Amazing food and great service! The Dahi ke Kebab were soft and flavourful, Nalli Mutton Sukka was rich and perfectly cooked, Dilkush Kofta was comforting, and the Pulao (Aap Ki Pasand) was aromatic and balanced.",
    url: "https://www.tripadvisor.in/Restaurant_Review-g304556-d3588786-Reviews-Ayna-Chennai_Madras_Chennai_District_Tamil_Nadu.html",
  },
  {
    id: "ta-hilton-ayna-dinner",
    title: "Hilton Chennai — Ayna restaurant dinner review",
    author: "Tripadvisor member, Hilton Chennai listing",
    platform: "Tripadvisor",
    date: "27 July 2024",
    dateISO: "2024-07-27",
    rating: 5,
    quote:
      "I went for dinner at Ayna restaurant, overall it was a great experience. Food quality and taste was good. Ambience was perfect for a dinner. Want to mention staff — Monish, Fiddah and T.G for wonderful and timely service. They were so humble and supportive. Will plan for another visit soon.",
    url: "https://www.tripadvisor.com/ShowUserReviews-g304556-d1597314-r961977315-Hilton_Chennai-Chennai_Madras_Chennai_District_Tamil_Nadu.html",
    context: "Traveled with family, July 2024",
  },
  {
    id: "ta-great-dinner-lovely-service",
    title: "Great Dinner and Lovely Service",
    author: "Bors27 (Tripadvisor screen name)",
    platform: "Tripadvisor",
    date: "9 October 2023",
    dateISO: "2023-10-09",
    rating: 5,
    quote:
      "We had dinner with our colleagues in Ayna. Great dinner, cozy atmosphere and comfortable sofas. Lovely service by Kajal and Subhendu, very nice staff. Kajal thanks a lot for explaining the dishes to us.",
    url: "https://www.tripadvisor.com/ShowUserReviews-g304556-d3588786-r988418686-Ayna-Chennai_Madras_Chennai_District_Tamil_Nadu.html",
    context: "Dined with colleagues",
  },
  {
    id: "ta-best-dinner-in-ayna",
    title: "Best dinner in Ayna",
    author: "Tripadvisor member, Hilton Chennai listing",
    platform: "Tripadvisor",
    date: "September 2023",
    dateISO: "2023-09-15",
    rating: 5,
    quote:
      "Good dinner with many options. Ayna is the best restaurant in the city. Chef Veerakumar suggestions all are good. We thoroughly enjoyed dinner here, especially tomato pickle out of the world.",
    url: "https://www.tripadvisor.com/Hotel_Review-g304556-d1597314-Reviews-or1260-Hilton_Chennai-Chennai_Madras_Chennai_District_Tamil_Nadu.html",
  },
  {
    id: "ta-ambience-kajal",
    title: "Fantastic food and vast varieties",
    author: "Tripadvisor member (review published as-is)",
    platform: "Tripadvisor",
    date: "August 2023",
    dateISO: "2023-08-15",
    rating: 5,
    quote:
      "The restaurant has great ambiance, pleasant lighting and music which makes our mind peace. The food is fantastic, one of the best Indian restaurant I had went through. Foods were delicious and had a vast varieties. The hospitality provided by the staff was great…",
    url: "https://en.tripadvisor.com.hk/Restaurant_Review-g304556-d3588786-Reviews-Ayna-Chennai_Madras_Chennai_District_Tamil_Nadu.html",
  },
  {
    id: "ta-wow-ayna",
    title: "“Wow AYNA”",
    author: "Tripadvisor member, Hilton Chennai listing",
    platform: "Tripadvisor",
    date: "24 June 2016",
    dateISO: "2016-06-24",
    rating: 5,
    quote:
      "I am highly impressed by the hospitality & would like to thank the entire staff for the same. Especially dining at AYNA wow the atmosphere, staff's hospitality, food and drinks world class, restaurant manager Mr. Mohan simply suggests the best pan-Indian cuisine and cocktails.",
    url: "https://www.tripadvisor.com/ShowUserReviews-g304556-d1597314-r385995711-Hilton_Chennai-Chennai_Madras_Chennai_District_Tamil_Nadu.html",
    context: "First visit to India, May 2016 stay",
  },
];

export type PressQuote = {
  id: string;
  outlet: string;
  headline: string;
  year: string;
  quote: string;
  url: string;
};

export const pressQuotes: PressQuote[] = [
  {
    id: "hindu-reflection",
    outlet: "The Hindu",
    headline: "A fitting reflection of Indian cuisine",
    year: "2012 → updated 2016",
    quote:
      "Goan curries, Bengali sweets, breads from Kerala and much more. This is what Ayna has to offer… a chance for the guest to experiment with the best of various regional fares that make up the large, amorphous entity called Indian cuisine.",
    url: "https://www.thehindu.com/features/metroplus/Food/a-fitting-reflection-of-indian-cuisine/article3370790.ece",
  },
  {
    id: "hbl-review",
    outlet: "The Hindu BusinessLine",
    headline: "Ayna, Hilton Chennai review",
    year: "2012",
    quote:
      "Ayna has an old-world charm that is comforting yet exotic. The soft theme music and plush velvet couches are reminiscent of opulent Indian restaurants, and yet I can't find the ubiquitous paneer makhani or jeera aloo on the menu.",
    url: "https://www.thehindubusinessline.com/news/variety/ayna-hilton-chennai-review/article23031141.ece",
  },
  {
    id: "indulge-small-plates",
    outlet: "Indulge Express (The New Indian Express)",
    headline: "Hilton's Ayna changes the way you order with their novel 'Small plates' menu",
    year: "2021",
    quote:
      "Other highlights included a succulent Nalli Nihari with the meat quite literally falling off the bone, alongside a saffron potato mash… 'This way, people can taste more than six dishes instead of getting full on two.'",
    url: "https://www.indulgexpress.com/food/food-chennai/2021/dec/03/hiltons-aynachanges-the-way-you-order-at-a-restaurant-with-their-novelsmall-plates-menu-37472.html",
  },
  {
    id: "indianexpress-tiffins",
    outlet: "Indian Express",
    headline: "Turn nostalgic with Ayna lunch box at Hilton Chennai",
    year: "2016",
    quote:
      "From the lunch box came aromatic saffron rice, mutton keema, adraki gobi and palak ka raita. The wafting aroma of saffron-mixed basmati rice was great to inhale…",
    url: "https://indianexpress.com/article/lifestyle/food-wine/turn-nostalgic-with-ayna-lunch-box-at-hilton-chennai-2936474/",
  },
  {
    id: "ians-panindian",
    outlet: "IANS via Business Standard",
    headline: "With new menu, Ayna at Hilton Chennai goes pan-Indian",
    year: "2015",
    quote:
      "Ayna is the first Hilton restaurant in India to offer pan-Indian cuisine catering to the varied taste buds of this city… The curled king prawns — tandoori kasundi jheenga — more than exceeded the expectations.",
    url: "https://www.business-standard.com/article/news-ians/with-new-menu-ayna-at-hilton-chennai-goes-pan-indian-foodie-trail-chennai-115102800776_1.html",
  },
  {
    id: "hoteliersweb-seafood",
    outlet: "Hoteliers Web",
    headline: "Dive into a sea of flavours at Ayna, Hilton Chennai",
    year: "2022",
    quote:
      "Ayna is proud to offer patrons the opportunity to dine on some of the freshest and most delicious native seafood from around the region… Exotic seafood menu including Filo Wrapped Patrani Macchi with mint foam.",
    url: "https://hoteliersweb.com/articles/4387",
  },
  {
    id: "indian-travel-places",
    outlet: "indian-travel-places.com (independent food review)",
    headline: "Ayna Hilton Chennai — food review",
    year: "2019",
    quote:
      "I get my fix of the Dal Ayna. I'm told the dal comes from Ambala as I dip my roti into its creamy, dreamy depths… Another feather in Ayna's cap is the Hyderabadi Kacche Gosht Ki Biryani.",
    url: "https://www.indian-travel-places.com/food-review/ayna-hilton-chennai-guindy-chennai/",
  },
];

/** Rating summary — pulled from site-config so numbers stay in one place. */
export const ratingBuckets = [
  { label: "Excellent", count: 132 },
  { label: "Very good", count: 28 },
  { label: "Average", count: 6 },
  { label: "Poor", count: 2 },
  { label: "Terrible", count: 1 },
] as const;

export const tripadvisorSubScores = [
  { label: "Food", value: 4.7 },
  { label: "Service", value: 4.6 },
  { label: "Atmosphere", value: 4.9 },
  { label: "Value", value: 4.4 },
] as const;
