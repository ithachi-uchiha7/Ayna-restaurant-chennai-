import { menu, type MenuItem } from "./menu-data";

export type CartLine = { slug: string; qty: number };

export type CartEntry = {
  item: MenuItem;
  qty: number;
  lineTotal: number;
};

export type CartSummary = {
  lines: CartEntry[];
  count: number;
  vegCount: number;
  nonVegCount: number;
  indicativeTotal: number;
  hasIndicativePricing: boolean;
};

/**
 * Pure cart reducer/pricer shared by the client cart context, the checkout page
 * and the API validation layer. Kept free of browser/node APIs so it is unit
 * testable.
 */
export function summariseCart(lines: CartLine[], catalog: MenuItem[] = menu): CartSummary {
  const bySlug = new Map(catalog.map((item) => [item.slug, item]));
  const merged = new Map<string, number>();
  for (const line of lines) {
    if (!bySlug.has(line.slug)) continue;
    const qty = Math.max(1, Math.min(50, Math.floor(line.qty)));
    merged.set(line.slug, (merged.get(line.slug) ?? 0) + qty);
  }

  const entries: CartEntry[] = [...merged.entries()]
    .map(([slug, qty]) => {
      const item = bySlug.get(slug) as MenuItem;
      return { item, qty, lineTotal: item.price * qty };
    })
    .sort((a, b) => a.item.name.localeCompare(b.item.name));

  return {
    lines: entries,
    count: entries.reduce((sum, entry) => sum + entry.qty, 0),
    vegCount: entries.filter((e) => e.item.diet === "veg" || e.item.diet === "vegan").reduce((s, e) => s + e.qty, 0),
    nonVegCount: entries.filter((e) => e.item.diet === "non-veg" || e.item.diet === "egg").reduce((s, e) => s + e.qty, 0),
    indicativeTotal: entries.reduce((sum, entry) => sum + entry.lineTotal, 0),
    hasIndicativePricing: entries.length > 0,
  };
}

export function emptyCartSummary(): CartSummary {
  return {
    lines: [],
    count: 0,
    vegCount: 0,
    nonVegCount: 0,
    indicativeTotal: 0,
    hasIndicativePricing: false,
  };
}

export function referenceCode(prefix: string): string {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let out = "";
  for (let i = 0; i < 6; i += 1) {
    out += alphabet[Math.floor(Math.random() * alphabet.length)];
  }
  return `${prefix}-${out}`;
}
