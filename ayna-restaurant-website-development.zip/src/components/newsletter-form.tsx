"use client";

import { useState } from "react";
import { Field, inputClass, Spinner, StatusPanel } from "./ui";

export function NewsletterForm({ source = "footer" }: { source?: string }) {
  const [email, setEmail] = useState("");
  const [state, setState] = useState<"idle" | "loading" | "done" | "error">("idle");
  const [message, setMessage] = useState("");
  const [error, setError] = useState<string | null>(null);

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setState("loading");
    setError(null);
    try {
      const res = await fetch("/api/newsletter", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, source }),
      });
      const data = await res.json();
      if (!res.ok || !data.ok) {
        setError(data?.fields?.email ?? data?.error ?? "Could not subscribe.");
        setState("error");
        return;
      }
      setMessage(data.message);
      setState("done");
      setEmail("");
    } catch {
      setError("Network error. Please try again.");
      setState("error");
    }
  }

  if (state === "done") {
    return <StatusPanel tone="success" title="Subscribed">{message}</StatusPanel>;
  }

  return (
    <form onSubmit={onSubmit} noValidate className="space-y-3">
      <Field label="E-mail" name="newsletter-email" error={error ?? undefined}>
        <input
          id="newsletter-email"
          name="email"
          type="email"
          autoComplete="email"
          required
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="you@example.com"
          className={inputClass}
        />
      </Field>
      <button type="submit" className="btn-gold w-full" disabled={state === "loading"}>
        {state === "loading" ? <Spinner label="Subscribing" /> : "Join the list"}
      </button>
      <p className="text-[0.68rem] leading-relaxed text-emerald-50/40">
        Seasonal menus, festival nights and private-dining news. Unsubscribe any time. We store your
        e-mail and the page you subscribed from — nothing else.
      </p>
    </form>
  );
}
