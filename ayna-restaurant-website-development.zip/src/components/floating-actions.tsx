"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useCart } from "./cart-provider";
import { WhatsAppButton } from "./ui";
import { useEffect, useState } from "react";

/** Sticky mobile action bar + desktop WhatsApp floater. Hidden on admin pages. */
export function FloatingActions() {
  const pathname = usePathname();
  const { summary, ready } = useCart();
  const [mounted, setMounted] = useState(false);

  useEffect(() => setMounted(true), []);

  if (pathname.startsWith("/admin")) return null;

  return (
    <>
      <div className="pointer-events-none fixed bottom-5 right-4 z-50 hidden md:block">
        <div className="pointer-events-auto float-slow">
          <WhatsAppButton message="Hello Ayna (Hilton Chennai)! I have an enquiry about dining at Ayna." />
        </div>
      </div>

      <div className="fixed inset-x-0 bottom-0 z-50 border-t border-gold-400/20 bg-forest-950/95 px-3 py-2.5 backdrop-blur-xl md:hidden">
        <div className="flex items-center justify-between gap-2">
          <Link href="/menu" className="btn-ghost flex-1 !px-3 !py-2.5 !text-[0.6rem]">
            Menu
          </Link>
          <Link href="/reservations" className="btn-ghost flex-1 !px-3 !py-2.5 !text-[0.6rem]">
            Reserve
          </Link>
          <Link href="/cart" className="btn-gold relative flex-1 !px-3 !py-2.5 !text-[0.6rem]">
            Basket
            {mounted && ready && summary.count > 0 ? (
              <span className="absolute -right-1 -top-1 grid h-5 min-w-5 place-items-center rounded-full bg-forest-950 px-1 text-[0.6rem] font-bold text-gold-200 ring-1 ring-gold-300">
                {summary.count}
              </span>
            ) : null}
          </Link>
        </div>
      </div>
      <div aria-hidden className="h-16 md:hidden" />
    </>
  );
}
