"use client";

import { useMemo, useState } from "react";
import { DishCard } from "./dish-card";
import { menu, menuCategories, priceDisclaimer, type Diet, type MenuCategory } from "@/lib/menu-data";
import { Spinner } from "./ui";

const diets: (Diet | "all")[] = ["all", "veg", "non-veg", "vegan"];
const sorts = [
  { id: "curated", label: "Curated" },
  { id: "price-asc", label: "Price ↑" },
  { id: "price-desc", label: "Price ↓" },
  { id: "az", label: "A–Z" },
] as const;

export function MenuExplorer({ initialCategory = "all" }: { initialCategory?: MenuCategory | "all" }) {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState<MenuCategory | "all">(initialCategory);
  const [diet, setDiet] = useState<Diet | "all">("all");
  const [signatureOnly, setSignatureOnly] = useState(false);
  const [sort, setSort] = useState<(typeof sorts)[number]["id"]>("curated");
  const [loading, setLoading] = useState(false);

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    const filtered = menu.filter((item) => {
      if (category !== "all" && item.category !== category) return false;
      if (diet !== "all" && item.diet !== diet) return false;
      if (signatureOnly && !item.signature) return false;
      if (!q) return true;
      return `${item.name} ${item.description} ${item.region} ${item.category}`.toLowerCase().includes(q);
    });

    const sorted = [...filtered];
    if (sort === "price-asc") sorted.sort((a, b) => a.price - b.price);
    if (sort === "price-desc") sorted.sort((a, b) => b.price - a.price);
    if (sort === "az") sorted.sort((a, b) => a.name.localeCompare(b.name));
    return sorted;
  }, [query, category, diet, signatureOnly, sort]);

  function switchCategory(next: MenuCategory | "all") {
    if (next === category) return;
    setLoading(true);
    setCategory(next);
    window.setTimeout(() => setLoading(false), 220);
  }

  const grouped = useMemo(() => {
    if (sort !== "curated") return null;
    const map = new Map<MenuCategory, typeof results>();
    for (const item of results) {
      const list = map.get(item.category) ?? [];
      list.push(item);
      map.set(item.category, list);
    }
    return [...map.entries()];
  }, [results, sort]);

  return (
    <div>
      <div className="rounded-3xl glass p-5 sm:p-6">
        <div className="grid gap-4 lg:grid-cols-[2fr_1fr_1fr]">
          <label className="block">
            <span className="mb-2 block text-xs uppercase tracking-[0.18em] text-gold-200/75">
              Search dishes, regions or ingredients
            </span>
            <input
              type="search"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="e.g. biryani, Kerala, prawn, dal"
              className="w-full rounded-xl border border-gold-400/25 bg-forest-950/70 px-4 py-3 text-sm text-gold-50 placeholder:text-emerald-50/30 outline-none transition focus:border-gold-300/70"
              aria-label="Search the menu"
            />
          </label>

          <label className="block">
            <span className="mb-2 block text-xs uppercase tracking-[0.18em] text-gold-200/75">Dietary</span>
            <select
              value={diet}
              onChange={(event) => setDiet(event.target.value as Diet | "all")}
              className="w-full rounded-xl border border-gold-400/25 bg-forest-950/70 px-4 py-3 text-sm text-gold-50 outline-none transition focus:border-gold-300/70"
              aria-label="Filter by dietary preference"
            >
              {diets.map((option) => (
                <option key={option} value={option} className="bg-forest-950">
                  {option === "all" ? "Everything" : option === "non-veg" ? "Non-vegetarian" : option === "veg" ? "Vegetarian" : "Vegan"}
                </option>
              ))}
            </select>
          </label>

          <label className="block">
            <span className="mb-2 block text-xs uppercase tracking-[0.18em] text-gold-200/75">Sort</span>
            <select
              value={sort}
              onChange={(event) => setSort(event.target.value as (typeof sorts)[number]["id"])}
              className="w-full rounded-xl border border-gold-400/25 bg-forest-950/70 px-4 py-3 text-sm text-gold-50 outline-none transition focus:border-gold-300/70"
              aria-label="Sort the menu"
            >
              {sorts.map((option) => (
                <option key={option.id} value={option.id} className="bg-forest-950">
                  {option.label}
                </option>
              ))}
            </select>
          </label>
        </div>

        <div className="mt-5 flex flex-wrap items-center gap-2">
          <Chip active={category === "all"} onClick={() => switchCategory("all")}>
            All
          </Chip>
          {menuCategories.map((option) => (
            <Chip key={option} active={category === option} onClick={() => switchCategory(option)}>
              {option}
            </Chip>
          ))}
        </div>

        <div className="mt-4 flex flex-wrap items-center justify-between gap-3 border-t border-gold-400/10 pt-4">
          <label className="flex items-center gap-2 text-sm text-emerald-50/70">
            <input
              type="checkbox"
              checked={signatureOnly}
              onChange={(event) => setSignatureOnly(event.target.checked)}
              className="h-4 w-4 rounded border-gold-400/40 bg-forest-950 accent-gold-400"
            />
            Chef&apos;s signatures only
          </label>
          <p aria-live="polite" className="text-sm text-gold-200/80">
            {loading ? <Spinner label="Filtering" /> : `${results.length} dish${results.length === 1 ? "" : "es"}`}
          </p>
        </div>
      </div>

      <p className="mt-5 rounded-2xl border border-gold-400/20 bg-burgundy-700/25 px-4 py-3 text-xs leading-relaxed text-gold-100/85">
        <strong className="font-semibold">Price note:</strong> {priceDisclaimer}
      </p>

      {results.length === 0 ? (
        <div className="mt-12 rounded-3xl glass p-12 text-center">
          <p className="script gold-text text-3xl">Nothing on that plate</p>
          <p className="mt-3 text-sm text-emerald-50/65">
            No dish matches those filters. Try clearing the search, or ask the kitchen — Ayna adapts
            spice levels and can prepare off-menu vegetarian dishes on request.
          </p>
          <button
            type="button"
            className="btn-ghost mt-6"
            onClick={() => {
              setQuery("");
              setCategory("all");
              setDiet("all");
              setSignatureOnly(false);
            }}
          >
            Reset filters
          </button>
        </div>
      ) : grouped ? (
        <div className="mt-14 space-y-16">
          {grouped.map(([groupName, items]) => (
            <div key={groupName}>
              <div className="mb-6 flex items-baseline gap-4">
                <h3 className="font-[family-name:var(--font-cormorant)] text-3xl text-gold-100">{groupName}</h3>
                <span className="hairline flex-1" />
                <span className="text-xs uppercase tracking-[0.18em] text-emerald-50/40">
                  {items.length} dish{items.length === 1 ? "" : "es"}
                </span>
              </div>
              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                {items.map((item, i) => (
                  <DishCard key={item.slug} item={item} priority={i < 2} />
                ))}
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {results.map((item, i) => (
            <DishCard key={item.slug} item={item} priority={i < 3} />
          ))}
        </div>
      )}
    </div>
  );
}

function Chip({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={`rounded-full px-4 py-2 text-[0.68rem] uppercase tracking-[0.16em] transition ${
        active
          ? "bg-gold-400 text-forest-950 font-semibold"
          : "text-emerald-50/70 ring-1 ring-gold-400/25 hover:bg-gold-400/10 hover:text-gold-100"
      }`}
    >
      {children}
    </button>
  );
}
