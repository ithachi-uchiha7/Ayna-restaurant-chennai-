"use client";

import { useEffect, useState } from "react";

const KEY = "ayna.consent.v1";

export function CookieConsent() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    try {
      if (!window.localStorage.getItem(KEY)) {
        const timer = window.setTimeout(() => setVisible(true), 1200);
        return () => window.clearTimeout(timer);
      }
    } catch {
      /* storage blocked — do not nag */
    }
  }, []);

  const decide = (value: "all" | "essential") => {
    try {
      window.localStorage.setItem(KEY, JSON.stringify({ value, at: new Date().toISOString() }));
    } catch {
      /* ignore */
    }
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div
      role="dialog"
      aria-live="polite"
      aria-label="Cookie preferences"
      className="fixed inset-x-3 bottom-3 z-[80] mx-auto max-w-3xl rounded-2xl glass p-5 sm:inset-x-6"
    >
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="text-sm leading-relaxed text-emerald-50/80">
          <p className="font-medium text-gold-100">Cookies, kept minimal</p>
          <p className="mt-1 text-[0.8rem] text-emerald-50/60">
            This site uses one essential cookie to keep you signed in and local storage for your
            pre-order basket. No advertising or third-party tracking cookies are set.
          </p>
        </div>
        <div className="flex shrink-0 gap-2">
          <button type="button" className="btn-ghost !px-4 !py-2.5 !text-[0.65rem]" onClick={() => decide("essential")}>
            Essential only
          </button>
          <button type="button" className="btn-gold !px-4 !py-2.5 !text-[0.65rem]" onClick={() => decide("all")}>
            Accept
          </button>
        </div>
      </div>
    </div>
  );
}
