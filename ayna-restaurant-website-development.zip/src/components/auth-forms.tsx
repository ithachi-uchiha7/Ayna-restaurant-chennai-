"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { Field, inputClass, Spinner, StatusPanel } from "./ui";

type Errors = Record<string, string>;

/* ------------------------------- Login ------------------------------- */

export function LoginForm() {
  const router = useRouter();
  const [errors, setErrors] = useState<Errors>({});
  const [state, setState] = useState<"idle" | "loading" | "error">("idle");
  const [formError, setFormError] = useState<string | null>(null);

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    setState("loading");
    setErrors({});
    setFormError(null);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: String(data.get("email") ?? ""),
          password: String(data.get("password") ?? ""),
        }),
      });
      const payload = await res.json();
      if (!res.ok || !payload.ok) {
        setErrors(payload?.fields ?? {});
        setFormError(payload?.error ?? "Could not sign in.");
        setState("error");
        return;
      }
      router.replace(payload.user?.role === "admin" ? "/admin" : "/account");
      router.refresh();
    } catch {
      setFormError("Network error. Please try again.");
      setState("error");
    }
  }

  return (
    <form onSubmit={onSubmit} noValidate className="space-y-5">
      <Field label="E-mail" name="l-email" required error={errors.email}>
        <input id="l-email" name="email" type="email" autoComplete="email" required className={inputClass} />
      </Field>
      <Field label="Password" name="l-password" required error={errors.password}>
        <input
          id="l-password"
          name="password"
          type="password"
          autoComplete="current-password"
          required
          className={inputClass}
        />
      </Field>

      {formError ? <StatusPanel tone="error" title="Sign-in failed">{formError}</StatusPanel> : null}

      <button type="submit" className="btn-gold w-full" disabled={state === "loading"}>
        {state === "loading" ? <Spinner label="Signing in" /> : "Sign in"}
      </button>

      <div className="flex flex-wrap justify-between gap-3 text-xs text-emerald-50/55">
        <Link href="/forgot-password" className="text-gold-200/85 underline underline-offset-4">
          Forgot your password?
        </Link>
        <Link href="/register" className="text-gold-200/85 underline underline-offset-4">
          Create an account
        </Link>
      </div>
    </form>
  );
}

/* ------------------------------ Register ----------------------------- */

export function RegisterForm() {
  const router = useRouter();
  const [errors, setErrors] = useState<Errors>({});
  const [state, setState] = useState<"idle" | "loading" | "error">("idle");
  const [formError, setFormError] = useState<string | null>(null);

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    setState("loading");
    setErrors({});
    setFormError(null);
    try {
      const res = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          fullName: String(data.get("fullName") ?? ""),
          email: String(data.get("email") ?? ""),
          phone: String(data.get("phone") ?? ""),
          password: String(data.get("password") ?? ""),
          marketingOptIn: data.get("marketingOptIn") === "on",
        }),
      });
      const payload = await res.json();
      if (!res.ok || !payload.ok) {
        setErrors(payload?.fields ?? {});
        setFormError(payload?.error ?? "Could not create the account.");
        setState("error");
        return;
      }
      router.replace("/account");
      router.refresh();
    } catch {
      setFormError("Network error. Please try again.");
      setState("error");
    }
  }

  return (
    <form onSubmit={onSubmit} noValidate className="space-y-5">
      <Field label="Full name" name="r-name" required error={errors.fullName}>
        <input id="r-name" name="fullName" autoComplete="name" required className={inputClass} />
      </Field>
      <Field label="E-mail" name="r-email" required error={errors.email}>
        <input id="r-email" name="email" type="email" autoComplete="email" required className={inputClass} />
      </Field>
      <Field label="Phone" name="r-phone" error={errors.phone} hint="optional">
        <input id="r-phone" name="phone" type="tel" autoComplete="tel" className={inputClass} />
      </Field>
      <Field
        label="Password"
        name="r-password"
        required
        error={errors.password}
        hint="10+ chars, upper & lower case, a number"
      >
        <input
          id="r-password"
          name="password"
          type="password"
          autoComplete="new-password"
          required
          className={inputClass}
        />
      </Field>

      <label className="flex items-start gap-3 text-sm text-emerald-50/70">
        <input type="checkbox" name="marketingOptIn" className="mt-0.5 h-4 w-4 accent-gold-400" />
        Send me festival menus and event news (you can opt out any time).
      </label>

      {formError ? <StatusPanel tone="error" title="Registration failed">{formError}</StatusPanel> : null}

      <button type="submit" className="btn-gold w-full" disabled={state === "loading"}>
        {state === "loading" ? <Spinner label="Creating account" /> : "Create account"}
      </button>

      <p className="text-xs text-emerald-50/50">
        Already with us?{" "}
        <Link href="/login" className="text-gold-200/85 underline underline-offset-4">
          Sign in
        </Link>
      </p>
      <p className="text-[0.68rem] leading-relaxed text-emerald-50/40">
        Passwords are salted and hashed with scrypt; we never store them in plain text. Read the{" "}
        <Link href="/privacy" className="text-gold-200/85 underline underline-offset-4">
          privacy policy
        </Link>
        .
      </p>
    </form>
  );
}

/* --------------------------- Forgot password -------------------------- */

export function ForgotPasswordForm() {
  const [state, setState] = useState<"idle" | "loading" | "done" | "error">("idle");
  const [message, setMessage] = useState("");
  const [resetLink, setResetLink] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    setState("loading");
    setError(null);
    try {
      const res = await fetch("/api/auth/forgot-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: String(data.get("email") ?? "") }),
      });
      const payload = await res.json();
      if (!res.ok || !payload.ok) {
        setError(payload?.fields?.email ?? payload?.error ?? "Could not start recovery.");
        setState("error");
        return;
      }
      setMessage(payload.message);
      setResetLink(payload.resetLink ?? null);
      setState("done");
    } catch {
      setError("Network error. Please try again.");
      setState("error");
    }
  }

  if (state === "done") {
    return (
      <div className="space-y-5">
        <StatusPanel tone="success" title="Recovery started">
          <p>{message}</p>
          {resetLink ? (
            <p className="break-all rounded-xl bg-forest-950/60 px-3 py-2 text-xs">
              <a href={resetLink} className="text-gold-200 underline underline-offset-4">
                {resetLink}
              </a>
            </p>
          ) : null}
        </StatusPanel>
        <Link href="/login" className="btn-ghost">
          Back to sign in
        </Link>
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} noValidate className="space-y-5">
      <Field label="Account e-mail" name="f-email" required error={error ?? undefined}>
        <input id="f-email" name="email" type="email" autoComplete="email" required className={inputClass} />
      </Field>
      <button type="submit" className="btn-gold w-full" disabled={state === "loading"}>
        {state === "loading" ? <Spinner label="Checking" /> : "Send recovery link"}
      </button>
      <p className="text-[0.68rem] leading-relaxed text-emerald-50/45">
        Recovery links are single-use and expire after 60 minutes. If no e-mail provider is configured
        on this deployment, the link is shown here instead of being e-mailed.
      </p>
      <Link href="/login" className="block text-xs text-gold-200/85 underline underline-offset-4">
        Back to sign in
      </Link>
    </form>
  );
}

/* ---------------------------- Reset password -------------------------- */

export function ResetPasswordForm({ token }: { token: string }) {
  const router = useRouter();
  const [errors, setErrors] = useState<Errors>({});
  const [state, setState] = useState<"idle" | "loading" | "error">("idle");
  const [formError, setFormError] = useState<string | null>(null);

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    setState("loading");
    setErrors({});
    setFormError(null);
    try {
      const res = await fetch("/api/auth/reset-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          token,
          password: String(data.get("password") ?? ""),
        }),
      });
      const payload = await res.json();
      if (!res.ok || !payload.ok) {
        setErrors(payload?.fields ?? {});
        setFormError(payload?.error ?? "Could not reset the password.");
        setState("error");
        return;
      }
      router.replace("/account");
      router.refresh();
    } catch {
      setFormError("Network error. Please try again.");
      setState("error");
    }
  }

  if (!token) {
    return (
      <StatusPanel tone="error" title="Recovery token missing">
        <p>
          Open the recovery link from your e-mail, or{" "}
          <Link href="/forgot-password" className="text-gold-200 underline underline-offset-4">
            request a new link
          </Link>
          .
        </p>
      </StatusPanel>
    );
  }

  return (
    <form onSubmit={onSubmit} noValidate className="space-y-5">
      <Field
        label="New password"
        name="n-password"
        required
        error={errors.password}
        hint="10+ chars, upper & lower case, a number"
      >
        <input
          id="n-password"
          name="password"
          type="password"
          autoComplete="new-password"
          required
          className={inputClass}
        />
      </Field>
      {formError ? <StatusPanel tone="error" title="Reset failed">{formError}</StatusPanel> : null}
      <button type="submit" className="btn-gold w-full" disabled={state === "loading"}>
        {state === "loading" ? <Spinner label="Updating" /> : "Set new password"}
      </button>
    </form>
  );
}

/* ------------------------------- Profile ------------------------------ */

type ProfileUser = {
  id: number;
  email: string;
  fullName: string;
  phone: string | null;
  role: string;
  marketingOptIn: boolean;
  dietaryPreference: string | null;
  notes: string | null;
  createdAt: string;
};

export function ProfileForm({ user }: { user: ProfileUser }) {
  const router = useRouter();
  const [errors, setErrors] = useState<Errors>({});
  const [state, setState] = useState<"idle" | "loading" | "done" | "error">("idle");
  const [message, setMessage] = useState("");
  const [formError, setFormError] = useState<string | null>(null);

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    setState("loading");
    setErrors({});
    setFormError(null);
    try {
      const res = await fetch("/api/auth/profile", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          fullName: String(data.get("fullName") ?? ""),
          phone: String(data.get("phone") ?? ""),
          dietaryPreference: String(data.get("dietaryPreference") ?? "none"),
          marketingOptIn: data.get("marketingOptIn") === "on",
          notes: String(data.get("notes") ?? ""),
        }),
      });
      const payload = await res.json();
      if (!res.ok || !payload.ok) {
        setErrors(payload?.fields ?? {});
        setFormError(payload?.error ?? "Could not save your profile.");
        setState("error");
        return;
      }
      setMessage("Profile saved.");
      setState("done");
      router.refresh();
    } catch {
      setFormError("Network error. Please try again.");
      setState("error");
    }
  }

  return (
    <form onSubmit={onSubmit} noValidate className="space-y-5">
      <div className="grid gap-5 sm:grid-cols-2">
        <Field label="Full name" name="p-name" required error={errors.fullName}>
          <input
            id="p-name"
            name="fullName"
            defaultValue={user.fullName}
            required
            className={inputClass}
          />
        </Field>
        <Field label="Phone" name="p-phone" error={errors.phone} hint="optional">
          <input id="p-phone" name="phone" type="tel" defaultValue={user.phone ?? ""} className={inputClass} />
        </Field>
      </div>

      <Field label="E-mail" name="p-email" hint="cannot be changed here">
        <input id="p-email" value={user.email} readOnly disabled className={`${inputClass} opacity-60`} />
      </Field>

      <Field label="Dietary preference" name="p-diet" error={errors.dietaryPreference}>
        <select
          id="p-diet"
          name="dietaryPreference"
          defaultValue={user.dietaryPreference ?? "none"}
          className={inputClass}
        >
          {["none", "vegetarian", "vegan", "gluten-free", "halal", "jain", "other"].map((option) => (
            <option key={option} value={option} className="bg-forest-950">
              {option === "none" ? "Prefer not to say" : option}
            </option>
          ))}
        </select>
      </Field>

      <Field label="Standing notes for the restaurant" name="p-notes" error={errors.notes} hint="optional">
        <textarea
          id="p-notes"
          name="notes"
          rows={3}
          defaultValue={user.notes ?? ""}
          placeholder="Allergies, preferred table, usual time…"
          className={inputClass}
        />
      </Field>

      <label className="flex items-start gap-3 text-sm text-emerald-50/70">
        <input
          type="checkbox"
          name="marketingOptIn"
          defaultChecked={user.marketingOptIn}
          className="mt-0.5 h-4 w-4 accent-gold-400"
        />
        Keep me on the Ayna mailing list.
      </label>

      {state === "done" && message ? (
        <StatusPanel tone="success" title="Saved">{message}</StatusPanel>
      ) : null}
      {formError ? <StatusPanel tone="error" title="Not saved">{formError}</StatusPanel> : null}

      <button type="submit" className="btn-gold" disabled={state === "loading"}>
        {state === "loading" ? <Spinner label="Saving" /> : "Save profile"}
      </button>
    </form>
  );
}

export function LogoutButton({ className = "btn-ghost" }: { className?: string }) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);

  async function logout() {
    setBusy(true);
    await fetch("/api/auth/logout", { method: "POST" });
    router.replace("/");
    router.refresh();
  }

  return (
    <button type="button" onClick={logout} className={className} disabled={busy}>
      {busy ? <Spinner label="Signing out" /> : "Sign out"}
    </button>
  );
}
