"use client";

import { useState } from "react";
import { Field, inputClass, Spinner, StatusPanel } from "./ui";
import { ReserveButton, WhatsAppButton } from "./ui";
import { dinnerSlots } from "@/lib/hours";
import { useCart } from "./cart-provider";
import { formatINR } from "@/lib/menu-data";
import { summariseCart } from "@/lib/cart";

type Errors = Record<string, string>;

function today(): string {
  return new Date().toISOString().slice(0, 10);
}

function maxDate(): string {
  const d = new Date();
  d.setMonth(d.getMonth() + 6);
  return d.toISOString().slice(0, 10);
}

/* ------------------------------------------------------------------ *
 * Reservation ENQUIRY form (distinct from the external Google booking)
 * ------------------------------------------------------------------ */

export function ReservationForm() {
  const { summary } = useCart();
  const slots = dinnerSlots();
  const [errors, setErrors] = useState<Errors>({});
  const [state, setState] = useState<"idle" | "loading" | "done" | "error">("idle");
  const [result, setResult] = useState<{ reference: string; message: string } | null>(null);
  const [formError, setFormError] = useState<string | null>(null);
  const [ack, setAck] = useState(false);

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    setState("loading");
    setErrors({});
    setFormError(null);

    const items = summary.lines.map((line) => ({ slug: line.item.slug, qty: line.qty }));

    try {
      const res = await fetch("/api/reservations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          fullName: String(data.get("fullName") ?? ""),
          email: String(data.get("email") ?? ""),
          phone: String(data.get("phone") ?? ""),
          date: String(data.get("date") ?? ""),
          time: String(data.get("time") ?? ""),
          guests: Number(data.get("guests") ?? 2),
          occasion: String(data.get("occasion") ?? "none"),
          seating: String(data.get("seating") ?? "no-preference"),
          message: String(data.get("message") ?? ""),
          items,
          acknowledgeExternal: ack,
        }),
      });
      const payload = await res.json();
      if (!res.ok || !payload.ok) {
        setErrors(payload?.fields ?? {});
        setFormError(payload?.error ?? "Could not send the enquiry.");
        setState("error");
        return;
      }
      setResult({ reference: payload.reference, message: payload.message });
      setState("done");
    } catch {
      setFormError("Network error — please try again or call +91 44 2225 5555.");
      setState("error");
    }
  }

  if (state === "done" && result) {
    return (
      <div className="space-y-5">
        <StatusPanel tone="success" title={`Enquiry saved · reference ${result.reference}`}>
          <p>{result.message}</p>
          <p className="rounded-xl bg-forest-950/50 px-3 py-2 text-xs">
            <strong className="text-gold-200">This is not a confirmed booking.</strong> For an instant
            confirmation, use Ayna&apos;s official Google reservation page.
          </p>
        </StatusPanel>
        <div className="flex flex-wrap gap-3">
          <ReserveButton label="Open the Google booking page" />
          <WhatsAppButton
            message={`Hello Ayna! I just sent an enquiry (ref ${result.reference}). Could you confirm my table?`}
            label="Follow up on WhatsApp"
          />
        </div>
        <button type="button" className="btn-ghost" onClick={() => setState("idle")}>
          Send another enquiry
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} noValidate className="space-y-5">
      <div className="grid gap-5 sm:grid-cols-2">
        <Field label="Full name" name="fullName" required error={errors.fullName}>
          <input id="fullName" name="fullName" autoComplete="name" required className={inputClass} />
        </Field>
        <Field label="Phone" name="phone" required error={errors.phone}>
          <input id="phone" name="phone" type="tel" autoComplete="tel" required placeholder="+91 …" className={inputClass} />
        </Field>
      </div>

      <Field label="E-mail" name="email" required error={errors.email}>
        <input id="email" name="email" type="email" autoComplete="email" required className={inputClass} />
      </Field>

      <div className="grid gap-5 sm:grid-cols-3">
        <Field label="Date" name="date" required error={errors.date}>
          <input
            id="date"
            name="date"
            type="date"
            required
            min={today()}
            max={maxDate()}
            defaultValue={today()}
            className={inputClass}
          />
        </Field>
        <Field label="Time" name="time" required error={errors.time} hint="dinner service">
          <select id="time" name="time" required defaultValue="19:00" className={inputClass}>
            {slots.map((slot) => (
              <option key={slot} value={slot} className="bg-forest-950">
                {slot}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Guests" name="guests" required error={errors.guests}>
          <input
            id="guests"
            name="guests"
            type="number"
            min={1}
            max={40}
            defaultValue={2}
            required
            className={inputClass}
          />
        </Field>
      </div>

      <div className="grid gap-5 sm:grid-cols-2">
        <Field label="Occasion" name="occasion" error={errors.occasion}>
          <select id="occasion" name="occasion" defaultValue="none" className={inputClass}>
            {["none", "birthday", "anniversary", "business", "family", "date", "celebration", "other"].map((option) => (
              <option key={option} value={option} className="bg-forest-950">
                {option === "none" ? "Prefer not to say" : option}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Seating preference" name="seating" error={errors.seating}>
          <select id="seating" name="seating" defaultValue="no-preference" className={inputClass}>
            {["no-preference", "indoor", "private-dining", "window", "booth"].map((option) => (
              <option key={option} value={option} className="bg-forest-950">
                {option === "no-preference" ? "No preference" : option.replace("-", " ")}
              </option>
            ))}
          </select>
        </Field>
      </div>

      <Field label="Anything we should know?" name="message" error={errors.message} hint="optional">
        <textarea
          id="message"
          name="message"
          rows={4}
          placeholder="Dietary needs, cake, wheelchair access, high chair…"
          className={inputClass}
        />
      </Field>

      {summary.count > 0 ? (
        <p className="rounded-2xl border border-gold-400/25 bg-forest-950/60 px-4 py-3 text-sm text-gold-100/85">
          Your basket ({summary.count} item{summary.count === 1 ? "" : "s"}, indicative{" "}
          {formatINR(summary.indicativeTotal)}) will be attached to this enquiry as a pre-order note.
        </p>
      ) : null}

      <label className="flex items-start gap-3 rounded-2xl border border-gold-400/20 bg-forest-950/50 px-4 py-3 text-sm text-emerald-50/75">
        <input
          type="checkbox"
          checked={ack}
          onChange={(event) => setAck(event.target.checked)}
          className="mt-0.5 h-4 w-4 accent-gold-400"
          required
        />
        <span>
          I understand this sends an <strong className="text-gold-200">enquiry</strong> to the team via
          this website, and that only the official Google reservation page can confirm a table
          instantly.
        </span>
      </label>
      {errors.acknowledgeExternal ? (
        <p role="alert" className="text-xs text-rose-300">
          {errors.acknowledgeExternal}
        </p>
      ) : null}

      {formError ? <StatusPanel tone="error" title="We couldn't send that">{formError}</StatusPanel> : null}

      <div className="flex flex-wrap items-center gap-3">
        <button type="submit" className="btn-gold" disabled={state === "loading"}>
          {state === "loading" ? <Spinner label="Sending" /> : "Send enquiry"}
        </button>
        <span className="text-xs text-emerald-50/45">
          Or book instantly on Google — no waiting for a reply.
        </span>
      </div>
    </form>
  );
}

/* ------------------------------------------------------------------ *
 * Contact form
 * ------------------------------------------------------------------ */

export function ContactForm() {
  const [errors, setErrors] = useState<Errors>({});
  const [state, setState] = useState<"idle" | "loading" | "done" | "error">("idle");
  const [result, setResult] = useState<{ reference: string; message: string } | null>(null);
  const [formError, setFormError] = useState<string | null>(null);

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    setState("loading");
    setErrors({});
    setFormError(null);
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          fullName: String(data.get("fullName") ?? ""),
          email: String(data.get("email") ?? ""),
          phone: String(data.get("phone") ?? ""),
          topic: String(data.get("topic") ?? "general"),
          message: String(data.get("message") ?? ""),
        }),
      });
      const payload = await res.json();
      if (!res.ok || !payload.ok) {
        setErrors(payload?.fields ?? {});
        setFormError(payload?.error ?? "Could not send the message.");
        setState("error");
        return;
      }
      setResult({ reference: payload.reference, message: payload.message });
      setState("done");
    } catch {
      setFormError("Network error — please try WhatsApp on +91 95000 11940.");
      setState("error");
    }
  }

  if (state === "done" && result) {
    return (
      <div className="space-y-5">
        <StatusPanel tone="success" title={`Message received · reference ${result.reference}`}>
          <p>{result.message}</p>
        </StatusPanel>
        <WhatsAppButton message="Hello Ayna! I sent a message through your website." label="Continue on WhatsApp" />
        <button type="button" className="btn-ghost" onClick={() => setState("idle")}>
          Send another message
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} noValidate className="space-y-5">
      <div className="grid gap-5 sm:grid-cols-2">
        <Field label="Full name" name="c-fullName" required error={errors.fullName}>
          <input id="c-fullName" name="fullName" autoComplete="name" required className={inputClass} />
        </Field>
        <Field label="Phone" name="c-phone" error={errors.phone} hint="optional">
          <input id="c-phone" name="phone" type="tel" autoComplete="tel" className={inputClass} />
        </Field>
      </div>
      <Field label="E-mail" name="c-email" required error={errors.email}>
        <input id="c-email" name="email" type="email" autoComplete="email" required className={inputClass} />
      </Field>
      <Field label="Topic" name="c-topic" error={errors.topic}>
        <select id="c-topic" name="topic" defaultValue="general" className={inputClass}>
          {[
            ["general", "General question"],
            ["reservation", "Reservation help"],
            ["feedback", "Feedback about a visit"],
            ["private-dining", "Private dining"],
            ["press", "Press & media"],
            ["careers", "Careers"],
            ["accessibility", "Accessibility"],
          ].map(([value, label]) => (
            <option key={value} value={value} className="bg-forest-950">
              {label}
            </option>
          ))}
        </select>
      </Field>
      <Field label="Message" name="c-message" required error={errors.message}>
        <textarea id="c-message" name="message" rows={5} required className={inputClass} />
      </Field>

      {formError ? <StatusPanel tone="error" title="Message not sent">{formError}</StatusPanel> : null}

      <button type="submit" className="btn-gold" disabled={state === "loading"}>
        {state === "loading" ? <Spinner label="Sending" /> : "Send message"}
      </button>
      <p className="text-xs leading-relaxed text-emerald-50/45">
        We store your name, e-mail, optional phone number and message so the team can reply. See the{" "}
        <a href="/privacy" className="text-gold-200 underline underline-offset-4">
          privacy policy
        </a>
        .
      </p>
    </form>
  );
}

/* ------------------------------------------------------------------ *
 * Event / private dining enquiry
 * ------------------------------------------------------------------ */

export function EventForm() {
  const [errors, setErrors] = useState<Errors>({});
  const [state, setState] = useState<"idle" | "loading" | "done" | "error">("idle");
  const [result, setResult] = useState<{ reference: string; message: string } | null>(null);
  const [formError, setFormError] = useState<string | null>(null);

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    setState("loading");
    setErrors({});
    setFormError(null);
    try {
      const res = await fetch("/api/events", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          fullName: String(data.get("fullName") ?? ""),
          email: String(data.get("email") ?? ""),
          phone: String(data.get("phone") ?? ""),
          eventType: String(data.get("eventType") ?? "other"),
          preferredDate: String(data.get("preferredDate") ?? ""),
          guests: Number(data.get("guests") ?? 10),
          budget: String(data.get("budget") ?? "unsure"),
          message: String(data.get("message") ?? ""),
        }),
      });
      const payload = await res.json();
      if (!res.ok || !payload.ok) {
        setErrors(payload?.fields ?? {});
        setFormError(payload?.error ?? "Could not send the enquiry.");
        setState("error");
        return;
      }
      setResult({ reference: payload.reference, message: payload.message });
      setState("done");
    } catch {
      setFormError("Network error — please call +91 44 2225 5555.");
      setState("error");
    }
  }

  if (state === "done" && result) {
    return (
      <div className="space-y-5">
        <StatusPanel tone="success" title={`Enquiry saved · reference ${result.reference}`}>
          <p>{result.message}</p>
        </StatusPanel>
        <button type="button" className="btn-ghost" onClick={() => setState("idle")}>
          Send another enquiry
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} noValidate className="space-y-5">
      <div className="grid gap-5 sm:grid-cols-2">
        <Field label="Full name" name="e-fullName" required error={errors.fullName}>
          <input id="e-fullName" name="fullName" required autoComplete="name" className={inputClass} />
        </Field>
        <Field label="Phone" name="e-phone" required error={errors.phone}>
          <input id="e-phone" name="phone" type="tel" required autoComplete="tel" className={inputClass} />
        </Field>
      </div>
      <Field label="E-mail" name="e-email" required error={errors.email}>
        <input id="e-email" name="email" type="email" required autoComplete="email" className={inputClass} />
      </Field>
      <div className="grid gap-5 sm:grid-cols-3">
        <Field label="Event type" name="e-type" error={errors.eventType}>
          <select id="e-type" name="eventType" defaultValue="family-gathering" className={inputClass}>
            {[
              ["birthday", "Birthday"],
              ["anniversary", "Anniversary"],
              ["corporate-dinner", "Corporate dinner"],
              ["family-gathering", "Family gathering"],
              ["wedding-related", "Wedding-related"],
              ["other", "Something else"],
            ].map(([value, label]) => (
              <option key={value} value={value} className="bg-forest-950">
                {label}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Preferred date" name="e-date" error={errors.preferredDate} hint="optional">
          <input id="e-date" name="preferredDate" type="date" min={today()} className={inputClass} />
        </Field>
        <Field label="Guests" name="e-guests" required error={errors.guests}>
          <input id="e-guests" name="guests" type="number" min={2} max={200} defaultValue={12} required className={inputClass} />
        </Field>
      </div>
      <Field label="Indicative budget" name="e-budget" error={errors.budget}>
        <select id="e-budget" name="budget" defaultValue="unsure" className={inputClass}>
          {[
            ["unsure", "Not sure yet"],
            ["under-25k", "Under ₹25,000"],
            ["25k-50k", "₹25,000 – ₹50,000"],
            ["50k-100k", "₹50,000 – ₹1,00,000"],
            ["100k-plus", "₹1,00,000+"],
          ].map(([value, label]) => (
            <option key={value} value={value} className="bg-forest-950">
              {label}
            </option>
          ))}
        </select>
      </Field>
      <Field label="Tell us about the occasion" name="e-message" error={errors.message} hint="optional">
        <textarea id="e-message" name="message" rows={4} className={inputClass} />
      </Field>

      {formError ? <StatusPanel tone="error" title="Not sent">{formError}</StatusPanel> : null}

      <button type="submit" className="btn-gold" disabled={state === "loading"}>
        {state === "loading" ? <Spinner label="Sending" /> : "Request a callback"}
      </button>
      <p className="text-xs leading-relaxed text-emerald-50/45">
        A private dining area is listed for Ayna on Tripadvisor and Justdial. This form logs your
        enquiry for the hotel team; it does not confirm a booking or a price.
      </p>
    </form>
  );
}

/* ------------------------------------------------------------------ *
 * Pre-order / checkout form (used on /order and /checkout)
 * ------------------------------------------------------------------ */

export function PreOrderForm({ mode = "checkout" }: { mode?: "checkout" | "order" }) {
  const { summary, clear, ready } = useCart();
  const [errors, setErrors] = useState<Errors>({});
  const [state, setState] = useState<"idle" | "loading" | "done" | "error">("idle");
  const [result, setResult] = useState<{ reference: string; indicativeTotal: number; message: string } | null>(null);
  const [formError, setFormError] = useState<string | null>(null);

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    setState("loading");
    setErrors({});
    setFormError(null);
    try {
      const res = await fetch("/api/preorders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          fullName: String(data.get("fullName") ?? ""),
          email: String(data.get("email") ?? ""),
          phone: String(data.get("phone") ?? ""),
          serviceType: String(data.get("serviceType") ?? "dine-in-preorder"),
          preferredDate: String(data.get("preferredDate") ?? ""),
          preferredTime: String(data.get("preferredTime") ?? ""),
          guests: data.get("guests") ? Number(data.get("guests")) : undefined,
          notes: String(data.get("notes") ?? ""),
          items: summary.lines.map((line) => ({ slug: line.item.slug, qty: line.qty })),
        }),
      });
      const payload = await res.json();
      if (!res.ok || !payload.ok) {
        setErrors(payload?.fields ?? {});
        setFormError(payload?.error ?? "Could not submit the pre-order.");
        setState("error");
        return;
      }
      setResult({
        reference: payload.reference,
        indicativeTotal: payload.indicativeTotal,
        message: payload.message,
      });
      clear();
      setState("done");
    } catch {
      setFormError("Network error — please try again.");
      setState("error");
    }
  }

  if (state === "done" && result) {
    return (
      <div className="space-y-5">
        <StatusPanel tone="success" title={`Pre-order received · reference ${result.reference}`}>
          <p>{result.message}</p>
          <p>
            Indicative total attached: <strong className="text-gold-200">{formatINR(result.indicativeTotal)}</strong>{" "}
            (no payment was taken; the bill is settled at the restaurant).
          </p>
        </StatusPanel>
        <div className="flex flex-wrap gap-3">
          <WhatsAppButton
            message={`Hello Ayna! I submitted pre-order ${result.reference}. Please confirm it for me.`}
            label="Confirm on WhatsApp"
          />
          <a href="/menu" className="btn-ghost">
            Back to the menu
          </a>
        </div>
      </div>
    );
  }

  if (ready && summary.count === 0) {
    return (
      <div className="rounded-3xl glass p-8 text-center">
        <p className="script gold-text text-3xl">Your basket is empty</p>
        <p className="mx-auto mt-3 max-w-md text-sm text-emerald-50/65">
          Add dishes from the menu and they will appear here with quantities and an indicative total.
        </p>
        <a href="/menu" className="btn-gold mt-6 inline-flex">
          Browse the menu
        </a>
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} noValidate className="space-y-5">
      <div className="grid gap-5 sm:grid-cols-2">
        <Field label="Full name" name="o-fullName" required error={errors.fullName}>
          <input id="o-fullName" name="fullName" required autoComplete="name" className={inputClass} />
        </Field>
        <Field label="Phone" name="o-phone" required error={errors.phone}>
          <input id="o-phone" name="phone" type="tel" required autoComplete="tel" className={inputClass} />
        </Field>
      </div>
      <Field label="E-mail" name="o-email" required error={errors.email}>
        <input id="o-email" name="email" type="email" required autoComplete="email" className={inputClass} />
      </Field>
      <Field label="This pre-order is for" name="o-type" error={errors.serviceType}>
        <select id="o-type" name="serviceType" defaultValue="dine-in-preorder" className={inputClass}>
          <option value="dine-in-preorder" className="bg-forest-950">
            Dine-in pre-order (kitchen starts early)
          </option>
          <option value="takeaway-enquiry" className="bg-forest-950">
            Takeaway enquiry (restaurant arranges)
          </option>
        </select>
      </Field>
      <div className="grid gap-5 sm:grid-cols-3">
        <Field label="Date" name="o-date" error={errors.preferredDate} hint="optional">
          <input id="o-date" name="preferredDate" type="date" min={today()} className={inputClass} />
        </Field>
        <Field label="Time" name="o-time" error={errors.preferredTime} hint="optional">
          <select id="o-time" name="preferredTime" defaultValue="" className={inputClass}>
            <option value="" className="bg-forest-950">
              Not decided
            </option>
            {dinnerSlots().map((slot) => (
              <option key={slot} value={slot} className="bg-forest-950">
                {slot}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Guests" name="o-guests" error={errors.guests} hint="optional">
          <input id="o-guests" name="guests" type="number" min={1} max={40} className={inputClass} />
        </Field>
      </div>
      <Field label="Notes for the kitchen" name="o-notes" error={errors.notes} hint="optional">
        <textarea id="o-notes" name="notes" rows={3} className={inputClass} />
      </Field>

      {formError ? <StatusPanel tone="error" title="Not submitted">{formError}</StatusPanel> : null}

      <button type="submit" className="btn-gold w-full" disabled={state === "loading"}>
        {state === "loading" ? <Spinner label="Submitting" /> : mode === "checkout" ? "Submit pre-order" : "Send to the kitchen"}
      </button>
      <p className="text-xs leading-relaxed text-emerald-50/50">
        No card details are requested or stored — this project does not integrate a payment gateway.
        Delivery orders should be placed on Ayna&apos;s official Zomato listing.
      </p>
    </form>
  );
}
