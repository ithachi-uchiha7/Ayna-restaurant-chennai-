"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { menu, type MenuItem } from "@/lib/menu-data";
import { emptyCartSummary, summariseCart, type CartSummary } from "@/lib/cart";

const STORAGE_KEY = "ayna.cart.v1";

type CartContextValue = {
  summary: CartSummary;
  ready: boolean;
  lastAdded: string | null;
  add: (slug: string, qty?: number) => void;
  setQty: (slug: string, qty: number) => void;
  remove: (slug: string) => void;
  clear: () => void;
  qtyOf: (slug: string) => number;
  itemBySlug: (slug: string) => MenuItem | undefined;
};

const CartContext = createContext<CartContextValue | null>(null);

function readStorage(): { slug: string; qty: number }[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed
      .filter((entry): entry is { slug: string; qty: number } => {
        if (typeof entry !== "object" || entry === null) return false;
        const candidate = entry as Record<string, unknown>;
        return typeof candidate.slug === "string" && typeof candidate.qty === "number";
      })
      .filter((entry) => menu.some((item) => item.slug === entry.slug));
  } catch {
    return [];
  }
}

export function CartProvider({ children }: { children: ReactNode }) {
  const [lines, setLines] = useState<{ slug: string; qty: number }[]>([]);
  const [ready, setReady] = useState(false);
  const [lastAdded, setLastAdded] = useState<string | null>(null);

  useEffect(() => {
    setLines(readStorage());
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready) return;
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(lines));
    } catch {
      /* storage disabled — cart stays in memory only */
    }
  }, [lines, ready]);

  useEffect(() => {
    if (!lastAdded) return;
    const timer = window.setTimeout(() => setLastAdded(null), 2600);
    return () => window.clearTimeout(timer);
  }, [lastAdded]);

  const add = useCallback((slug: string, qty = 1) => {
    setLines((prev) => {
      const existing = prev.find((line) => line.slug === slug);
      if (existing) {
        const next = existing.qty + qty;
        if (next <= 0) return prev.filter((line) => line.slug !== slug);
        return prev.map((line) => (line.slug === slug ? { ...line, qty: Math.min(50, next) } : line));
      }
      return [...prev, { slug, qty: Math.min(50, Math.max(1, qty)) }];
    });
    setLastAdded(slug);
  }, []);

  const setQty = useCallback((slug: string, qty: number) => {
    setLines((prev) =>
      qty <= 0
        ? prev.filter((line) => line.slug !== slug)
        : prev.map((line) => (line.slug === slug ? { ...line, qty: Math.min(50, qty) } : line)),
    );
  }, []);

  const remove = useCallback((slug: string) => {
    setLines((prev) => prev.filter((line) => line.slug !== slug));
  }, []);

  const clear = useCallback(() => setLines([]), []);

  const value = useMemo<CartContextValue>(() => {
    const summary = ready ? summariseCart(lines) : emptyCartSummary();
    return {
      summary,
      ready,
      lastAdded,
      add,
      setQty,
      remove,
      clear,
      qtyOf: (slug: string) => lines.find((line) => line.slug === slug)?.qty ?? 0,
      itemBySlug: (slug: string) => menu.find((item) => item.slug === slug),
    };
  }, [lines, ready, lastAdded, add, setQty, remove, clear]);

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart(): CartContextValue {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart must be used inside <CartProvider>");
  return ctx;
}
