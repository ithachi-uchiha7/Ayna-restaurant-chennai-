"use client";

import { useState } from "react";
import { useCart } from "./cart-provider";
import { TiltCard } from "./motion";
import { dietBadgeClass, dietaryLabels, formatINR, type MenuItem } from "@/lib/menu-data";
import { AiImageChip, SourceNote } from "./ui";

const dishImages: Record<string, string> = {
  "dal-ayna": "/images/dish-dal-ayna.jpg",
  "kacche-gosht-ki-biryani": "/images/dish-biryani.jpg",
  "tandoori-kasundi-jheenga": "/images/dish-seafood.jpg",
  "sakora-phirni": "/images/dish-dessert.jpg",
};

export function SpiceMeter({ level }: { level: number }) {
  return (
    <span className="inline-flex items-center gap-0.5" aria-label={`Spice level ${level} of 3`}>
      {[1, 2, 3].map((n) => (
        <span
          key={n}
          aria-hidden
          className={`h-1.5 w-1.5 rounded-full ${n <= level ? "bg-rose-400" : "bg-emerald-50/15"}`}
        />
      ))}
    </span>
  );
}

export function DishCard({ item, priority = false }: { item: MenuItem; priority?: boolean }) {
  const { add, qtyOf, lastAdded } = useCart();
  const [expanded, setExpanded] = useState(false);
  const qty = qtyOf(item.slug);
  const image = dishImages[item.slug] ?? "/images/hero-interior.jpg";

  return (
    <TiltCard className="h-full rounded-3xl" intensity={5}>
      <article className="flex h-full flex-col overflow-hidden rounded-3xl glass">
        <div className="relative h-44 overflow-hidden">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={image}
            alt={`AI-generated illustration representing ${item.name}`}
            loading={priority ? "eager" : "lazy"}
            decoding="async"
            className="h-full w-full object-cover transition duration-[1200ms] hover:scale-110"
          />
          <AiImageChip />
          <div
            aria-hidden
            className="absolute inset-0 bg-gradient-to-t from-forest-950 via-forest-950/25 to-transparent"
          />
          <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between gap-2">
            <span className={`rounded-full px-2.5 py-1 text-[0.6rem] font-semibold uppercase tracking-widest ring-1 ${dietBadgeClass(item.diet)}`}>
              {dietaryLabels[item.diet]}
            </span>
            {item.signature ? (
              <span className="rounded-full bg-gold-400/90 px-2.5 py-1 text-[0.6rem] font-bold uppercase tracking-widest text-forest-950">
                Signature
              </span>
            ) : null}
          </div>
        </div>

        <div className="flex flex-1 flex-col p-5">
          <div className="flex items-start justify-between gap-3">
            <h3 className="text-xl leading-snug text-gold-50">{item.name}</h3>
            <div className="text-right">
              <p className="font-display text-lg text-gold-200">{formatINR(item.price)}</p>
              <p className="text-[0.58rem] uppercase tracking-widest text-emerald-50/35">Indicative</p>
            </div>
          </div>

          <p className="mt-1 text-[0.68rem] uppercase tracking-[0.16em] text-emerald-50/45">
            {item.region} · <SpiceMeter level={item.spice} />
          </p>

          <p className={`mt-3 text-sm leading-relaxed text-emerald-50/70 ${expanded ? "" : "line-clamp-3"}`}>
            {item.description}
          </p>

          <button
            type="button"
            onClick={() => setExpanded((v) => !v)}
            className="mt-2 self-start text-[0.68rem] uppercase tracking-[0.18em] text-gold-300/80 transition hover:text-gold-100"
            aria-expanded={expanded}
          >
            {expanded ? "Less" : "More + source"}
          </button>

          {expanded ? (
            <div className="mt-3 space-y-2">
              <SourceNote>{item.source}</SourceNote>
            </div>
          ) : null}

          <div className="mt-5 flex items-center gap-2">
            {qty > 0 ? (
              <div className="flex flex-1 items-center justify-between rounded-full ring-1 ring-gold-400/40">
                <QtyButton slug={item.slug} delta={-1} />
                <span className="min-w-8 text-center text-sm font-semibold text-gold-100">{qty}</span>
                <QtyButton slug={item.slug} delta={1} />
              </div>
            ) : (
              <button
                type="button"
                onClick={() => add(item.slug)}
                className="btn-gold flex-1 !px-4 !py-2.5 !text-[0.65rem]"
              >
                {lastAdded === item.slug ? "Added ✓" : "Add to pre-order"}
              </button>
            )}
          </div>
        </div>
      </article>
    </TiltCard>
  );
}

function QtyButton({ slug, delta }: { slug: string; delta: number }) {
  const { add } = useCart();
  return (
    <button
      type="button"
      onClick={() => add(slug, delta)}
      className="grid h-9 w-9 place-items-center rounded-full text-lg text-gold-100 transition hover:bg-gold-400/15"
      aria-label={delta > 0 ? "Increase quantity" : "Decrease quantity"}
    >
      {delta > 0 ? "+" : "−"}
    </button>
  );
}
