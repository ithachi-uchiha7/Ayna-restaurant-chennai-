import Link from "next/link";
import { SiteHeader } from "./site-header";
import { CookieConsent } from "./cookie-consent";
import { NewsletterForm } from "./newsletter-form";
import { ScrollProgress } from "./motion";
import { WhatsAppButton } from "./ui";
import { address, contact, externalLinks, hoursSummary, site } from "@/lib/site-config";

const columns: { title: string; links: { href: string; label: string }[] }[] = [
  {
    title: "Explore",
    links: [
      { href: "/about", label: "About Ayna" },
      { href: "/menu", label: "Full menu" },
      { href: "/specials", label: "Specials & signatures" },
      { href: "/gallery", label: "Gallery" },
      { href: "/venue", label: "Venue & facilities" },
    ],
  },
  {
    title: "Plan your visit",
    links: [
      { href: "/reservations", label: "Reservations" },
      { href: "/events", label: "Events & private dining" },
      { href: "/visit", label: "Hours, map & directions" },
      { href: "/faq", label: "FAQ" },
      { href: "/order", label: "Delivery & pre-order" },
    ],
  },
  {
    title: "Guests",
    links: [
      { href: "/reviews", label: "Guest reviews" },
      { href: "/account", label: "My account" },
      { href: "/cart", label: "Pre-order basket" },
      { href: "/contact", label: "Contact us" },
      { href: "/admin", label: "Team dashboard" },
    ],
  },
  {
    title: "Legal",
    links: [
      { href: "/privacy", label: "Privacy policy" },
      { href: "/terms", label: "Terms of use" },
      { href: "/faq#cookies", label: "Cookie notice" },
      { href: "/faq#accessibility", label: "Accessibility" },
    ],
  },
];

export function SiteFooter() {
  return (
    <>
      <SiteHeader />
      <ScrollProgress />
      <footer className="relative overflow-hidden border-t border-gold-400/15 bg-forest-950">
        <div
          aria-hidden
          className="pointer-events-none absolute -left-32 -top-40 h-96 w-96 rounded-full opacity-25 blur-3xl"
          style={{ background: "radial-gradient(circle, #1b5b3c, transparent 70%)" }}
        />
        <div className="relative mx-auto max-w-7xl px-5 py-16 lg:px-8">
          <div className="grid gap-12 lg:grid-cols-[1.3fr_2fr]">
            <div>
              <p className="script gold-text text-4xl">{site.name}</p>
              <p className="mt-3 max-w-sm text-sm leading-relaxed text-emerald-50/65">
                {site.shortDescription}
              </p>

              <address className="mt-6 space-y-1 text-sm not-italic text-emerald-50/70">
                <p className="text-gold-100">{address.line1}</p>
                <p>{address.line2}</p>
                <p>
                  {address.line3}, {address.city} {address.postalCode}
                </p>
                <p>{address.state}, {address.country}</p>
              </address>

              <div className="mt-5 space-y-1.5 text-sm">
                <a href={contact.hotelPhoneHref} className="block text-gold-100 transition hover:text-gold-300">
                  {contact.hotelPhoneDisplay} <span className="text-emerald-50/45">(Hilton Chennai)</span>
                </a>
                <a href={contact.restaurantPhoneHref} className="block text-gold-100 transition hover:text-gold-300">
                  {contact.restaurantPhoneDisplay} <span className="text-emerald-50/45">(restaurant line)</span>
                </a>
                <WhatsAppButton message="Hello Ayna! I'd like to check availability for dinner." />
              </div>

              <div className="mt-6 grid gap-1 text-sm text-emerald-50/60">
                {hoursSummary.map((row) => (
                  <p key={row.label}>
                    <span className="text-gold-200/70">{row.label}:</span> {row.value}
                  </p>
                ))}
              </div>

              {contact.email ? (
                <a href={`mailto:${contact.email}`} className="mt-3 inline-block text-sm text-gold-100">
                  {contact.email}
                </a>
              ) : (
                <p className="mt-3 max-w-sm text-xs leading-relaxed text-emerald-50/45">
                  {contact.emailNote}
                </p>
              )}
            </div>

            <div className="grid gap-10 sm:grid-cols-2 lg:grid-cols-4">
              {columns.map((column) => (
                <div key={column.title}>
                  <p className="eyebrow mb-4">{column.title}</p>
                  <ul className="space-y-2.5">
                    {column.links.map((link) => (
                      <li key={link.href + link.label}>
                        <Link
                          href={link.href}
                          className="text-sm text-emerald-50/65 transition hover:text-gold-200"
                        >
                          {link.label}
                        </Link>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-14 grid gap-8 rounded-3xl glass p-7 lg:grid-cols-[1fr_1fr]">
            <div>
              <p className="script gold-text text-2xl">Ayna letters</p>
              <p className="mt-2 text-sm text-emerald-50/65">
                Festival menus, chef&apos;s tables and seasonal seafood nights — straight to your inbox.
              </p>
              <div className="mt-4 flex flex-wrap gap-3 text-xs">
                <a
                  href={externalLinks.tripadvisor}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="rounded-full px-3 py-1.5 ring-1 ring-gold-400/30 transition hover:bg-gold-400/10"
                >
                  Tripadvisor ↗
                </a>
                <a
                  href={externalLinks.zomato}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="rounded-full px-3 py-1.5 ring-1 ring-gold-400/30 transition hover:bg-gold-400/10"
                >
                  Zomato ↗
                </a>
                <a
                  href={externalLinks.justdial}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="rounded-full px-3 py-1.5 ring-1 ring-gold-400/30 transition hover:bg-gold-400/10"
                >
                  Justdial ↗
                </a>
                <a
                  href={externalLinks.hiltonDining}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="rounded-full px-3 py-1.5 ring-1 ring-gold-400/30 transition hover:bg-gold-400/10"
                >
                  Hilton Chennai ↗
                </a>
              </div>
              <p className="mt-4 text-[0.68rem] leading-relaxed text-emerald-50/40">
                Ayna does not publish verified Instagram or Facebook accounts, so we link only to
                platforms listed above rather than inventing handles.
              </p>
            </div>
            <NewsletterForm source="footer" />
          </div>

          <div className="mt-10 flex flex-col gap-4 border-t border-gold-400/10 pt-7 text-xs text-emerald-50/45 sm:flex-row sm:items-center sm:justify-between">
            <p>
              © {new Date().getFullYear()} {site.legalName}. An independent guide built with care —
              not owned or operated by Hilton.
            </p>
            <p className="flex flex-wrap items-center gap-x-4 gap-y-2">
              <span>Imagery on this site is AI-generated and labelled as such.</span>
              <Link href="/privacy" className="text-gold-200/70 transition hover:text-gold-100">
                Privacy
              </Link>
              <Link href="/terms" className="text-gold-200/70 transition hover:text-gold-100">
                Terms
              </Link>
            </p>
          </div>
        </div>
      </footer>
      <CookieConsent />
    </>
  );
}
