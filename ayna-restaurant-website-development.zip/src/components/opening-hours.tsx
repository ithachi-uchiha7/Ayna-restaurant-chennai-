"use client";

import { useEffect, useState } from "react";
import { computeOpenStatus, formatMinutes, toIstInstant, weekOrder, dayName } from "@/lib/hours";
import { hourNotes, openingHours } from "@/lib/site-config";

export function OpeningHoursTable({ showNotes = true }: { showNotes?: boolean }) {
  const [now, setNow] = useState<Date | null>(null);
  const [istClock, setIstClock] = useState("");

  useEffect(() => {
    const tick = () => {
      const date = new Date();
      setNow(date);
      const { day, minutes } = toIstInstant(date);
      const h = Math.floor(minutes / 60);
      const m = minutes % 60;
      setIstClock(`${dayName(day)} · ${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")} IST`);
    };
    tick();
    const timer = window.setInterval(tick, 15_000);
    return () => window.clearInterval(timer);
  }, []);

  const status = computeOpenStatus(now ?? new Date());

  return (
    <div className="rounded-3xl glass p-7">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <p className="script gold-text text-2xl">Opening hours</p>
        {now ? (
          <span
            className={`inline-flex items-center gap-2 rounded-full px-3 py-1.5 text-xs font-medium ring-1 ${
              status.isOpen
                ? "bg-emerald-500/10 text-emerald-200 ring-emerald-400/30"
                : "bg-rose-500/10 text-rose-200 ring-rose-400/25"
            }`}
          >
            <span aria-hidden className={`h-2 w-2 rounded-full ${status.isOpen ? "bg-emerald-400" : "bg-rose-400"}`} />
            {status.label} · {status.detail}
          </span>
        ) : (
          <span className="text-xs text-gold-200/60">Reading your local time…</span>
        )}
      </div>

      {istClock ? <p className="mt-1 text-xs text-emerald-50/45">Restaurant time · {istClock}</p> : null}

      <table className="mt-6 w-full text-sm">
        <caption className="sr-only">Ayna opening hours by day of week, in Indian Standard Time</caption>
        <thead>
          <tr className="text-left text-[0.6rem] uppercase tracking-[0.2em] text-emerald-50/45">
            <th scope="col" className="pb-3">Day</th>
            <th scope="col" className="pb-3">Services</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gold-400/10">
          {weekOrder.map((day) => {
            const isToday = now ? toIstInstant(now).day === day : false;
            return (
              <tr key={day} className={isToday ? "bg-gold-400/8" : ""}>
                <th scope="row" className="py-3 text-left align-top">
                  <span className="text-gold-100">{dayName(day)}</span>
                  {isToday ? <span className="ml-2 text-[0.6rem] uppercase tracking-widest text-gold-300">today</span> : null}
                </th>
                <td className="py-3">
                  {(openingHours[day] ?? []).map((window) => (
                    <p key={window.id} className="text-emerald-50/72">
                      {window.label} {formatMinutes(window.opens)} – {formatMinutes(window.closes)}
                      {window.historic ? (
                        <span className="ml-2 rounded bg-gold-400/12 px-1.5 py-0.5 text-[0.55rem] uppercase tracking-widest text-gold-200/80">
                          historically listed
                        </span>
                      ) : null}
                    </p>
                  ))}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>

      {showNotes ? (
        <ul className="mt-6 space-y-2 text-xs leading-relaxed text-emerald-50/50">
          {hourNotes.map((note) => (
            <li key={note} className="flex gap-2">
              <span aria-hidden className="text-gold-300">•</span>
              {note}
            </li>
          ))}
        </ul>
      ) : null}
    </div>
  );
}
