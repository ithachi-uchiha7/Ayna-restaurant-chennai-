"use client";

import Link from "next/link";
import { useCart } from "./cart-provider";
import { formatINR, priceDisclaimer } from "@/lib/menu-data";
import { SpiceMeter } from "./dish-card";
import { DeliveryButton, Spinner, StatusPanel } from "./ui";

export function CartView({ children }: { children?: React.ReactNode }) {
  const { summary, setQty, remove, clear, ready } = useCart();

  if (!ready) {
    return (
      <div className="rounded-3xl glass p-10 text-center">
        <Spinner label="Loading your basket" />
      </div>
    );
  }

  if (summary.count === 0) {
    return (
      <div className="rounded-3xl glass p-12 text-center">
        <p className="script gold-text text-4xl">Nothing here yet</p>
        <p className="mx-auto mt-4 max-w-lg text-sm leading-relaxed text-emerald-50/65">
          Your pre-order basket is empty. Add dishes from the menu — you can send them to the kitchen
          ahead of your reservation, or order delivery through Ayna&apos;s official Zomato listing.
        </p>
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <Link href="/menu" className="btn-gold">
            Browse the menu
          </Link>
          <DeliveryButton />
        </div>
      </div>
    );
  }

  return (
    <div className="grid gap-6 lg:grid-cols-[1.5fr_1fr]">
      <div className="space-y-4">
        {summary.lines.map((entry) => (
          <article key={entry.item.slug} className="flex gap-4 rounded-3xl glass p-4">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src="/images/dish-kebab-platter.jpg"
              alt={`AI-generated illustration representing ${entry.item.name}`}
              loading="lazy"
              className="h-24 w-24 shrink-0 rounded-2xl object-cover"
            />
            <div className="flex flex-1 flex-col">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h3 className="font-[family-name:var(--font-cormorant)] text-xl leading-snug text-gold-50">
                    {entry.item.name}
                  </h3>
                  <p className="mt-1 flex items-center gap-3 text-[0.68rem] uppercase tracking-[0.14em] text-emerald-50/45">
                    {entry.item.region}
                    <SpiceMeter level={entry.item.spice} />
                  </p>
                </div>
                <p className="shrink-0 text-right">
                  <span className="block font-[family-name:var(--font-cormorant)] text-lg text-gold-200">
                    {formatINR(entry.lineTotal)}
                  </span>
                  <span className="text-[0.55rem] uppercase tracking-widest text-emerald-50/35">
                    {formatINR(entry.item.price)} each
                  </span>
                </p>
              </div>

              <div className="mt-auto flex items-center justify-between gap-3 pt-3">
                <div className="flex items-center gap-1 rounded-full ring-1 ring-gold-400/35">
                  <button
                    type="button"
                    onClick={() => setQty(entry.item.slug, entry.qty - 1)}
                    className="grid h-9 w-9 place-items-center rounded-full text-lg text-gold-100 transition hover:bg-gold-400/15"
                    aria-label={`Decrease ${entry.item.name}`}
                  >
                    −
                  </button>
                  <span className="min-w-7 text-center text-sm font-semibold text-gold-100">{entry.qty}</span>
                  <button
                    type="button"
                    onClick={() => setQty(entry.item.slug, entry.qty + 1)}
                    className="grid h-9 w-9 place-items-center rounded-full text-lg text-gold-100 transition hover:bg-gold-400/15"
                    aria-label={`Increase ${entry.item.name}`}
                  >
                    +
                  </button>
                </div>
                <button
                  type="button"
                  onClick={() => remove(entry.item.slug)}
                  className="text-xs uppercase tracking-[0.16em] text-rose-300/80 transition hover:text-rose-200"
                >
                  Remove
                </button>
              </div>
            </div>
          </article>
        ))}

        <button
          type="button"
          onClick={clear}
          className="text-xs uppercase tracking-[0.18em] text-emerald-50/45 transition hover:text-rose-300"
        >
          Empty the basket
        </button>
      </div>

      <aside className="lg:sticky lg:top-28 lg:self-start">
        <div className="rounded-3xl glass p-6">
          <p className="script gold-text text-2xl">Order summary</p>
          <dl className="mt-5 space-y-2 text-sm">
            <div className="flex justify-between">
              <dt className="text-emerald-50/65">Dishes</dt>
              <dd className="text-gold-100">{summary.count}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-emerald-50/65">Vegetarian</dt>
              <dd className="text-emerald-200">{summary.vegCount}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-emerald-50/65">Non-vegetarian</dt>
              <dd className="text-rose-200">{summary.nonVegCount}</dd>
            </div>
            <div className="mt-3 flex items-baseline justify-between border-t border-gold-400/15 pt-3">
              <dt className="text-gold-100">Indicative total</dt>
              <dd className="font-[family-name:var(--font-cormorant)] text-2xl text-gold-200">
                {formatINR(summary.indicativeTotal)}
              </dd>
            </div>
          </dl>

          <div className="mt-4">
            <StatusPanel tone="info" title="Indicative pricing — no payment taken">
              <p className="text-[0.78rem] leading-relaxed">{priceDisclaimer}</p>
            </StatusPanel>
          </div>

          {children}

          <div className="mt-4 flex flex-wrap gap-3">
            <Link href="/menu" className="btn-ghost flex-1 !px-4 !py-2.5 !text-[0.65rem]">
              Add more dishes
            </Link>
            <DeliveryButton className="btn-ghost flex-1 !px-4 !py-2.5 !text-[0.65rem]" label="Zomato delivery" />
          </div>
        </div>
      </aside>
    </div>
  );
}
