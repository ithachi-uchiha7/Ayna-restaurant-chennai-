"use client";

import Link from "next/link";
import { useEffect, useState, type ReactNode } from "react";
import { externalLinks, whatsappLink } from "@/lib/site-config";

/* ------------------------------------------------------------------ *
 * External action buttons — all destinations come from site-config.ts
 * ------------------------------------------------------------------ */

export function ExternalButton({
  href,
  children,
  className = "btn-gold",
  ariaLabel,
}: {
  href: string;
  children: ReactNode;
  className?: string;
  ariaLabel?: string;
}) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className={className}
      aria-label={ariaLabel}
    >
      {children}
      <span aria-hidden className="text-[0.7em] opacity-70">
        ↗
      </span>
    </a>
  );
}

export function ReserveButton({
  className = "btn-gold",
  label = "Reserve a table",
}: {
  className?: string;
  label?: string;
}) {
  return (
    <ExternalButton
      href={externalLinks.reservations}
      className={className}
      ariaLabel="Open Ayna's official Google reservation page in a new tab"
    >
      {label}
    </ExternalButton>
  );
}

export function DeliveryButton({
  className = "btn-ghost",
  label = "Order on Zomato",
}: {
  className?: string;
  label?: string;
}) {
  return (
    <ExternalButton
      href={externalLinks.zomato}
      className={className}
      ariaLabel="Open Ayna's official Zomato listing to order delivery"
    >
      {label}
    </ExternalButton>
  );
}

export function WhatsAppButton({
  className = "btn-whatsapp",
  message,
  label = "WhatsApp us",
}: {
  className?: string;
  message?: string;
  label?: string;
}) {
  return (
    <a
      href={whatsappLink(message)}
      target="_blank"
      rel="noopener noreferrer"
      className={className}
      aria-label={`Chat with Ayna on WhatsApp at +91 95000 11940`}
    >
      <svg viewBox="0 0 24 24" aria-hidden className="h-4 w-4 fill-current">
        <path d="M17.47 14.38c-.3-.15-1.75-.86-2.02-.96-.27-.1-.47-.15-.67.15s-.77.96-.94 1.16c-.17.2-.35.22-.64.07-.3-.15-1.25-.46-2.38-1.47-.88-.78-1.47-1.75-1.64-2.04-.17-.3-.02-.46.13-.6.13-.13.3-.35.45-.52.15-.17.2-.3.3-.5.1-.2.05-.37-.02-.52-.07-.15-.67-1.6-.92-2.2-.24-.58-.49-.5-.67-.51h-.57c-.2 0-.52.07-.79.37-.27.3-1.04 1.01-1.04 2.46 0 1.45 1.06 2.85 1.21 3.05.15.2 2.09 3.34 5.08 4.55.71.3 1.26.48 1.69.62.71.22 1.36.19 1.87.12.57-.09 1.75-.72 2-1.41.25-.69.25-1.28.17-1.41-.07-.13-.27-.2-.57-.35Z" />
        <path d="M12.04 2C6.6 2 2.2 6.4 2.2 11.84c0 1.74.46 3.44 1.32 4.94L2 22l5.36-1.4a9.83 9.83 0 0 0 4.68 1.19h.01c5.43 0 9.84-4.4 9.84-9.84A9.78 9.78 0 0 0 12.04 2Zm0 17.94h-.01a8.2 8.2 0 0 1-4.16-1.14l-.3-.18-3.1.81.83-3.02-.19-.31a8.14 8.14 0 0 1-1.25-4.35c0-4.51 3.67-8.18 8.19-8.18a8.13 8.13 0 0 1 8.18 8.19c0 4.51-3.67 8.18-8.19 8.18Z" />
      </svg>
      {label}
    </a>
  );
}

/* ------------------------------------------------------------------ *
 * Live open / closed badge (IST aware, updates every minute)
 * ------------------------------------------------------------------ */

export function OpenStatusBadge({ compact = false }: { compact?: boolean }) {
  const [status, setStatus] = useState<{ isOpen: boolean; label: string; detail: string } | null>(null);

  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      try {
        const res = await fetch("/api/open-status", { cache: "no-store" });
        const data = await res.json();
        if (!cancelled && data?.ok) {
          setStatus({ isOpen: data.isOpen, label: data.label, detail: data.detail });
        }
      } catch {
        /* offline — fall back to client-side calculation below */
      }
      if (!cancelled) {
        // Client-side fallback keeps the badge honest even without the API.
        import("@/lib/hours").then(({ computeOpenStatus }) => {
          setStatus((prev) => prev ?? computeOpenStatus());
        });
      }
    };
    load();
    const timer = window.setInterval(load, 60_000);
    return () => {
      cancelled = true;
      window.clearInterval(timer);
    };
  }, []);

  if (!status) {
    return (
      <span className="inline-flex items-center gap-2 text-xs text-gold-200/60">
        <span className="h-2 w-2 rounded-full bg-gold-200/40" />
        Checking hours…
      </span>
    );
  }

  return (
    <span
      className={`inline-flex items-center gap-2 rounded-full px-3 py-1.5 text-xs font-medium ring-1 ${
        status.isOpen
          ? "bg-emerald-500/10 text-emerald-200 ring-emerald-400/30"
          : "bg-rose-500/10 text-rose-200 ring-rose-400/25"
      }`}
    >
      <span
        aria-hidden
        className={`h-2 w-2 rounded-full ${status.isOpen ? "bg-emerald-400 animate-pulse-ring" : "bg-rose-400"}`}
      />
      {status.isOpen ? "Open now" : "Closed"}
      {!compact ? <span className="text-gold-200/70">· {status.detail}</span> : null}
    </span>
  );
}

/* ------------------------------------------------------------------ *
 * Small shared pieces
 * ------------------------------------------------------------------ */

export function SectionHeading({
  eyebrow,
  title,
  script,
  intro,
  align = "center",
}: {
  eyebrow?: string;
  title: string;
  script?: string;
  intro?: string;
  align?: "center" | "left";
}) {
  return (
    <div className={`max-w-3xl ${align === "center" ? "mx-auto text-center" : ""}`}>
      {eyebrow ? <p className="eyebrow mb-4">{eyebrow}</p> : null}
      {script ? (
        <p className="script gold-text text-3xl leading-tight sm:text-4xl">{script}</p>
      ) : null}
      <h2 className="mt-2 text-3xl font-light text-gold-50 sm:text-4xl md:text-5xl">{title}</h2>
      {intro ? <p className="mt-5 text-balance text-base leading-relaxed text-emerald-50/70">{intro}</p> : null}
    </div>
  );
}

export function Field({
  label,
  name,
  error,
  hint,
  children,
  required,
}: {
  label: string;
  name: string;
  error?: string;
  hint?: string;
  children: ReactNode;
  required?: boolean;
}) {
  return (
    <label htmlFor={name} className="block">
      <span className="mb-2 flex items-baseline justify-between gap-3">
        <span className="text-xs font-medium uppercase tracking-[0.18em] text-gold-200/80">
          {label}
          {required ? <span className="text-rose-300"> *</span> : null}
        </span>
        {hint ? <span className="text-[0.68rem] text-emerald-50/40">{hint}</span> : null}
      </span>
      {children}
      {error ? (
        <span role="alert" className="mt-1.5 block text-xs text-rose-300">
          {error}
        </span>
      ) : null}
    </label>
  );
}

export const inputClass =
  "w-full rounded-xl border border-gold-400/25 bg-forest-950/70 px-4 py-3 text-sm text-gold-50 placeholder:text-emerald-50/30 outline-none transition focus:border-gold-300/70 focus:bg-forest-900/80";

export function StatusPanel({
  tone,
  title,
  children,
}: {
  tone: "success" | "error" | "info";
  title: string;
  children?: ReactNode;
}) {
  const palette =
    tone === "success"
      ? "border-emerald-400/30 bg-emerald-500/10 text-emerald-100"
      : tone === "error"
        ? "border-rose-400/30 bg-rose-500/10 text-rose-100"
        : "border-gold-400/30 bg-gold-400/10 text-gold-100";
  return (
    <div role="status" aria-live="polite" className={`rounded-2xl border px-5 py-4 text-sm ${palette}`}>
      <p className="font-semibold tracking-wide">{title}</p>
      {children ? <div className="mt-2 space-y-2 text-[0.85rem] opacity-90">{children}</div> : null}
    </div>
  );
}

export function Spinner({ label = "Loading" }: { label?: string }) {
  return (
    <span className="inline-flex items-center gap-2 text-sm text-gold-200/80">
      <span
        aria-hidden
        className="h-4 w-4 animate-spin rounded-full border-2 border-gold-300/30 border-t-gold-200"
      />
      {label}…
    </span>
  );
}

export function SourceNote({ children }: { children: ReactNode }) {
  return (
    <p className="text-xs leading-relaxed text-emerald-50/45">
      <span className="mr-1.5 rounded border border-gold-400/25 px-1.5 py-0.5 text-[0.6rem] uppercase tracking-widest text-gold-200/70">
        Source
      </span>
      {children}
    </p>
  );
}

export function InternalLink({
  href,
  children,
  className = "",
}: {
  href: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <Link href={href} className={className}>
      {children}
    </Link>
  );
}

/** Transparent "AI-generated imagery" disclosure chip used near every visual. */
export function AiImageChip({ className = "" }: { className?: string }) {
  return (
    <span
      className={`pointer-events-none absolute left-3 top-3 z-10 rounded-full bg-forest-950/75 px-2.5 py-1 text-[0.6rem] uppercase tracking-[0.18em] text-gold-200/80 ring-1 ring-gold-400/25 ${className}`}
    >
      AI-generated illustration
    </span>
  );
}
