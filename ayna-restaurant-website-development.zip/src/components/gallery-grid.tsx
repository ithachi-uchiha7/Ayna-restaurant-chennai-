"use client";

import { useCallback, useEffect, useState } from "react";
import { gallery, realPhotoSources, type GalleryItem } from "@/lib/content";
import { AiImageChip } from "./ui";

export function GalleryGrid() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);
  const [filter, setFilter] = useState<"all" | "food" | "room">("all");

  const items: GalleryItem[] = gallery;
  const visible = items.filter((item) => {
    if (filter === "food") return /dish-/.test(item.src);
    if (filter === "room") return !/dish-/.test(item.src);
    return true;
  });

  const close = useCallback(() => setOpenIndex(null), []);
  const step = useCallback(
    (delta: number) => {
      setOpenIndex((current) => {
        if (current === null) return current;
        const next = (current + delta + visible.length) % visible.length;
        return next;
      });
    },
    [visible.length],
  );

  useEffect(() => {
    if (openIndex === null) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") close();
      if (event.key === "ArrowRight") step(1);
      if (event.key === "ArrowLeft") step(-1);
    };
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [openIndex, close, step]);

  const active = openIndex === null ? null : visible[openIndex];

  return (
    <div>
      <div className="mb-8 flex flex-wrap items-center justify-center gap-2">
        {(["all", "food", "room"] as const).map((option) => (
          <button
            key={option}
            type="button"
            onClick={() => setFilter(option)}
            aria-pressed={filter === option}
            className={`rounded-full px-4 py-2 text-[0.68rem] uppercase tracking-[0.16em] transition ${
              filter === option
                ? "bg-gold-400 font-semibold text-forest-950"
                : "text-emerald-50/70 ring-1 ring-gold-400/25 hover:bg-gold-400/10"
            }`}
          >
            {option === "all" ? "Everything" : option === "food" ? "Food" : "Room & bar"}
          </button>
        ))}
      </div>

      <div className="grid auto-rows-[12rem] grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
        {visible.map((item, index) => (
          <button
            key={item.src + index}
            type="button"
            onClick={() => setOpenIndex(index)}
            className={`group relative overflow-hidden rounded-2xl ring-1 ring-gold-400/15 transition hover:ring-gold-300/50 ${
              item.span === "wide" ? "col-span-2" : ""
            } ${item.span === "tall" ? "row-span-2" : ""}`}
            aria-label={`Open image: ${item.caption}`}
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={item.src}
              alt={item.alt}
              loading="lazy"
              decoding="async"
              className="h-full w-full object-cover transition duration-[1200ms] group-hover:scale-110"
            />
            <span aria-hidden className="absolute inset-0 bg-gradient-to-t from-forest-950/85 via-transparent to-transparent opacity-80" />
            <AiImageChip />
            <span className="absolute bottom-3 left-3 right-3 text-left text-[0.66rem] uppercase tracking-[0.14em] text-gold-100/85">
              {item.caption}
            </span>
          </button>
        ))}
      </div>

      {active ? (
        <div
          role="dialog"
          aria-modal="true"
          aria-label={active.caption}
          className="fixed inset-0 z-[90] flex items-center justify-center bg-forest-950/94 p-4 backdrop-blur-xl"
          onClick={close}
        >
          <div
            className="relative w-full max-w-5xl"
            onClick={(event) => event.stopPropagation()}
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={active.src}
              alt={active.alt}
              className="max-h-[76vh] w-full rounded-3xl object-contain ring-1 ring-gold-400/25"
            />
            <div className="mt-4 flex flex-wrap items-center justify-between gap-4">
              <div>
                <p className="font-[family-name:var(--font-cormorant)] text-2xl text-gold-100">{active.caption}</p>
                <p className="mt-1 max-w-xl text-xs leading-relaxed text-emerald-50/60">{active.alt}</p>
              </div>
              <div className="flex gap-2">
                <button type="button" className="btn-ghost !px-4 !py-2.5 !text-[0.65rem]" onClick={() => step(-1)}>
                  ← Prev
                </button>
                <button type="button" className="btn-ghost !px-4 !py-2.5 !text-[0.65rem]" onClick={() => step(1)}>
                  Next →
                </button>
                <button type="button" className="btn-gold !px-4 !py-2.5 !text-[0.65rem]" onClick={close}>
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      ) : null}

      <section className="mt-16 rounded-3xl glass p-7">
        <p className="script gold-text text-2xl">Genuine photographs of Ayna</p>
        <p className="mt-3 max-w-3xl text-sm leading-relaxed text-emerald-50/70">
          We do not pass AI artwork off as the restaurant. These platforms host real guest and
          management photography of Ayna and its food:
        </p>
        <ul className="mt-5 grid gap-3 sm:grid-cols-2">
          {realPhotoSources.map((source) => (
            <li key={source.url}>
              <a
                href={source.url}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-between gap-3 rounded-2xl ring-1 ring-gold-400/20 px-4 py-3 text-sm text-gold-100 transition hover:bg-gold-400/10"
              >
                {source.label}
                <span aria-hidden>↗</span>
              </a>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
