"use client";

import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { AmbientField, Parallax } from "./motion";
import { DeliveryButton, OpenStatusBadge, ReserveButton } from "./ui";
import { ratings, site } from "@/lib/site-config";

export function HomeHero() {
  const stageRef = useRef<HTMLDivElement | null>(null);
  const [pointer, setPointer] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const node = stageRef.current;
    if (!node) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const onMove = (event: PointerEvent) => {
      const rect = node.getBoundingClientRect();
      setPointer({
        x: (event.clientX - rect.left) / rect.width - 0.5,
        y: (event.clientY - rect.top) / rect.height - 0.5,
      });
    };
    node.addEventListener("pointermove", onMove);
    return () => node.removeEventListener("pointermove", onMove);
  }, []);

  return (
    <section
      ref={stageRef}
      className="relative isolate flex min-h-[100svh] items-center overflow-hidden noise"
      aria-label="Ayna introduction"
    >
      {/* Layer 1 — photographic depth plate */}
      <div className="absolute inset-0 -z-30" style={{ transform: `translate3d(${pointer.x * -18}px, ${pointer.y * -14}px, 0)` }}>
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src="/images/hero-interior.jpg"
          alt="AI-generated illustration of Ayna's deep-green and gold dining room"
          className="ken-burns h-full w-full object-cover"
          fetchPriority="high"
        />
      </div>
      <div aria-hidden className="absolute inset-0 -z-20 bg-[radial-gradient(120%_90%_at_50%_10%,rgba(4,18,12,.35),rgba(4,18,12,.86)_60%,#04120c_100%)]" />
      <div aria-hidden className="absolute inset-0 -z-20 bg-gradient-to-b from-forest-950/70 via-transparent to-forest-950" />

      {/* Layer 2 — rotating gold jaali mandala */}
      <div
        aria-hidden
        className="pointer-events-none absolute -right-40 top-1/2 -z-10 h-[46rem] w-[46rem] -translate-y-1/2 opacity-[0.13]"
        style={{ transform: `translate3d(${pointer.x * 34}px, calc(-50% + ${pointer.y * 30}px), 0)` }}
      >
        <svg viewBox="0 0 400 400" className="spin-slow h-full w-full">
          <defs>
            <linearGradient id="jaali" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#f6e7bd" />
              <stop offset="100%" stopColor="#a9853a" />
            </linearGradient>
          </defs>
          <g fill="none" stroke="url(#jaali)" strokeWidth="0.6">
            {Array.from({ length: 18 }).map((_, i) => (
              <circle key={i} cx="200" cy="200" r={40 + i * 9} />
            ))}
            {Array.from({ length: 24 }).map((_, i) => {
              const a = (i / 24) * Math.PI * 2;
              return (
                <g key={`p${i}`}>
                  <line x1="200" y1="200" x2={200 + Math.cos(a) * 200} y2={200 + Math.sin(a) * 200} />
                  <circle cx={200 + Math.cos(a) * 150} cy={200 + Math.sin(a) * 150} r="9" />
                </g>
              );
            })}
          </g>
        </svg>
      </div>

      <AmbientField density={52} />

      {/* Layer 3 — content */}
      <div className="relative mx-auto w-full max-w-7xl px-5 pb-24 pt-32 lg:px-8">
        <Parallax speed={0.06}>
          <div
            style={{
              transform: `perspective(1200px) rotateX(${pointer.y * -4}deg) rotateY(${pointer.x * 5}deg)`,
              transformStyle: "preserve-3d",
            }}
            className="max-w-3xl"
          >
            <p className="eyebrow">Hilton Chennai · Guindy · 3rd Floor</p>

            <h1 className="mt-6 flex flex-col">
              <span className="script gold-text block text-[clamp(4.5rem,15vw,10rem)] leading-[0.85]">
                {site.name}
              </span>
              <span className="mt-3 block font-[family-name:var(--font-cormorant)] text-[clamp(1.15rem,3.4vw,2.1rem)] font-light tracking-[0.02em] text-gold-50/90">
                Pan-Indian fine dining, reflected in gold
              </span>
            </h1>

            <p className="mt-7 max-w-xl text-balance text-base leading-relaxed text-emerald-50/72 sm:text-lg">
              Ayna brings Kashmiri morels, Chettinad pepper, Bengali sweets and Malabar seafood to one
              green-and-gold dining room above Guindy. Travellers&apos; Choice 2025 · 4.7/5 on Tripadvisor.
            </p>

            <div className="mt-9 flex flex-wrap items-center gap-4">
              <ReserveButton label="Book a table" />
              <Link href="/menu" className="btn-ghost">
                Explore the menu
              </Link>
              <DeliveryButton label="Order on Zomato" />
            </div>

            <div className="mt-9 flex flex-wrap items-center gap-4">
              <OpenStatusBadge />
              <Link
                href="/visit"
                className="text-xs uppercase tracking-[0.18em] text-gold-200/70 underline-offset-4 transition hover:text-gold-100 hover:underline"
              >
                Hours, map & directions
              </Link>
            </div>

            <dl className="mt-12 grid max-w-2xl grid-cols-2 gap-x-8 gap-y-5 sm:grid-cols-4">
              {ratings.map((rating) => (
                <div key={rating.source}>
                  <dt className="text-[0.6rem] uppercase tracking-[0.24em] text-emerald-50/45">{rating.source}</dt>
                  <dd className="mt-1 font-[family-name:var(--font-cormorant)] text-2xl text-gold-200">
                    {rating.score}
                  </dd>
                </div>
              ))}
            </dl>
          </div>
        </Parallax>
      </div>

      <div aria-hidden className="absolute inset-x-0 bottom-6 flex justify-center">
        <span className="flex h-11 w-7 items-start justify-center rounded-full ring-1 ring-gold-300/40">
          <span className="mt-1.5 h-2 w-1 animate-bounce rounded-full bg-gold-200/80" />
        </span>
      </div>
    </section>
  );
}
