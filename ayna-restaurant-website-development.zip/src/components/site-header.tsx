"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { useCart } from "./cart-provider";
import { OpenStatusBadge, ReserveButton } from "./ui";
import { site } from "@/lib/site-config";

export const navItems = [
  { href: "/", label: "Home" },
  { href: "/about", label: "About" },
  { href: "/menu", label: "Menu" },
  { href: "/specials", label: "Specials" },
  { href: "/gallery", label: "Gallery" },
  { href: "/venue", label: "Venue" },
  { href: "/reviews", label: "Reviews" },
  { href: "/events", label: "Events" },
  { href: "/visit", label: "Visit" },
  { href: "/contact", label: "Contact" },
];

type Me = { id: number; fullName: string; role: string } | null;

export function SiteHeader() {
  const pathname = usePathname();
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [me, setMe] = useState<Me>(null);
  const [loaded, setLoaded] = useState(false);
  const { summary, ready } = useCart();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  useEffect(() => {
    let cancelled = false;
    fetch("/api/auth/me", { cache: "no-store" })
      .then((res) => res.json())
      .then((data) => {
        if (cancelled) return;
        setMe(data?.user ? { id: data.user.id, fullName: data.user.fullName, role: data.user.role } : null);
        setLoaded(true);
      })
      .catch(() => setLoaded(true));
    return () => {
      cancelled = true;
    };
  }, [pathname]);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-[60] transition-all duration-500 ${
        scrolled ? "bg-forest-950/88 backdrop-blur-xl shadow-[0_18px_40px_-30px_rgba(0,0,0,.9)]" : "bg-transparent"
      }`}
    >
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-5 py-3.5 lg:px-8">
        <Link href="/" className="group flex items-center gap-3" aria-label={`${site.name} — home`}>
          <span
            aria-hidden
            className="relative grid h-11 w-11 place-items-center rounded-full ring-1 ring-gold-400/45 transition group-hover:ring-gold-200/80"
            style={{ background: "radial-gradient(circle at 35% 30%, #1b5b3c, #06170f 70%)" }}
          >
            <span className="script gold-text text-2xl">A</span>
          </span>
          <span className="leading-none">
            <span className="script gold-text block text-2xl">{site.name}</span>
            <span className="block text-[0.55rem] uppercase tracking-[0.36em] text-gold-200/55">
              Hilton Chennai
            </span>
          </span>
        </Link>

        <nav aria-label="Primary" className="hidden items-center gap-0.5 xl:flex">
          {navItems.map((item) => {
            const active = pathname === item.href || (item.href !== "/" && pathname.startsWith(item.href));
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`relative rounded-full px-3 py-2 text-[0.7rem] font-medium uppercase tracking-[0.16em] transition ${
                  active ? "text-gold-100" : "text-emerald-50/65 hover:text-gold-100"
                }`}
              >
                {item.label}
                <span
                  aria-hidden
                  className={`absolute inset-x-3 -bottom-0.5 h-px origin-left bg-gradient-to-r from-transparent via-gold-300 to-transparent transition-transform duration-300 ${
                    active ? "scale-x-100" : "scale-x-0"
                  }`}
                />
              </Link>
            );
          })}
        </nav>

        <div className="flex items-center gap-2">
          <div className="hidden lg:block">
            <OpenStatusBadge compact />
          </div>

          <Link
            href="/cart"
            className="relative grid h-10 w-10 place-items-center rounded-full ring-1 ring-gold-400/30 transition hover:ring-gold-200/70"
            aria-label={`Pre-order basket, ${ready ? summary.count : 0} items`}
          >
            <svg viewBox="0 0 24 24" aria-hidden className="h-[18px] w-[18px] fill-none stroke-gold-200" strokeWidth="1.6">
              <path d="M4 6h16l-1.4 11.2a2 2 0 0 1-2 1.8H7.4a2 2 0 0 1-2-1.8L4 6Z" />
              <path d="M9 6V5a3 3 0 0 1 6 0v1" />
            </svg>
            {ready && summary.count > 0 ? (
              <span className="absolute -right-1 -top-1 grid h-5 min-w-5 place-items-center rounded-full bg-gold-400 px-1 text-[0.6rem] font-bold text-forest-950">
                {summary.count}
              </span>
            ) : null}
          </Link>

          {loaded && me ? (
            <Link
              href={me.role === "admin" ? "/admin" : "/account"}
              className="hidden rounded-full px-4 py-2 text-[0.7rem] uppercase tracking-[0.16em] text-gold-100 ring-1 ring-gold-400/35 transition hover:bg-gold-400/10 sm:block"
            >
              {me.role === "admin" ? "Admin" : me.fullName.split(" ")[0]}
            </Link>
          ) : (
            <Link
              href="/login"
              className="hidden rounded-full px-4 py-2 text-[0.7rem] uppercase tracking-[0.16em] text-gold-100 ring-1 ring-gold-400/35 transition hover:bg-gold-400/10 sm:block"
            >
              Sign in
            </Link>
          )}

          <div className="hidden md:block">
            <ReserveButton className="btn-gold !px-5 !py-2.5 !text-[0.68rem]" label="Book" />
          </div>

          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            className="grid h-10 w-10 place-items-center rounded-full ring-1 ring-gold-400/30 transition hover:ring-gold-200/70 xl:hidden"
            aria-expanded={open}
            aria-controls="mobile-nav"
            aria-label={open ? "Close menu" : "Open menu"}
          >
            <span className="relative block h-3 w-5">
              <span
                className={`absolute left-0 h-px w-5 bg-gold-100 transition-all ${open ? "top-1.5 rotate-45" : "top-0"}`}
              />
              <span
                className={`absolute left-0 top-1.5 h-px w-5 bg-gold-100 transition-all ${open ? "opacity-0" : ""}`}
              />
              <span
                className={`absolute left-0 h-px w-5 bg-gold-100 transition-all ${open ? "top-1.5 -rotate-45" : "top-3"}`}
              />
            </span>
          </button>
        </div>
      </div>

      <div
        id="mobile-nav"
        hidden={!open}
        className="xl:hidden border-t border-gold-400/15 bg-forest-950/96 backdrop-blur-xl"
      >
        <nav aria-label="Mobile" className="mx-auto grid max-w-7xl gap-1 px-5 py-5 sm:grid-cols-2">
          {navItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="rounded-xl px-3 py-3 text-sm uppercase tracking-[0.16em] text-emerald-50/80 transition hover:bg-gold-400/10 hover:text-gold-100"
            >
              {item.label}
            </Link>
          ))}
          <Link
            href={me ? (me.role === "admin" ? "/admin" : "/account") : "/login"}
            className="rounded-xl px-3 py-3 text-sm uppercase tracking-[0.16em] text-gold-100 transition hover:bg-gold-400/10"
          >
            {me ? (me.role === "admin" ? "Admin dashboard" : "My account") : "Sign in"}
          </Link>
          <div className="mt-3 flex flex-wrap gap-3 sm:col-span-2">
            <ReserveButton className="btn-gold !px-5 !py-3 !text-[0.68rem]" label="Reserve on Google" />
            <Link href="/cart" className="btn-ghost">
              Basket ({ready ? summary.count : 0})
            </Link>
          </div>
        </nav>
      </div>
    </header>
  );
}
