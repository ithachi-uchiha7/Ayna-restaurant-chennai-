import type { Metadata } from "next";
import { CountUp, Reveal } from "@/components/motion";
import { ReserveButton, SectionHeading } from "@/components/ui";
import { pressQuotes, ratingBuckets, reviews, tripadvisorSubScores } from "@/lib/reviews-data";
import { ratings } from "@/lib/site-config";

export const metadata: Metadata = {
  title: "Guest reviews & press — genuine and attributable",
  description:
    "Real, attributable reviews of Ayna at Hilton Chennai with links to their original sources on Tripadvisor, plus published press coverage from The Hindu, Indian Express, Indulge Express and IANS.",
  alternates: { canonical: "/reviews" },
};

export default function ReviewsPage() {
  const totalBucket = ratingBuckets.reduce((sum, bucket) => sum + bucket.count, 0);

  return (
    <div className="pt-28">
      <section className="mx-auto max-w-7xl px-5 pb-10 lg:px-8">
        <SectionHeading
          eyebrow="Customer reviews"
          script="Verbatim, sourced, linked"
          title="What guests actually wrote"
          intro="Every quote below is reproduced from a public review or article. Reviewer names are shown as published — many platforms only expose screen names, and we will not invent identities. Each card links to the original."
        />
      </section>

      <section className="mx-auto max-w-7xl px-5 pb-16 lg:px-8">
        <div className="grid gap-6 lg:grid-cols-[1.1fr_1fr]">
          <Reveal>
            <div className="rounded-3xl glass p-7">
              <div className="flex flex-wrap items-end gap-6">
                <div>
                  <p className="font-[family-name:var(--font-cormorant)] text-6xl leading-none text-gold-200">
                    4.7
                  </p>
                  <p className="mt-1 text-xs uppercase tracking-[0.2em] text-emerald-50/50">
                    Tripadvisor · <CountUp to={169} /> reviews
                  </p>
                </div>
                <div className="flex-1 space-y-2">
                  {ratingBuckets.map((bucket) => (
                    <div key={bucket.label} className="flex items-center gap-3">
                      <span className="w-20 shrink-0 text-xs text-emerald-50/60">{bucket.label}</span>
                      <span className="h-2 flex-1 overflow-hidden rounded-full bg-forest-950/70">
                        <span
                          className="block h-full rounded-full bg-gradient-to-r from-gold-600 to-gold-200"
                          style={{ width: `${(bucket.count / totalBucket) * 100}%` }}
                        />
                      </span>
                      <span className="w-8 text-right text-xs text-emerald-50/50">{bucket.count}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="mt-7 grid grid-cols-2 gap-4 sm:grid-cols-4">
                {tripadvisorSubScores.map((score) => (
                  <div key={score.label} className="rounded-2xl bg-forest-950/50 px-4 py-3">
                    <p className="text-[0.6rem] uppercase tracking-[0.2em] text-gold-200/65">{score.label}</p>
                    <p className="mt-1 font-[family-name:var(--font-cormorant)] text-2xl text-gold-100">
                      {score.value}
                    </p>
                  </div>
                ))}
              </div>

              <p className="mt-6 text-xs leading-relaxed text-emerald-50/50">
                Tripadvisor also awarded Ayna its Travellers&apos; Choice badge for 2025 and ranks it #44
                of 5,591 restaurants in Chennai. Sub-scores and bucket counts are as published on the
                Tripadvisor listing page.
              </p>
            </div>
          </Reveal>

          <Reveal delay={120}>
            <div className="grid gap-4">
              {ratings.map((rating) => (
                <a
                  key={rating.source}
                  href={rating.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-between gap-4 rounded-3xl glass-soft px-6 py-5 transition hover:bg-gold-400/10"
                >
                  <span>
                    <span className="block text-sm uppercase tracking-[0.18em] text-gold-200/70">{rating.source}</span>
                    <span className="mt-1 block text-xs leading-relaxed text-emerald-50/60">{rating.detail}</span>
                  </span>
                  <span className="shrink-0 font-[family-name:var(--font-cormorant)] text-3xl text-gold-200">
                    {rating.score}
                  </span>
                </a>
              ))}
            </div>
          </Reveal>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-5 pb-20 lg:px-8">
        <div className="grid gap-6 md:grid-cols-2">
          {reviews.map((review, i) => (
            <Reveal key={review.id} delay={(i % 2) * 80}>
              <figure className="flex h-full flex-col rounded-3xl glass p-7">
                <div className="flex items-center justify-between gap-4">
                  <span aria-hidden className="text-lg tracking-[0.3em] text-gold-300">
                    {"★".repeat(review.rating ?? 5)}
                  </span>
                  <span className="rounded-full bg-forest-950/60 px-3 py-1 text-[0.6rem] uppercase tracking-[0.18em] text-gold-200/75 ring-1 ring-gold-400/20">
                    {review.platform}
                  </span>
                </div>
                <blockquote className="mt-5 flex-1">
                  <p className="font-[family-name:var(--font-cormorant)] text-2xl leading-snug text-gold-50">
                    “{review.title}”
                  </p>
                  <p className="mt-4 text-sm leading-relaxed text-emerald-50/75">{review.quote}</p>
                </blockquote>
                <figcaption className="mt-6 border-t border-gold-400/15 pt-4">
                  <p className="text-sm text-gold-100">{review.author}</p>
                  <p className="mt-1 text-xs text-emerald-50/50">
                    {review.date}
                    {review.context ? ` · ${review.context}` : ""}
                  </p>
                  <a
                    href={review.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-3 inline-block text-xs uppercase tracking-[0.18em] text-gold-300/85 transition hover:text-gold-100"
                  >
                    Verify on {review.platform} ↗
                  </a>
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </div>

        <div className="mt-8 rounded-3xl border border-gold-400/20 bg-forest-900/50 p-6">
          <p className="text-sm font-semibold text-gold-100">A note on balance</p>
          <p className="mt-2 text-sm leading-relaxed text-emerald-50/70">
            Across {totalBucket} Tripadvisor reviews, 6 were rated &quot;average&quot;, 2 &quot;poor&quot; and 1
            &quot;terrible&quot;. Common criticisms in hotel-level reviews mention pricing and occasional
            Wi-Fi issues elsewhere in the property. We publish the aggregate distribution rather than
            only the praise.
          </p>
        </div>
      </section>

      <section className="border-t border-gold-400/12 bg-forest-900/40 py-20">
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <SectionHeading eyebrow="Press" script="Critics' columns" title="Published reviews of Ayna" />
          <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {pressQuotes.map((quote, i) => (
              <Reveal key={quote.id} delay={i * 70}>
                <figure className="flex h-full flex-col rounded-3xl glass p-6">
                  <blockquote className="flex-1 text-sm leading-relaxed text-emerald-50/75">“{quote.quote}”</blockquote>
                  <figcaption className="mt-5 border-t border-gold-400/15 pt-4">
                    <p className="text-sm text-gold-100">{quote.outlet}</p>
                    <p className="mt-1 text-xs text-emerald-50/50">
                      {quote.headline} · {quote.year}
                    </p>
                    <a
                      href={quote.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="mt-2 inline-block text-xs uppercase tracking-[0.18em] text-gold-300/85"
                    >
                      Read the original ↗
                    </a>
                  </figcaption>
                </figure>
              </Reveal>
            ))}
          </div>

          <div className="mt-12 text-center">
            <ReserveButton label="Reserve a table on Google" />
          </div>
        </div>
      </section>
    </div>
  );
}
