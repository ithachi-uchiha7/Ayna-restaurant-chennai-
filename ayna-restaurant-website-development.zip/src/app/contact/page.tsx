import type { Metadata } from "next";
import { ContactForm } from "@/components/forms";
import { Reveal } from "@/components/motion";
import { SectionHeading, WhatsAppButton } from "@/components/ui";
import { address, contact, externalLinks } from "@/lib/site-config";

export const metadata: Metadata = {
  title: "Contact Ayna — verified phone, WhatsApp & enquiry form",
  description:
    "Contact Ayna at Hilton Chennai: hotel switchboard +91 44 2225 5555, restaurant line 044 3085 5566, WhatsApp +91 95000 11940, or send an enquiry through the site's contact form.",
  alternates: { canonical: "/contact" },
};

const channels = [
  {
    label: "Hilton Chennai switchboard",
    value: contact.hotelPhoneDisplay,
    href: contact.hotelPhoneHref,
    note: "Ask for Ayna reservations · verified on Tripadvisor & Hilton",
  },
  {
    label: "Restaurant line",
    value: contact.restaurantPhoneDisplay,
    href: contact.restaurantPhoneHref,
    note: "Listed by magicpin and indian-travel-places.com",
  },
  {
    label: "WhatsApp",
    value: contact.whatsappDisplay,
    href: `https://wa.me/${contact.whatsappNumber}`,
    note: "Opens a chat with a prefilled enquiry message",
  },
];

export default function ContactPage() {
  return (
    <div className="pt-28">
      <section className="mx-auto max-w-7xl px-5 pb-10 lg:px-8">
        <SectionHeading
          eyebrow="Contact us"
          script="Talk to the team"
          title="Verified ways to reach Ayna"
          intro="We only publish contact details we could verify from public listings. Where nothing official exists, we say so rather than invent an address."
        />
      </section>

      <section className="mx-auto max-w-7xl px-5 pb-16 lg:px-8">
        <div className="grid gap-6 lg:grid-cols-[1fr_1.15fr]">
          <Reveal>
            <div className="space-y-4">
              {channels.map((channel) => (
                <a
                  key={channel.label}
                  href={channel.href}
                  target={channel.href.startsWith("http") ? "_blank" : undefined}
                  rel={channel.href.startsWith("http") ? "noopener noreferrer" : undefined}
                  className="flex items-center justify-between gap-4 rounded-3xl glass px-6 py-5 transition hover:bg-gold-400/10"
                >
                  <span>
                    <span className="block text-[0.6rem] uppercase tracking-[0.2em] text-gold-200/70">
                      {channel.label}
                    </span>
                    <span className="mt-1 block font-[family-name:var(--font-cormorant)] text-2xl text-gold-50">
                      {channel.value}
                    </span>
                    <span className="mt-1 block text-xs text-emerald-50/50">{channel.note}</span>
                  </span>
                  <span aria-hidden className="text-gold-300">
                    {channel.href.startsWith("http") ? "↗" : "→"}
                  </span>
                </a>
              ))}

              <div className="rounded-3xl glass-soft p-6">
                <p className="text-[0.6rem] uppercase tracking-[0.2em] text-gold-200/70">Address</p>
                <address className="mt-2 space-y-1 text-sm not-italic text-emerald-50/75">
                  <p className="text-gold-100">{address.line1}</p>
                  <p>{address.line2}</p>
                  <p>
                    {address.line3}, {address.city} {address.postalCode}
                  </p>
                  <p>
                    {address.state}, {address.country}
                  </p>
                </address>
                <div className="mt-4 flex flex-wrap gap-3 text-xs">
                  <a
                    href={externalLinks.googleMapsDirections}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="rounded-full px-3 py-1.5 ring-1 ring-gold-400/30 transition hover:bg-gold-400/10"
                  >
                    Directions ↗
                  </a>
                  <a
                    href={externalLinks.zomato}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="rounded-full px-3 py-1.5 ring-1 ring-gold-400/30 transition hover:bg-gold-400/10"
                  >
                    Zomato listing ↗
                  </a>
                  <a
                    href={externalLinks.tripadvisor}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="rounded-full px-3 py-1.5 ring-1 ring-gold-400/30 transition hover:bg-gold-400/10"
                  >
                    Tripadvisor ↗
                  </a>
                </div>
              </div>

              <div className="rounded-3xl border border-gold-400/20 bg-forest-900/50 p-6">
                <p className="text-sm font-semibold text-gold-100">E-mail address</p>
                <p className="mt-2 text-sm leading-relaxed text-emerald-50/70">{contact.emailNote}</p>
              </div>
            </div>
          </Reveal>

          <Reveal delay={120}>
            <div className="rounded-3xl glass p-7">
              <p className="script gold-text text-3xl">Send a message</p>
              <p className="mt-2 text-sm text-emerald-50/65">
                Feedback, questions, accessibility needs, press requests — this reaches the website
                team and is stored securely for a reply.
              </p>
              <div className="mt-7">
                <ContactForm />
              </div>
              <div className="mt-6 border-t border-gold-400/15 pt-5">
                <WhatsAppButton label="Prefer WhatsApp? Chat now" />
              </div>
            </div>
          </Reveal>
        </div>
      </section>
    </div>
  );
}
