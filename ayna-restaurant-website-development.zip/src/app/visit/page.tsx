import type { Metadata } from "next";
import { Reveal } from "@/components/motion";
import { OpeningHoursTable } from "@/components/opening-hours";
import { DeliveryButton, ReserveButton, WhatsAppButton } from "@/components/ui";
import { address, contact, externalLinks, priceGuidance } from "@/lib/site-config";

export const metadata: Metadata = {
  title: "Location, map, directions & opening hours",
  description:
    "Find Ayna: 3rd floor, Hilton Chennai, 124/1 J.N. Salai, Guindy, Chennai 600032. Interactive map, directions, live open/closed status and verified opening hours.",
  alternates: { canonical: "/visit" },
};

const bbox = `${address.lng - 0.006}%2C${address.lat - 0.0035}%2C${address.lng + 0.006}%2C${address.lat + 0.0035}`;

const landmarks = [
  { label: "Olympia Tech Park", detail: "Listed as the nearby landmark on Justdial & Swiggy" },
  { label: "Guindy metro & bus", detail: "Short ride from Guindy station on the blue line" },
  { label: "Chennai International Airport", detail: "Roughly 8–10 km via J.N. Salai (traffic dependent)" },
  { label: "Chennai Central Station", detail: "About 13 km; Booking.com lists 8.1 mi from the hotel" },
];

export default function VisitPage() {
  return (
    <div className="pt-28">
      <section className="mx-auto max-w-7xl px-5 pb-8 lg:px-8">
        <p className="eyebrow">Location</p>
        <h1 className="mt-3 max-w-3xl text-4xl font-light text-gold-50 sm:text-5xl">
          Third floor, Hilton Chennai, Guindy
        </h1>
        <p className="mt-5 max-w-2xl text-base leading-relaxed text-emerald-50/72">
          {address.singleLine}. Coordinates {address.lat}, {address.lng}. Take the hotel lifts to the
          3rd floor — Ayna shares the level with the hotel&apos;s other dining venues.
        </p>
      </section>

      <section className="mx-auto max-w-7xl px-5 pb-16 lg:px-8">
        <div className="grid gap-6 lg:grid-cols-[1.4fr_1fr]">
          <Reveal>
            <div className="overflow-hidden rounded-3xl gold-border">
              <iframe
                title="Map showing Ayna at Hilton Chennai, Guindy"
                src={`https://www.openstreetmap.org/export/embed.html?bbox=${bbox}&layer=mapnik&marker=${address.lat}%2C${address.lng}`}
                className="h-[26rem] w-full border-0 grayscale-[25%]"
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
              <div className="flex flex-wrap items-center justify-between gap-3 bg-forest-900/70 px-5 py-4">
                <p className="text-xs text-emerald-50/55">
                  Interactive map © OpenStreetMap contributors. Google Maps link provided for turn-by-turn
                  directions.
                </p>
                <div className="flex flex-wrap gap-3">
                  <a
                    href={externalLinks.googleMapsDirections}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn-gold !px-4 !py-2.5 !text-[0.65rem]"
                  >
                    Get directions ↗
                  </a>
                  <a
                    href={externalLinks.googleMapsPlace}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn-ghost !px-4 !py-2.5 !text-[0.65rem]"
                  >
                    Open in Google Maps ↗
                  </a>
                </div>
              </div>
            </div>
          </Reveal>

          <Reveal delay={120}>
            <div className="space-y-6">
              <div className="rounded-3xl glass p-6">
                <p className="text-sm font-semibold text-gold-100">Reach us</p>
                <ul className="mt-4 space-y-3 text-sm">
                  <li>
                    <a href={contact.hotelPhoneHref} className="text-gold-100 transition hover:text-gold-300">
                      {contact.hotelPhoneDisplay}
                    </a>
                    <span className="ml-2 text-xs text-emerald-50/45">Hilton Chennai switchboard</span>
                  </li>
                  <li>
                    <a href={contact.restaurantPhoneHref} className="text-gold-100 transition hover:text-gold-300">
                      {contact.restaurantPhoneDisplay}
                    </a>
                    <span className="ml-2 text-xs text-emerald-50/45">restaurant line (magicpin)</span>
                  </li>
                  <li>
                    <WhatsAppButton label="WhatsApp +91 95000 11940" />
                  </li>
                </ul>
                <p className="mt-4 text-xs leading-relaxed text-emerald-50/45">{contact.emailNote}</p>
              </div>

              <div className="rounded-3xl glass-soft p-6">
                <p className="text-sm font-semibold text-gold-100">Getting there</p>
                <ul className="mt-4 space-y-3">
                  {landmarks.map((item) => (
                    <li key={item.label} className="text-sm">
                      <span className="block text-gold-50/90">{item.label}</span>
                      <span className="text-xs text-emerald-50/55">{item.detail}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="rounded-3xl burgundy-glass p-6">
                <p className="text-sm font-semibold text-gold-100">Cost guidance</p>
                <p className="mt-2 text-sm leading-relaxed text-emerald-50/72">{priceGuidance.costForTwo}</p>
                <p className="mt-1 text-xs text-emerald-50/50">{priceGuidance.note}</p>
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-5 pb-16 lg:px-8">
        <div className="grid gap-6 lg:grid-cols-2">
          <Reveal>
            <OpeningHoursTable />
          </Reveal>

          <Reveal delay={120}>
            <div className="flex h-full flex-col justify-between gap-6 rounded-3xl glass p-7">
              <div>
                <p className="script gold-text text-3xl">Ready when you are</p>
                <p className="mt-3 text-sm leading-relaxed text-emerald-50/70">
                  Reserve on Google for instant confirmation, send an enquiry here if you&apos;d like the
                  team to plan something special, or order delivery through Zomato.
                </p>
              </div>
              <div className="flex flex-wrap gap-3">
                <ReserveButton label="Reserve on Google" />
                <a href="/reservations" className="btn-ghost">
                  Enquiry form
                </a>
                <DeliveryButton />
              </div>
            </div>
          </Reveal>
        </div>
      </section>
    </div>
  );
}
