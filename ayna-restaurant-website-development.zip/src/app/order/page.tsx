import type { Metadata } from "next";
import Link from "next/link";
import { DishCard } from "@/components/dish-card";
import { PreOrderForm } from "@/components/forms";
import { Reveal } from "@/components/motion";
import { DeliveryButton, SectionHeading, StatusPanel } from "@/components/ui";
import { menu } from "@/lib/menu-data";
import { externalLinks } from "@/lib/site-config";

export const metadata: Metadata = {
  title: "Order online & delivery — Zomato, or pre-order for dine-in",
  description:
    "Ayna's delivery is fulfilled on its official Zomato listing. Alternatively build a pre-order basket so the kitchen starts preparing before you arrive at Hilton Chennai.",
  alternates: { canonical: "/order" },
};

export default function OrderPage() {
  const popular = menu.filter((item) => item.signature).slice(0, 6);

  return (
    <div className="pt-28">
      <section className="mx-auto max-w-7xl px-5 pb-10 lg:px-8">
        <SectionHeading
          eyebrow="Online ordering & delivery"
          script="Ayna, wherever you are"
          title="Two honest ways to get the food"
          intro="We will not pretend to run a delivery fleet. Delivery is handled by Ayna's official Zomato listing; pre-orders for dine-in are handled by the restaurant directly."
        />
      </section>

      <section className="mx-auto max-w-7xl px-5 pb-16 lg:px-8">
        <div className="grid gap-6 md:grid-cols-2">
          <Reveal>
            <div className="flex h-full flex-col rounded-3xl glass p-7">
              <p className="eyebrow">Option 1 · delivery & takeaway</p>
              <h2 className="mt-3 font-[family-name:var(--font-cormorant)] text-3xl text-gold-50">
                Order on Zomato
              </h2>
              <p className="mt-4 flex-1 text-sm leading-relaxed text-emerald-50/72">
                Ayna&apos;s Zomato listing carries live delivery availability, the restaurant&apos;s own
                menu and prices, and Zomato&apos;s payment and support. Every delivery button on this
                site opens that page in a new tab — we never take your money or your card details.
              </p>
              <div className="mt-6 flex flex-wrap gap-3">
                <DeliveryButton className="btn-gold" label="Open Zomato" />
                <a
                  href={externalLinks.zomatoMenu}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-ghost"
                >
                  Zomato menu ↗
                </a>
              </div>
              <p className="mt-4 text-xs leading-relaxed text-emerald-50/45">
                Delivery radius, charges and timings are set by Zomato and the restaurant.
              </p>
            </div>
          </Reveal>

          <Reveal delay={120}>
            <div className="flex h-full flex-col rounded-3xl glass p-7">
              <p className="eyebrow">Option 2 · dine-in pre-order</p>
              <h2 className="mt-3 font-[family-name:var(--font-cormorant)] text-3xl text-gold-50">
                Pre-order before you arrive
              </h2>
              <p className="mt-4 flex-1 text-sm leading-relaxed text-emerald-50/72">
                Choose dishes with quantities and send them to the restaurant with your booking. Ideal
                for large tables, tasting-style dinners and guests on a tight schedule. No payment is
                requested — the bill is settled at the table.
              </p>
              <div className="mt-6 flex flex-wrap gap-3">
                <Link href="/menu" className="btn-gold">
                  Build a pre-order
                </Link>
                <Link href="/cart" className="btn-ghost">
                  View basket
                </Link>
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-5 pb-16 lg:px-8">
        <div className="grid gap-6 lg:grid-cols-[1fr_1fr]">
          <Reveal>
            <div className="rounded-3xl glass p-7">
              <p className="script gold-text text-3xl">Send a pre-order</p>
              <p className="mt-2 text-sm text-emerald-50/65">
                Your basket items are attached automatically.
              </p>
              <div className="mt-6">
                <PreOrderForm mode="order" />
              </div>
            </div>
          </Reveal>

          <Reveal delay={120}>
            <div className="space-y-6">
              <StatusPanel tone="info" title="What happens after you submit">
                <ul className="space-y-2 text-[0.82rem]">
                  <li>1. The pre-order is stored in the restaurant&apos;s queue with a reference (AYO-XXXXXX).</li>
                  <li>2. The team confirms by phone or WhatsApp during working hours.</li>
                  <li>3. The kitchen sequences your dishes for the time you gave.</li>
                  <li>4. You settle the bill at the restaurant — nothing is charged online.</li>
                </ul>
              </StatusPanel>

              <div className="rounded-3xl glass-soft p-6">
                <p className="text-sm font-semibold text-gold-100">Popular pre-orders</p>
                <ul className="mt-4 space-y-2 text-sm text-emerald-50/72">
                  {popular.slice(0, 4).map((item) => (
                    <li key={item.slug} className="flex items-center justify-between gap-3">
                      <span>{item.name}</span>
                      <span className="text-xs uppercase tracking-[0.16em] text-gold-200/70">{item.region}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      <section className="border-t border-gold-400/12 bg-forest-900/40 py-20">
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <SectionHeading eyebrow="Most pre-ordered" script="Start here" title="Signature plates" />
          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {popular.map((item, i) => (
              <Reveal key={item.slug} delay={i * 70}>
                <DishCard item={item} priority={i < 3} />
              </Reveal>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
