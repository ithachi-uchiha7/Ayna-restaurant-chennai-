import type { Metadata } from "next";
import Link from "next/link";
import { MenuExplorer } from "@/components/menu-explorer";
import { Reveal } from "@/components/motion";
import { DeliveryButton, SectionHeading } from "@/components/ui";
import { menu, menuCategories, priceDisclaimer } from "@/lib/menu-data";
import { externalLinks, priceGuidance } from "@/lib/site-config";

export const metadata: Metadata = {
  title: "Menu — pan-Indian dishes, dietary filters & search",
  description:
    "Browse Ayna's pan-Indian menu: kebabs and tandoor, seafood, vegetarian mains, biryani, breads and desserts, with dish names sourced from published reviews and press coverage.",
  alternates: { canonical: "/menu" },
};

export default function MenuPage() {
  return (
    <div className="pt-28">
      <section className="mx-auto max-w-7xl px-5 pb-8 lg:px-8">
        <SectionHeading
          eyebrow="The menu"
          script="From Kashmir to Kanyakumari"
          title="Ayna's pan-Indian table"
          intro="Roughly 140 items have been described across Ayna's published menus. The dishes below are the ones we could verify by name in guest reviews, press coverage and third-party listings — each carries its source. Use search and filters to find vegetarian, vegan or non-vegetarian plates."
        />

        <div className="mx-auto mt-8 flex max-w-4xl flex-wrap justify-center gap-3 text-xs">
          <span className="rounded-full bg-emerald-500/12 px-3 py-1.5 text-emerald-200 ring-1 ring-emerald-400/25">
            {menu.filter((i) => i.diet === "veg").length} vegetarian dishes
          </span>
          <span className="rounded-full bg-rose-500/12 px-3 py-1.5 text-rose-200 ring-1 ring-rose-400/25">
            {menu.filter((i) => i.diet === "non-veg").length} non-vegetarian dishes
          </span>
          <span className="rounded-full bg-gold-400/12 px-3 py-1.5 text-gold-200 ring-1 ring-gold-400/25">
            {menuCategories.length} categories
          </span>
          <span className="rounded-full bg-teal-500/12 px-3 py-1.5 text-teal-200 ring-1 ring-teal-400/25">
            Tripadvisor: vegan & gluten-free options
          </span>
        </div>

        <p className="mx-auto mt-6 max-w-3xl rounded-2xl border border-gold-400/20 bg-forest-900/60 px-5 py-4 text-center text-sm text-emerald-50/70">
          Ayna does not publish an official online à-la-carte price list. Published guidance is{" "}
          {priceGuidance.costForTwo}. Prices shown on this site are{" "}
          <strong className="text-gold-200">indicative only</strong> and the final bill is settled at
          the restaurant. For the restaurant&apos;s own live menu and prices, see{" "}
          <a
            href={externalLinks.zomatoMenu}
            target="_blank"
            rel="noopener noreferrer"
            className="text-gold-200 underline underline-offset-4"
          >
            Zomato&apos;s menu page ↗
          </a>
          .
        </p>
      </section>

      <section className="mx-auto max-w-7xl px-5 pb-24 lg:px-8">
        <MenuExplorer />
      </section>

      <section className="border-t border-gold-400/12 bg-forest-900/40 py-16">
        <div className="mx-auto max-w-5xl px-5 text-center lg:px-8">
          <Reveal>
            <p className="script gold-text text-3xl">Prefer the kitchen to start early?</p>
            <p className="mx-auto mt-3 max-w-2xl text-sm leading-relaxed text-emerald-50/70">
              Build a pre-order basket and send it with your reservation enquiry — or order delivery
              through Ayna&apos;s official Zomato listing. This website never takes payment for food.
            </p>
            <div className="mt-7 flex flex-wrap justify-center gap-3">
              <Link href="/order" className="btn-gold">
                Start a pre-order
              </Link>
              <DeliveryButton label="Zomato delivery" />
            </div>
            <p className="mt-6 text-xs text-emerald-50/40">{priceDisclaimer}</p>
          </Reveal>
        </div>
      </section>
    </div>
  );
}
