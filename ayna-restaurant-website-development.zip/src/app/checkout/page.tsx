import type { Metadata } from "next";
import { CartView } from "@/components/cart-view";
import { PreOrderForm } from "@/components/forms";
import { SectionHeading } from "@/components/ui";

export const metadata: Metadata = {
  title: "Checkout — send your pre-order to the kitchen",
  description:
    "Submit your Ayna pre-order. No payment is taken on this website; the restaurant confirms your pre-order and the bill is settled at the table.",
  alternates: { canonical: "/checkout" },
  robots: { index: false, follow: false },
};

export default function CheckoutPage() {
  return (
    <div className="pt-28">
      <section className="mx-auto max-w-7xl px-5 pb-8 lg:px-8">
        <SectionHeading
          eyebrow="Checkout"
          script="Send it to the kitchen"
          title="Confirm your pre-order"
          intro="Your pre-order is stored against a reference number and followed up by the restaurant by phone or WhatsApp. This is an enquiry with quantities — not an order and not a payment."
        />
      </section>

      <section className="mx-auto max-w-7xl px-5 pb-24 lg:px-8">
        <CartView>
          <div className="mt-5 border-t border-gold-400/15 pt-5">
            <PreOrderForm mode="checkout" />
          </div>
        </CartView>
      </section>
    </div>
  );
}
