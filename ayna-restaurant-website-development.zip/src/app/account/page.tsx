import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { preOrders, reservationRequests } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { LogoutButton, ProfileForm } from "@/components/auth-forms";
import { formatINR } from "@/lib/menu-data";

export const metadata: Metadata = {
  title: "My account",
  description: "Your Ayna profile, reservation enquiries and pre-order history.",
  robots: { index: false, follow: false },
};

function formatDate(value: Date | string): string {
  const date = typeof value === "string" ? new Date(value) : value;
  return date.toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" });
}

export default async function AccountPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  const [reservations, orders] = await Promise.all([
    db
      .select()
      .from(reservationRequests)
      .where(eq(reservationRequests.userId, user.id))
      .orderBy(desc(reservationRequests.createdAt))
      .limit(20),
    db.select().from(preOrders).where(eq(preOrders.userId, user.id)).orderBy(desc(preOrders.createdAt)).limit(20),
  ]);

  return (
    <div className="pt-28">
      <section className="mx-auto max-w-7xl px-5 pb-10 lg:px-8">
        <div className="flex flex-wrap items-end justify-between gap-5">
          <div>
            <p className="eyebrow">My account</p>
            <p className="script gold-text mt-2 text-5xl">Namaste, {user.fullName.split(" ")[0]}</p>
            <p className="mt-2 text-sm text-emerald-50/60">
              {user.email} · member since {formatDate(user.createdAt)}
              {user.role === "admin" ? " · team access" : ""}
            </p>
          </div>
          <div className="flex flex-wrap gap-3">
            {user.role === "admin" ? (
              <Link href="/admin" className="btn-gold">
                Admin dashboard
              </Link>
            ) : null}
            <LogoutButton />
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-5 pb-16 lg:px-8">
        <div className="grid gap-6 lg:grid-cols-[1fr_1.1fr]">
          <div className="rounded-3xl glass p-7">
            <p className="script gold-text text-2xl">Your details</p>
            <p className="mt-2 text-sm text-emerald-50/60">
              Stored so the restaurant can seat you well. Only the fields below are kept.
            </p>
            <div className="mt-6">
              <ProfileForm
                user={{
                  id: user.id,
                  email: user.email,
                  fullName: user.fullName,
                  phone: user.phone,
                  role: user.role,
                  marketingOptIn: user.marketingOptIn,
                  dietaryPreference: user.dietaryPreference,
                  notes: user.notes,
                  createdAt: user.createdAt.toISOString(),
                }}
              />
            </div>
          </div>

          <div className="space-y-6">
            <div className="rounded-3xl glass p-7">
              <div className="flex items-baseline justify-between gap-4">
                <p className="script gold-text text-2xl">Reservation enquiries</p>
                <span className="text-xs text-emerald-50/45">{reservations.length} saved</span>
              </div>

              {reservations.length === 0 ? (
                <div className="mt-5 rounded-2xl border border-gold-400/15 bg-forest-950/40 p-5 text-center">
                  <p className="text-sm text-emerald-50/65">
                    No enquiries yet. Send one from the reservations page — or book instantly on Google.
                  </p>
                  <Link href="/reservations" className="btn-ghost mt-4">
                    Reservation enquiry
                  </Link>
                </div>
              ) : (
                <ul className="mt-5 space-y-3">
                  {reservations.map((row) => (
                    <li key={row.id} className="rounded-2xl glass-soft px-4 py-3">
                      <div className="flex flex-wrap items-center justify-between gap-3">
                        <p className="text-sm text-gold-100">
                          {row.date} · {row.time} · {row.guests} guest{row.guests === 1 ? "" : "s"}
                        </p>
                        <span className="rounded-full bg-gold-400/15 px-2.5 py-1 text-[0.6rem] uppercase tracking-widest text-gold-200 ring-1 ring-gold-400/25">
                          {row.status}
                        </span>
                      </div>
                      <p className="mt-1 text-xs text-emerald-50/50">
                        Ref {row.reference} · {formatDate(row.createdAt)} · enquiry only, not confirmed
                      </p>
                      {row.preOrder && row.preOrder.length > 0 ? (
                        <p className="mt-2 text-xs text-emerald-50/65">
                          Pre-order attached:{" "}
                          {row.preOrder.map((item) => `${item.name} ×${item.qty}`).join(", ")}
                        </p>
                      ) : null}
                    </li>
                  ))}
                </ul>
              )}
            </div>

            <div className="rounded-3xl glass p-7">
              <div className="flex items-baseline justify-between gap-4">
                <p className="script gold-text text-2xl">Pre-orders</p>
                <span className="text-xs text-emerald-50/45">{orders.length} saved</span>
              </div>

              {orders.length === 0 ? (
                <div className="mt-5 rounded-2xl border border-gold-400/15 bg-forest-950/40 p-5 text-center">
                  <p className="text-sm text-emerald-50/65">
                    Nothing pre-ordered yet. Build a basket from the menu and send it to the kitchen.
                  </p>
                  <Link href="/menu" className="btn-ghost mt-4">
                    Browse the menu
                  </Link>
                </div>
              ) : (
                <ul className="mt-5 space-y-3">
                  {orders.map((row) => {
                    const total = row.items.reduce((sum, item) => sum + item.priceMinor * item.qty, 0);
                    return (
                      <li key={row.id} className="rounded-2xl glass-soft px-4 py-3">
                        <div className="flex flex-wrap items-center justify-between gap-3">
                          <p className="text-sm text-gold-100">
                            Ref {row.reference} · {row.items.length} dish
                            {row.items.length === 1 ? "" : "es"}
                          </p>
                          <span className="font-[family-name:var(--font-cormorant)] text-lg text-gold-200">
                            {formatINR(total / 100)}
                          </span>
                        </div>
                        <p className="mt-1 text-xs text-emerald-50/55">
                          {row.items.map((item) => `${item.name} ×${item.qty}`).join(", ")}
                        </p>
                        <p className="mt-1 text-xs text-emerald-50/40">
                          {formatDate(row.createdAt)} · {row.status} · indicative pricing, no payment taken
                        </p>
                      </li>
                    );
                  })}
                </ul>
              )}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
