import type { Metadata } from "next";
import { GalleryGrid } from "@/components/gallery-grid";
import { SectionHeading } from "@/components/ui";

export const metadata: Metadata = {
  title: "Gallery — illustrated mood boards & links to real photos",
  description:
    "An immersive, animated gallery of Ayna's green-and-gold dining mood. All imagery is AI-generated and labelled; genuine photographs of the restaurant are linked from Tripadvisor, Zomato, EazyDiner and Justdial.",
  alternates: { canonical: "/gallery" },
};

export default function GalleryPage() {
  return (
    <div className="pt-28">
      <section className="mx-auto max-w-7xl px-5 pb-6 lg:px-8">
        <SectionHeading
          eyebrow="Food gallery"
          script="Gold light, green shadow"
          title="An immersive look at the mood"
          intro="Click any frame to open the lightbox — arrow keys move through the set, Escape closes. Every image on this page is AI-generated illustration created for this project and is labelled as such; nothing here pretends to be a photograph of Ayna."
        />
      </section>

      <section className="mx-auto max-w-7xl px-5 pb-24 lg:px-8">
        <GalleryGrid />
      </section>
    </div>
  );
}
