import type { Metadata } from "next";
import Link from "next/link";
import { Parallax, Reveal, TiltCard } from "@/components/motion";
import { ReserveButton, SectionHeading, WhatsAppButton } from "@/components/ui";
import { experienceHighlights } from "@/lib/content";
import { address, facilities, externalLinks } from "@/lib/site-config";

export const metadata: Metadata = {
  title: "Venue, ambience & facilities",
  description:
    "Ayna sits on the 3rd floor of Hilton Chennai, Guindy: velvet-and-brass dining room, full bar, private dining area, valet parking, wheelchair access and Wi-Fi. Verified facility list.",
  alternates: { canonical: "/venue" },
};

const facilitiesNotListed = [
  "We do not claim on-site parking beyond what Hilton Chennai lists (valet + parking available).",
  "No outdoor/terrace seating at Ayna is documented in the sources we checked — the rooftop pool bar is a separate venue.",
  "No verified Instagram/Facebook account for Ayna is published, so none is linked.",
];

export default function VenuePage() {
  return (
    <div className="pt-28">
      <section className="mx-auto max-w-7xl px-5 pb-10 lg:px-8">
        <SectionHeading
          eyebrow="Venue & ambience"
          script="Velvet, brass, low light"
          title="The room above Guindy"
          intro="Ayna occupies the third floor of Hilton Chennai. Reviewers describe soft theme music, plush velvet couches, a bronze-coloured menu book and an old-world charm that is 'comforting yet exotic'."
        />
      </section>

      <section className="mx-auto max-w-7xl px-5 lg:px-8">
        <div className="grid gap-4 md:grid-cols-3">
          {[
            { src: "/images/hero-interior.jpg", caption: "Dining room mood" },
            { src: "/images/ambience-table.jpg", caption: "Table setting" },
            { src: "/images/bar-wine.jpg", caption: "Bar & wine list" },
          ].map((shot, i) => (
            <Reveal key={shot.src} delay={i * 90}>
              <TiltCard className="overflow-hidden rounded-3xl" intensity={6}>
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={shot.src}
                  alt={`AI-generated illustration — ${shot.caption}`}
                  loading="lazy"
                  className="h-72 w-full object-cover"
                />
                <span aria-hidden className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-forest-950 to-transparent p-4 text-sm text-gold-100">
                  {shot.caption}
                </span>
                <span className="absolute left-3 top-3 rounded-full bg-forest-950/75 px-2.5 py-1 text-[0.6rem] uppercase tracking-[0.18em] text-gold-200/80 ring-1 ring-gold-400/25">
                  AI illustration
                </span>
              </TiltCard>
            </Reveal>
          ))}
        </div>
      </section>

      <section className="py-20">
        <div className="mx-auto grid max-w-7xl gap-14 px-5 lg:grid-cols-[1fr_1.05fr] lg:px-8">
          <Reveal>
            <div>
              <p className="eyebrow">Dining experience</p>
              <p className="script gold-text mt-3 text-4xl">How the evening runs</p>
              <h2 className="mt-2 text-3xl font-light text-gold-50">From the tandoor to the phirni</h2>
              <div className="mt-8 space-y-5">
                {experienceHighlights.map((item) => (
                  <div key={item.title} className="rounded-2xl glass-soft p-5">
                    <p className="font-[family-name:var(--font-cormorant)] text-xl text-gold-100">{item.title}</p>
                    <p className="mt-2 text-sm leading-relaxed text-emerald-50/70">{item.body}</p>
                  </div>
                ))}
              </div>
            </div>
          </Reveal>

          <Reveal delay={130}>
            <div className="lg:sticky lg:top-28">
              <p className="eyebrow">Facilities</p>
              <p className="script gold-text mt-3 text-4xl">Everything a guest needs</p>
              <h2 className="mt-2 text-3xl font-light text-gold-50">Verified facilities</h2>
              <p className="mt-4 text-sm leading-relaxed text-emerald-50/65">
                Compiled from Tripadvisor&apos;s feature list, Justdial&apos;s &quot;quick information&quot;
                panel and Hilton Chennai&apos;s own dining page.
              </p>

              <ul className="mt-7 grid gap-3 sm:grid-cols-2">
                {facilities.map((facility) => (
                  <li key={facility.label} className="rounded-2xl ring-1 ring-gold-400/18 px-4 py-3">
                    <p className="flex items-center gap-2 text-sm text-gold-100">
                      <span aria-hidden>{facility.icon}</span>
                      {facility.label}
                    </p>
                    <p className="mt-1 text-xs leading-relaxed text-emerald-50/55">{facility.detail}</p>
                  </li>
                ))}
              </ul>

              <div className="mt-8 rounded-3xl burgundy-glass p-6">
                <p className="text-sm font-semibold text-gold-100">Honest limitations</p>
                <ul className="mt-3 space-y-2 text-xs leading-relaxed text-emerald-50/70">
                  {facilitiesNotListed.map((line) => (
                    <li key={line} className="flex gap-2">
                      <span aria-hidden className="text-gold-300">•</span>
                      {line}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      <section className="border-t border-gold-400/12 bg-forest-900/40 py-20">
        <div className="mx-auto max-w-5xl px-5 text-center lg:px-8">
          <Parallax speed={0.05}>
            <p className="script gold-text text-3xl">Getting there</p>
            <p className="mt-4 text-sm leading-relaxed text-emerald-50/70">
              {address.line1} · {address.line2} · {address.city} {address.postalCode}. Near Olympia
              Tech Park, Guindy. Valet parking at the hotel porch; step-free access via the hotel lifts.
            </p>
            <div className="mt-8 flex flex-wrap justify-center gap-3">
              <ReserveButton label="Reserve a table" />
              <a
                href={externalLinks.googleMapsDirections}
                target="_blank"
                rel="noopener noreferrer"
                className="btn-ghost"
              >
                Google Maps directions ↗
              </a>
              <WhatsAppButton label="Ask about access" />
            </div>
            <div className="mt-8 flex flex-wrap justify-center gap-3 text-xs">
              <Link href="/visit" className="btn-ghost !px-4 !py-2.5 !text-[0.65rem]">
                Map & opening hours
              </Link>
              <Link href="/events" className="btn-ghost !px-4 !py-2.5 !text-[0.65rem]">
                Private dining
              </Link>
            </div>
          </Parallax>
        </div>
      </section>
    </div>
  );
}
