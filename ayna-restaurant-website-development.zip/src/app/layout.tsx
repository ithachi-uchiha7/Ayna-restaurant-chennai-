import type { Metadata, Viewport } from "next";
import { Cormorant_Garamond, Great_Vibes, Inter } from "next/font/google";
import "./globals.css";
import { CartProvider } from "@/components/cart-provider";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-shell";
import { CookieConsent } from "@/components/cookie-consent";
import { ScrollProgress } from "@/components/motion";
import { FloatingActions } from "@/components/floating-actions";
import { address, contact, externalLinks, openingHours, priceGuidance, site } from "@/lib/site-config";

const inter = Inter({ subsets: ["latin"], variable: "--font-inter", display: "swap" });
const cormorant = Cormorant_Garamond({
  subsets: ["latin"],
  weight: ["300", "400", "500", "600"],
  variable: "--font-cormorant",
  display: "swap",
});
const greatVibes = Great_Vibes({ subsets: ["latin"], weight: "400", variable: "--font-vibes", display: "swap" });

export const metadata: Metadata = {
  metadataBase: new URL(site.url),
  title: {
    default: "Ayna — Pan-Indian Fine Dining at Hilton Chennai, Guindy",
    template: "%s · Ayna, Hilton Chennai",
  },
  description:
    "Ayna is the Indian specialty fine-dining restaurant on the 3rd floor of Hilton Chennai, Guindy. Pan-Indian cuisine from Kashmir to Kanyakumari, seafood, a full bar and private dining. Dinner 6:30 pm – 11:00 pm daily.",
  keywords: [
    "Ayna",
    "Ayna restaurant Chennai",
    "Hilton Chennai restaurant",
    "pan-Indian fine dining Chennai",
    "Guindy restaurant",
    "Indian restaurant Guindy",
    "seafood Chennai",
    "private dining Chennai",
  ],
  applicationName: "Ayna Chennai",
  authors: [{ name: "Ayna at Hilton Chennai" }],
  openGraph: {
    type: "website",
    siteName: "Ayna — Hilton Chennai",
    title: "Ayna — Pan-Indian Fine Dining at Hilton Chennai",
    description:
      "Pan-Indian fine dining on the 3rd floor of Hilton Chennai, Guindy. Reserve on Google, order delivery on Zomato.",
    locale: "en_IN",
    images: [{ url: "/images/hero-interior.jpg", width: 1536, height: 1024, alt: "Ayna dining room (AI-generated illustration)" }],
  },
  twitter: {
    card: "summary_large_image",
    title: "Ayna — Pan-Indian Fine Dining at Hilton Chennai",
    description: "Reserve a table at Ayna, the Indian specialty restaurant at Hilton Chennai, Guindy.",
    images: ["/images/hero-interior.jpg"],
  },
  robots: { index: true, follow: true },
  alternates: { canonical: "/" },
};

export const viewport: Viewport = {
  themeColor: "#04120c",
  width: "device-width",
  initialScale: 1,
};

function structuredData() {
  const days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
  const spec = Object.entries(openingHours).flatMap(([day, windows]) =>
    windows.map((w) => ({
      "@type": "OpeningHoursSpecification",
      dayOfWeek: `https://schema.org/${days[Number(day)]}`,
      opens: `${String(Math.floor(w.opens / 60)).padStart(2, "0")}:${String(w.opens % 60).padStart(2, "0")}`,
      closes: `${String(Math.floor(w.closes / 60)).padStart(2, "0")}:${String(w.closes % 60).padStart(2, "0")}`,
    })),
  );

  return {
    "@context": "https://schema.org",
    "@type": "Restaurant",
    name: "Ayna",
    alternateName: "Ayna — Hilton Chennai",
    description:
      "Ayna is the Indian specialty fine-dining restaurant of Hilton Chennai serving pan-Indian cuisine, seafood and desserts.",
    url: site.url,
    telephone: contact.hotelPhoneHref.replace("tel:", ""),
    image: [`${site.url}/images/hero-interior.jpg`],
    currenciesAccepted: "INR",
    paymentAccepted: "Cash, Credit Card (Amex, Mastercard, Visa)",
    priceRange: "₹₹₹₹",
    servesCuisine: ["Pan-Indian", "North Indian", "South Indian", "Seafood", "Mughlai", "Desserts"],
    address: {
      "@type": "PostalAddress",
      streetAddress: `${address.line1}, ${address.line2}`,
      addressLocality: `${address.line3}, ${address.city}`,
      addressRegion: address.state,
      postalCode: address.postalCode,
      addressCountry: address.countryCode,
    },
    geo: { "@type": "GeoCoordinates", latitude: address.lat, longitude: address.lng },
    hasMap: externalLinks.googleMapsPlace,
    openingHoursSpecification: spec,
    acceptsReservations: externalLinks.reservations,
    hasMenu: `${site.url}/menu`,
    amenityFeature: [
      { "@type": "LocationFeatureSpecification", name: "Full bar", value: true },
      { "@type": "LocationFeatureSpecification", name: "Valet parking", value: true },
      { "@type": "LocationFeatureSpecification", name: "Wheelchair accessible", value: true },
      { "@type": "LocationFeatureSpecification", name: "Private dining room", value: true },
      { "@type": "LocationFeatureSpecification", name: "Vegetarian options", value: true },
      { "@type": "LocationFeatureSpecification", name: "Free Wi-Fi", value: true },
    ],
    aggregateRating: {
      "@type": "AggregateRating",
      ratingValue: "4.7",
      reviewCount: "169",
      bestRating: "5",
      worstRating: "1",
    },
    review: [
      {
        "@type": "Review",
        author: { "@type": "Person", name: "Tripadvisor guest" },
        datePublished: "2025-01-10",
        reviewRating: { "@type": "Rating", ratingValue: "5", bestRating: "5" },
        reviewBody:
          "Excellent ambience, courteous and prompt service, quick food delivery and of course the food had authentic and exquisite taste.",
        url: externalLinks.tripadvisor,
      },
    ],
  };
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en-IN" className={`${inter.variable} ${cormorant.variable} ${greatVibes.variable}`}>
      <body className="min-h-screen antialiased">
        <script
          type="application/ld+json"
          suppressHydrationWarning
          dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData()) }}
        />
        <a
          href="#main"
          className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[100] focus:rounded-full focus:bg-gold-400 focus:px-4 focus:py-2 focus:text-sm focus:font-semibold focus:text-forest-950"
        >
          Skip to content
        </a>
        <CartProvider>
          <SiteHeader />
          <ScrollProgress />
          <main id="main">{children}</main>
          <SiteFooter />
          <CookieConsent />
          <FloatingActions />
        </CartProvider>
      </body>
    </html>
  );
}
