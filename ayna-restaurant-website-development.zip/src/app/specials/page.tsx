import type { Metadata } from "next";
import Link from "next/link";
import { DishCard } from "@/components/dish-card";
import { Parallax, Reveal, TiltCard } from "@/components/motion";
import { ReserveButton, SectionHeading, SourceNote } from "@/components/ui";
import { menu } from "@/lib/menu-data";

export const metadata: Metadata = {
  title: "Specials & signature dishes",
  description:
    "Ayna's signature plates — Dal Ayna, Hyderabadi Kacche Gosht ki Biryani, Tandoori Kasundi Jheenga, Nalli Nihari, Paneer Lazzat, Sakora Phirni — each sourced from published reviews and press coverage.",
  alternates: { canonical: "/specials" },
};

const festivals = [
  {
    title: "Tiffins of India",
    period: "Festival concept · first ran July 2016",
    body: "A dabbawala-inspired lunch served in tiered steel tiffins: a dal, two sabzis or one sabzi plus a non-vegetarian gravy, rice or pulao or paratha, and a dessert. Published prices at the time were ₹1,699 non-vegetarian and ₹1,499 vegetarian.",
    mustTry: "Aloo paratha, berry pulao, mutton korma, apple halwa",
    source: "Indian Express & DT Next, 2016",
  },
  {
    title: "Shaan-E-Punjab",
    period: "Reported April 2026 · 6:30 pm – 11:00 pm",
    body: "An uncompromising Punjabi food festival at Ayna, reported at ₹2,250 onwards.",
    mustTry: "Ask the team for the current festival menu",
    source: "Indulge Express, April 2026",
  },
  {
    title: "Small Plates menu",
    period: "Introduced 2021 · dinner",
    body: "The entire menu restructured into compact portions so a table can taste six or more dishes. Reported at INR 1,800 ++ for two at the time.",
    mustTry: "Nalli Nihari, Kuzhi Paniyaram 'Manchurian', Chettinad mutton sukka tartlets",
    source: "Indulge Express, December 2021",
  },
  {
    title: "Indian Curry Trail",
    period: "Festival concept · 15–30 April (2016)",
    body: "Regional curry festival with Konkan chicken and multigrain pooris, Parsi salli jardaloo marghi with ladi pav, South Indian mutton curry with tawa dosai and Kashmiri bakarkhani.",
    mustTry: "Parsi Salli Jardaloo Marghi",
    source: "HungryForever, 2016",
  },
];

export default function SpecialsPage() {
  const signatures = menu.filter((item) => item.signature);
  const tasting = ["dal-ayna", "tandoori-kasundi-jheenga", "nalli-nihari", "kacche-gosht-ki-biryani", "garlic-naan", "sakora-phirni"];
  const tastingMenu = tasting.map((slug) => menu.find((item) => item.slug === slug)).filter(Boolean);
  const tastingTotal = tastingMenu.reduce((sum, item) => sum + (item?.price ?? 0), 0);

  return (
    <div className="pt-28">
      <section className="mx-auto max-w-7xl px-5 pb-10 lg:px-8">
        <SectionHeading
          eyebrow="Our specials"
          script="What people come back for"
          title="Signature dishes & festivals"
          intro="Signature status here means the dish has been named in a published guest review, in a press review of Ayna, or in a third-party 'known for' list — not that we decided it ourselves."
        />
      </section>

      <section className="mx-auto max-w-7xl px-5 pb-20 lg:px-8">
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {signatures.map((item, i) => (
            <Reveal key={item.slug} delay={i * 70}>
              <DishCard item={item} priority={i < 3} />
            </Reveal>
          ))}
        </div>
      </section>

      {/* chef's journey */}
      <section className="relative overflow-hidden py-24">
        <div
          aria-hidden
          className="pointer-events-none absolute inset-0 -z-10"
          style={{ background: "linear-gradient(150deg, rgba(74,18,32,.45), rgba(4,18,12,1) 65%)" }}
        />
        <div className="mx-auto grid max-w-7xl items-center gap-14 px-5 lg:grid-cols-2 lg:px-8">
          <Reveal>
            <div>
              <p className="eyebrow">Chef&apos;s journey</p>
              <p className="script gold-text mt-3 text-4xl">A table-length tasting</p>
              <h2 className="mt-2 text-3xl font-light text-gold-50 sm:text-4xl">
                Six plates that cross the country
              </h2>
              <p className="mt-6 text-base leading-relaxed text-emerald-50/72">
                Order these together and you travel from Ambala to Chennai in one sitting. This is a
                suggestion built from verified dishes, not an official tasting menu — prices are
                indicative and the kitchen&apos;s actual set menus change with the seasons.
              </p>

              <ol className="mt-8 space-y-3">
                {tastingMenu.map((item, index) => (
                  <li
                    key={item?.slug}
                    className="flex items-start gap-4 rounded-2xl glass-soft px-4 py-3"
                  >
                    <span className="mt-0.5 grid h-7 w-7 shrink-0 place-items-center rounded-full bg-gold-400/90 text-xs font-bold text-forest-950">
                      {index + 1}
                    </span>
                    <span className="flex-1">
                      <span className="block font-[family-name:var(--font-cormorant)] text-lg text-gold-50">
                        {item?.name}
                      </span>
                      <span className="mt-0.5 block text-xs uppercase tracking-[0.14em] text-emerald-50/45">
                        {item?.region}
                      </span>
                    </span>
                  </li>
                ))}
              </ol>

              <p className="mt-5 text-sm text-emerald-50/60">
                Indicative total for the six dishes:{" "}
                <strong className="text-gold-200">₹{tastingTotal.toLocaleString("en-IN")}</strong>{" "}
                (excl. taxes & beverages).
              </p>

              <div className="mt-8 flex flex-wrap gap-3">
                <Link href="/order" className="btn-gold">
                  Pre-order these dishes
                </Link>
                <ReserveButton className="btn-ghost" label="Reserve on Google" />
              </div>
            </div>
          </Reveal>

          <Reveal delay={130}>
            <Parallax speed={0.12}>
              <TiltCard className="overflow-hidden rounded-[2rem]" intensity={7}>
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src="/images/dish-biryani.jpg"
                  alt="AI-generated illustration of Hyderabadi lamb biryani"
                  loading="lazy"
                  className="h-[30rem] w-full object-cover"
                />
                <span className="absolute right-4 top-4 rounded-full bg-forest-950/75 px-2.5 py-1 text-[0.6rem] uppercase tracking-[0.18em] text-gold-200/80 ring-1 ring-gold-400/25">
                  AI-generated illustration
                </span>
              </TiltCard>
            </Parallax>
          </Reveal>
        </div>
      </section>

      {/* festivals */}
      <section className="py-24">
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <SectionHeading
            eyebrow="Festivals & limited runs"
            script="Seasonal kitchens"
            title="Food festivals Ayna has hosted"
            intro="Ayna runs regional festivals through the year. Availability changes — always confirm what is currently on by phone or WhatsApp before you plan a visit."
          />
          <div className="mt-14 grid gap-6 md:grid-cols-2">
            {festivals.map((festival, i) => (
              <Reveal key={festival.title} delay={i * 80}>
                <article className="h-full rounded-3xl glass p-7">
                  <p className="text-[0.6rem] uppercase tracking-[0.2em] text-gold-200/65">{festival.period}</p>
                  <h3 className="mt-2 font-[family-name:var(--font-cormorant)] text-3xl text-gold-50">
                    {festival.title}
                  </h3>
                  <p className="mt-3 text-sm leading-relaxed text-emerald-50/72">{festival.body}</p>
                  <p className="mt-4 text-sm text-gold-200/85">
                    <span className="text-[0.6rem] uppercase tracking-[0.2em] text-emerald-50/45">Must try · </span>
                    {festival.mustTry}
                  </p>
                  <div className="mt-5">
                    <SourceNote>{festival.source}</SourceNote>
                  </div>
                </article>
              </Reveal>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
