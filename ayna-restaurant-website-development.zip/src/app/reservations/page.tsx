import type { Metadata } from "next";
import { ReservationForm } from "@/components/forms";
import { Reveal } from "@/components/motion";
import { ReserveButton, WhatsAppButton } from "@/components/ui";
import { OpeningHoursTable } from "@/components/opening-hours";
import { contact, externalLinks, priceGuidance } from "@/lib/site-config";

export const metadata: Metadata = {
  title: "Reservations — official Google booking & enquiry form",
  description:
    "Two ways to reserve at Ayna: the official Google reservation page (instant confirmation) or this website's enquiry form, which saves your request for the restaurant team.",
  alternates: { canonical: "/reservations" },
};

export default function ReservationsPage() {
  return (
    <div className="pt-28">
      <section className="mx-auto max-w-7xl px-5 pb-8 lg:px-8">
        <div className="grid gap-4 md:grid-cols-2">
          <Reveal>
            <div className="h-full rounded-3xl glass p-7">
              <p className="eyebrow">Option 1 · recommended</p>
              <h2 className="mt-3 font-[family-name:var(--font-cormorant)] text-3xl text-gold-50">
                Official Google reservation page
              </h2>
              <p className="mt-4 text-sm leading-relaxed text-emerald-50/72">
                Ayna&apos;s live table inventory runs on Google Dining. This is the only channel on this
                site that can confirm a booking in real time. Every &quot;Book a table&quot; button opens
                it in a new tab.
              </p>
              <div className="mt-6">
                <ReserveButton label="Open the Google booking page" />
              </div>
              <p className="mt-4 text-xs leading-relaxed text-emerald-50/50">
                Confirmation, changes and cancellations are handled by that service and by the
                restaurant — not by this website.
              </p>
            </div>
          </Reveal>

          <Reveal delay={120}>
            <div className="h-full rounded-3xl glass p-7">
              <p className="eyebrow">Option 2</p>
              <h2 className="mt-3 font-[family-name:var(--font-cormorant)] text-3xl text-gold-50">
                Website enquiry form
              </h2>
              <p className="mt-4 text-sm leading-relaxed text-emerald-50/72">
                Prefer to describe the occasion, attach a pre-order and wait for the team? This form
                stores your request in the restaurant&apos;s enquiry queue. It is an enquiry — not a
                confirmed reservation.
              </p>
              <div className="mt-6 flex flex-wrap gap-3">
                <WhatsAppButton message="Hello Ayna! I'd like to ask about a table." label="Ask on WhatsApp" />
                <a href={contact.hotelPhoneHref} className="btn-ghost">
                  Call {contact.hotelPhoneDisplay}
                </a>
              </div>
              <p className="mt-4 text-xs leading-relaxed text-emerald-50/50">
                Dinner service 6:30 pm – 11:00 pm daily. {priceGuidance.costForTwo}.
              </p>
            </div>
          </Reveal>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-5 pb-16 lg:px-8">
        <div className="grid gap-10 lg:grid-cols-[1.25fr_1fr]">
          <Reveal>
            <div className="rounded-3xl glass p-7">
              <p className="script gold-text text-3xl">Reservation enquiry</p>
              <p className="mt-2 text-sm text-emerald-50/65">
                Saved to the restaurant&apos;s enquiry queue with a reference you can quote.
              </p>
              <div className="mt-7">
                <ReservationForm />
              </div>
            </div>
          </Reveal>

          <Reveal delay={120}>
            <div className="space-y-6">
              <div className="rounded-3xl glass p-7">
                <p className="text-sm font-semibold text-gold-100">Before you book</p>
                <ul className="mt-4 space-y-3 text-sm leading-relaxed text-emerald-50/70">
                  <li className="flex gap-3">
                    <span aria-hidden className="text-gold-300">1.</span>
                    Dinner is served 6:30 pm – 11:00 pm every day. Lunch availability varies — check
                    the note on the hours table.
                  </li>
                  <li className="flex gap-3">
                    <span aria-hidden className="text-gold-300">2.</span>
                    Parties of 10+ are better handled as a private-dining enquiry so the kitchen can
                    plan.
                  </li>
                  <li className="flex gap-3">
                    <span aria-hidden className="text-gold-300">3.</span>
                    Table booking is recommended (Justdial) — Ayna fills up on weekend evenings.
                  </li>
                  <li className="flex gap-3">
                    <span aria-hidden className="text-gold-300">4.</span>
                    Valet parking is available at the hotel porch; the dining room is step-free via
                    the hotel lifts.
                  </li>
                </ul>
              </div>

              <div className="rounded-3xl burgundy-glass p-7">
                <p className="text-sm font-semibold text-gold-100">What we do not claim</p>
                <p className="mt-3 text-sm leading-relaxed text-emerald-50/72">
                  This website cannot see Google&apos;s table inventory, cannot confirm a reservation, and
                  never charges for one. If a booking must be changed or cancelled, do it through the
                  Google page or by phone.
                </p>
                <a
                  href={externalLinks.reservations}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-4 inline-block text-xs uppercase tracking-[0.18em] text-gold-300/85"
                >
                  Open Google reservations ↗
                </a>
              </div>

              <OpeningHoursTable />
            </div>
          </Reveal>
        </div>
      </section>
    </div>
  );
}
