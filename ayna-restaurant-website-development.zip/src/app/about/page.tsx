import type { Metadata } from "next";
import Link from "next/link";
import { Parallax, Reveal, TiltCard } from "@/components/motion";
import { ReserveButton, SectionHeading } from "@/components/ui";
import { aboutFacts, timeline } from "@/lib/content";
import { pressQuotes } from "@/lib/reviews-data";
import { address, contact } from "@/lib/site-config";

export const metadata: Metadata = {
  title: "About Ayna — the pan-Indian kitchen at Hilton Chennai",
  description:
    "The story of Ayna: opened in 2011 at Hilton Chennai, the first Hilton restaurant in India to serve pan-Indian cuisine, with a timeline, verified facts and press coverage.",
  alternates: { canonical: "/about" },
};

export default function AboutPage() {
  return (
    <div className="pt-28">
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 -z-10">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src="/images/tandoor-chef.jpg"
            alt=""
            aria-hidden
            className="h-full w-full object-cover opacity-30"
          />
          <div aria-hidden className="absolute inset-0 bg-gradient-to-b from-forest-950/85 via-forest-950/92 to-forest-950" />
        </div>

        <div className="mx-auto max-w-4xl px-5 pb-20 pt-10 text-center lg:px-8">
          <p className="eyebrow">About us</p>
          <p className="script gold-text mt-4 text-[clamp(3rem,9vw,5.5rem)] leading-none">Ayna</p>
          <h1 className="mt-4 text-3xl font-light text-gold-50 sm:text-4xl">
            Hindi for mirror — and a reflection of India&apos;s regional kitchens
          </h1>
          <p className="mx-auto mt-7 max-w-2xl text-base leading-relaxed text-emerald-50/72">
            Ayna is the Indian specialty fine-dining restaurant of Hilton Chennai, on the third floor
            above J.N. Salai in Guindy. It opened in 2011, and in 2015 the kitchen rebuilt its menu
            around pan-Indian cooking — the first Hilton restaurant in India to do so — bringing
            Rajasthani, Bengali, Kashmiri, Goan and Awadhi preparations in alongside its North and
            South Indian core.
          </p>
          <div className="mt-9 flex flex-wrap justify-center gap-3">
            <ReserveButton label="Book a table" />
            <Link href="/menu" className="btn-ghost">
              Explore the menu
            </Link>
          </div>
        </div>
      </section>

      {/* facts */}
      <section className="border-y border-gold-400/12 bg-forest-900/40 py-16">
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {aboutFacts.map((fact, i) => (
              <Reveal key={fact.label} delay={i * 70}>
                <div className="h-full rounded-3xl glass-soft p-6">
                  <p className="text-[0.6rem] uppercase tracking-[0.22em] text-gold-200/65">{fact.label}</p>
                  <p className="mt-2 font-[family-name:var(--font-cormorant)] text-xl text-gold-50">{fact.value}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* narrative */}
      <section className="py-24">
        <div className="mx-auto grid max-w-7xl items-start gap-14 px-5 lg:grid-cols-[1.1fr_1fr] lg:px-8">
          <Reveal>
            <div className="space-y-6 text-base leading-relaxed text-emerald-50/72">
              <p className="script gold-text text-4xl">The kitchen</p>
              <h2 className="text-3xl font-light text-gold-50">Pan-Indian, on purpose</h2>
              <p>
                Chennai eats regionally, and Ayna leans into that. The menu moves deliberately between
                the mustard-heavy cooking of Bengal, the coconut and raw-mango gravies of Kerala, the
                pepper-and-star-anise heat of Chettinad, the slow dum of Hyderabad and the refined
                Awadhi repertoire of Lucknow.
              </p>
              <p>
                Press interviews with the kitchen describe roughly 140 items on the expanded menu,
                including lobster and a dedicated seafood list. Reviews repeatedly single out the
                same plates: <strong className="text-gold-200">Dal Ayna</strong> — black urad simmered
                for hours using the hand-blending technique used for haleem — and the{" "}
                <strong className="text-gold-200">Hyderabadi Kacche Gosht ki Biryani</strong>, whose
                lamb marinates for 24 hours before it meets the rice.
              </p>
              <p>
                Since 2021 the kitchen has also plated much of the menu as compact &quot;small
                plates&quot;, so one table can taste six or more regions in a single sitting instead of
                filling up on two curries.
              </p>
              <p className="text-sm text-emerald-50/55">
                Named chefs in published coverage of Ayna include sous chef M. T. Pauljoe (2015
                pan-Indian menu), executive chef Achal Aggarwal (Tiffins of India, 2016) and executive
                chef Avijit Deb Sharma (Small Plates, 2021). Current brigade details are not published.
              </p>
            </div>
          </Reveal>

          <Reveal delay={140}>
            <Parallax speed={0.1}>
              <TiltCard className="overflow-hidden rounded-[2rem]" intensity={6}>
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src="/images/dish-kebab-platter.jpg"
                  alt="AI-generated illustration of a tandoor kebab platter"
                  loading="lazy"
                  className="h-[26rem] w-full object-cover"
                />
                <span className="absolute right-4 top-4 rounded-full bg-forest-950/75 px-2.5 py-1 text-[0.6rem] uppercase tracking-[0.18em] text-gold-200/80 ring-1 ring-gold-400/25">
                  AI-generated illustration
                </span>
              </TiltCard>
            </Parallax>
          </Reveal>
        </div>
      </section>

      {/* timeline */}
      <section className="relative overflow-hidden py-24">
        <div
          aria-hidden
          className="pointer-events-none absolute inset-0 -z-10"
          style={{ background: "linear-gradient(170deg, rgba(74,18,32,.4), rgba(4,18,12,1) 60%)" }}
        />
        <div className="mx-auto max-w-5xl px-5 lg:px-8">
          <SectionHeading eyebrow="Timeline" script="Fifteen years of fire" title="How Ayna evolved" />
          <ol className="relative mt-14 space-y-8 border-l border-gold-400/20 pl-7">
            {timeline.map((entry, i) => (
              <Reveal as="li" key={entry.year} delay={i * 70}>
                <span
                  aria-hidden
                  className="absolute -left-[7px] mt-2 grid h-3.5 w-3.5 place-items-center rounded-full bg-gold-400 ring-4 ring-forest-950"
                />
                <p className="font-[family-name:var(--font-cormorant)] text-3xl text-gold-200">{entry.year}</p>
                <p className="mt-1 text-lg text-gold-50">{entry.title}</p>
                <p className="mt-2 max-w-2xl text-sm leading-relaxed text-emerald-50/68">{entry.body}</p>
              </Reveal>
            ))}
          </ol>
        </div>
      </section>

      {/* press */}
      <section className="py-24">
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <SectionHeading
            eyebrow="In print"
            script="What the press wrote"
            title="Published coverage of Ayna"
            intro="Quotes are reproduced from the original articles, with links so you can read them in full."
          />
          <div className="mt-14 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {pressQuotes.map((quote, i) => (
              <Reveal key={quote.id} delay={i * 70}>
                <figure className="flex h-full flex-col rounded-3xl glass p-6">
                  <blockquote className="flex-1 text-sm leading-relaxed text-emerald-50/75">“{quote.quote}”</blockquote>
                  <figcaption className="mt-5 border-t border-gold-400/15 pt-4">
                    <p className="text-sm text-gold-100">{quote.outlet}</p>
                    <p className="mt-1 text-xs text-emerald-50/50">
                      {quote.headline} · {quote.year}
                    </p>
                    <a
                      href={quote.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="mt-2 inline-block text-xs uppercase tracking-[0.18em] text-gold-300/80 transition hover:text-gold-100"
                    >
                      Read the article ↗
                    </a>
                  </figcaption>
                </figure>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="border-t border-gold-400/12 bg-forest-900/40 py-16">
        <div className="mx-auto max-w-4xl px-5 text-center lg:px-8">
          <p className="script gold-text text-3xl">Come and see for yourself</p>
          <p className="mt-3 text-sm text-emerald-50/70">
            {address.line1}, {address.line2}, {address.city} {address.postalCode} ·{" "}
            <a href={contact.hotelPhoneHref} className="text-gold-200 underline underline-offset-4">
              {contact.hotelPhoneDisplay}
            </a>
          </p>
          <div className="mt-7 flex flex-wrap justify-center gap-3">
            <ReserveButton label="Reserve on Google" />
            <Link href="/visit" className="btn-ghost">
              Directions & hours
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
