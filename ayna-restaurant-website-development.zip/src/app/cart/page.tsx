import type { Metadata } from "next";
import Link from "next/link";
import { CartView } from "@/components/cart-view";
import { SectionHeading } from "@/components/ui";

export const metadata: Metadata = {
  title: "Pre-order basket",
  description: "Review the dishes in your Ayna pre-order basket, adjust quantities and continue to checkout.",
  alternates: { canonical: "/cart" },
  robots: { index: false, follow: false },
};

export default function CartPage() {
  return (
    <div className="pt-28">
      <section className="mx-auto max-w-7xl px-5 pb-8 lg:px-8">
        <SectionHeading
          eyebrow="Basket"
          script="Your pre-order"
          title="Check your table"
          intro="Quantities, dish summaries and an indicative total. Nothing is charged here — the bill is settled at the restaurant."
        />
      </section>

      <section className="mx-auto max-w-7xl px-5 pb-24 lg:px-8">
        <CartView>
          <Link href="/checkout" className="btn-gold mt-5 w-full">
            Continue to checkout
          </Link>
        </CartView>
      </section>
    </div>
  );
}
