import type { Metadata } from "next";
import { EventForm } from "@/components/forms";
import { Parallax, Reveal, TiltCard } from "@/components/motion";
import { ReserveButton, SectionHeading, WhatsAppButton } from "@/components/ui";
import { pressQuotes } from "@/lib/reviews-data";
import { contact } from "@/lib/site-config";

export const metadata: Metadata = {
  title: "Events, celebrations, private dining & group bookings",
  description:
    "Ayna lists a private dining area and regularly hosts celebrations. Enquire about birthdays, anniversaries, corporate dinners and group tables — enquiry only, not a confirmed booking.",
  alternates: { canonical: "/events" },
};

const occasions = [
  {
    title: "Birthdays & anniversaries",
    body: "Guests repeatedly mark personal milestones here — Tripadvisor reviews describe Ayna as a 'calm and welcoming ambience for all special occasions'.",
  },
  {
    title: "Business dinners",
    body: "A 2023 review describes a colleague dinner at Ayna with 'cozy atmosphere and comfortable sofas' and staff who explained each dish.",
  },
  {
    title: "Family tables",
    body: "Kid-friendly, high chairs available, and a vegetarian repertoire large enough for mixed-diet families.",
  },
  {
    title: "Festival & regional menus",
    body: "Ayna has run regional festivals (Shaan-E-Punjab, Tiffins of India, Indian Curry Trail) that can anchor a larger group dinner.",
  },
];

export default function EventsPage() {
  return (
    <div className="pt-28">
      <section className="mx-auto max-w-7xl px-5 pb-10 lg:px-8">
        <SectionHeading
          eyebrow="Events & private dining"
          script="Rooms for a celebration"
          title="Group tables, private dining, occasions"
          intro="Tripadvisor and Justdial both list a private dining area at Ayna, and guest reviews regularly mention celebrations. This page collects your enquiry for the hotel's events team — it does not confirm a booking or a price."
        />
      </section>

      <section className="mx-auto max-w-7xl px-5 pb-16 lg:px-8">
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {occasions.map((occasion, i) => (
            <Reveal key={occasion.title} delay={i * 80}>
              <div className="h-full rounded-3xl glass-soft p-6">
                <p className="font-[family-name:var(--font-cormorant)] text-2xl text-gold-100">{occasion.title}</p>
                <p className="mt-3 text-sm leading-relaxed text-emerald-50/68">{occasion.body}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      <section className="relative overflow-hidden py-20">
        <div className="absolute inset-0 -z-10">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src="/images/private-dining.jpg"
            alt=""
            aria-hidden
            loading="lazy"
            className="h-full w-full object-cover opacity-30"
          />
          <div aria-hidden className="absolute inset-0 bg-gradient-to-b from-forest-950 via-forest-950/88 to-forest-950" />
        </div>

        <div className="mx-auto grid max-w-7xl items-start gap-12 px-5 lg:grid-cols-[1fr_1.05fr] lg:px-8">
          <Reveal>
            <div>
              <p className="eyebrow">Planning</p>
              <p className="script gold-text mt-3 text-4xl">How a group dinner comes together</p>
              <ol className="mt-8 space-y-4">
                {[
                  "Send the enquiry below with your date, guest count and occasion.",
                  "The hotel's events team responds by phone or e-mail with availability.",
                  "Confirm the final menu, seating and beverage package with them directly.",
                  "Share dietary needs in advance — the kitchen adapts spice and prepares Jain/vegan plates.",
                ].map((step, index) => (
                  <li key={step} className="flex gap-4 rounded-2xl glass-soft px-4 py-3">
                    <span className="mt-0.5 grid h-7 w-7 shrink-0 place-items-center rounded-full bg-gold-400/90 text-xs font-bold text-forest-950">
                      {index + 1}
                    </span>
                    <span className="text-sm leading-relaxed text-emerald-50/75">{step}</span>
                  </li>
                ))}
              </ol>

              <div className="mt-8 rounded-3xl burgundy-glass p-6">
                <p className="text-sm font-semibold text-gold-100">Honest scope</p>
                <p className="mt-2 text-sm leading-relaxed text-emerald-50/72">
                  We can only state what the public listings confirm: a private dining area exists and
                  celebrations happen here. capacities, minimum spends and set-menu pricing are not
                  published, so we do not quote them. Call {contact.hotelPhoneDisplay} for specifics.
                </p>
              </div>

              <div className="mt-6 overflow-hidden rounded-3xl">
                <Parallax speed={0.08}>
                  <TiltCard className="overflow-hidden rounded-3xl" intensity={5}>
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src="/images/private-dining.jpg"
                      alt="AI-generated illustration of a private dining room"
                      loading="lazy"
                      className="h-56 w-full object-cover"
                    />
                    <span className="absolute left-3 top-3 rounded-full bg-forest-950/75 px-2.5 py-1 text-[0.6rem] uppercase tracking-[0.18em] text-gold-200/80 ring-1 ring-gold-400/25">
                      AI illustration
                    </span>
                  </TiltCard>
                </Parallax>
              </div>
            </div>
          </Reveal>

          <Reveal delay={120}>
            <div className="rounded-3xl glass p-7">
              <p className="script gold-text text-3xl">Event enquiry</p>
              <p className="mt-2 text-sm text-emerald-50/65">
                Saved with a reference number; the team responds during working hours.
              </p>
              <div className="mt-7">
                <EventForm />
              </div>
              <div className="mt-6 flex flex-wrap gap-3 border-t border-gold-400/15 pt-5">
                <WhatsAppButton message="Hello Ayna! I'd like to plan a private dining event." label="WhatsApp" />
                <ReserveButton className="btn-ghost" label="Reserve a normal table" />
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-5 pb-24 lg:px-8">
        <SectionHeading eyebrow="In print" script="What critics sat down to" title="Press on Ayna's menus" />
        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {pressQuotes.slice(0, 3).map((quote, i) => (
            <Reveal key={quote.id} delay={i * 80}>
              <figure className="flex h-full flex-col rounded-3xl glass p-6">
                <blockquote className="flex-1 text-sm leading-relaxed text-emerald-50/75">“{quote.quote}”</blockquote>
                <figcaption className="mt-4 border-t border-gold-400/15 pt-4 text-xs text-emerald-50/50">
                  {quote.outlet} · {quote.year} ·{" "}
                  <a href={quote.url} target="_blank" rel="noopener noreferrer" className="text-gold-300/85">
                    source ↗
                  </a>
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </div>
      </section>
    </div>
  );
}
