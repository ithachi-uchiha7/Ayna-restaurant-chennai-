import type { Metadata } from "next";
import Link from "next/link";
import { Reveal } from "@/components/motion";
import { ReserveButton, SectionHeading } from "@/components/ui";
import { faqs } from "@/lib/content";

export const metadata: Metadata = {
  title: "Frequently asked questions",
  description:
    "Answers about Ayna's hours, reservations, delivery, cuisine, cost, parking, private dining, vegetarian options and the imagery used on this website.",
  alternates: { canonical: "/faq" },
};

export default function FaqPage() {
  return (
    <div className="pt-28">
      <section className="mx-auto max-w-7xl px-5 pb-10 lg:px-8">
        <SectionHeading
          eyebrow="FAQ"
          script="Good questions"
          title="Everything guests ask us"
          intro="If an answer is not publicly documented, we say so rather than guess."
        />
      </section>

      <section className="mx-auto max-w-4xl px-5 pb-24 lg:px-8">
        <div className="space-y-3">
          {faqs.map((faq, index) => (
            <Reveal key={faq.q} delay={Math.min(index * 45, 400)}>
              <details className="group rounded-3xl glass px-6 py-5 [&_summary::-webkit-details-marker]:hidden">
                <summary className="flex cursor-pointer items-start justify-between gap-4">
                  <span className="font-[family-name:var(--font-cormorant)] text-xl text-gold-50">{faq.q}</span>
                  <span
                    aria-hidden
                    className="mt-1 shrink-0 text-gold-300 transition group-open:rotate-45"
                  >
                    +
                  </span>
                </summary>
                <div className="mt-4 space-y-3 border-t border-gold-400/12 pt-4 text-sm leading-relaxed text-emerald-50/72">
                  <p>{faq.a}</p>
                  {faq.source ? (
                    <p className="text-xs text-emerald-50/45">Source: {faq.source}</p>
                  ) : null}
                </div>
              </details>
            </Reveal>
          ))}
        </div>

        <div id="cookies" className="mt-14 scroll-mt-28 rounded-3xl glass p-7">
          <p className="script gold-text text-2xl">Cookies & analytics</p>
          <p className="mt-3 text-sm leading-relaxed text-emerald-50/70">
            This website sets exactly one cookie: <code className="text-gold-200">ayna_session</code>,
            an HttpOnly session cookie used only when you sign in. Your pre-order basket is kept in
            your browser&apos;s local storage, never on our server until you submit it. No advertising,
            tracking or social-media pixels are used.
          </p>
        </div>

        <div id="accessibility" className="mt-6 scroll-mt-28 rounded-3xl glass p-7">
          <p className="script gold-text text-2xl">Accessibility</p>
          <p className="mt-3 text-sm leading-relaxed text-emerald-50/70">
            The site is built to WCAG-minded basics: semantic landmarks, labelled form fields with
            inline error messages, visible focus rings, keyboard-operable gallery lightbox, skip-to-content
            link, and full <code className="text-gold-200">prefers-reduced-motion</code> support that
            disables parallax and animation. Tripadvisor and Justdial list Ayna as wheelchair
            accessible, with step-free access via the hotel lifts. Tell us about a specific need via
            the{" "}
            <Link href="/contact" className="text-gold-200 underline underline-offset-4">
              contact form
            </Link>{" "}
            and we&apos;ll pass it to the team.
          </p>
        </div>

        <div className="mt-12 text-center">
          <ReserveButton label="Reserve a table" />
          <p className="mt-4 text-xs text-emerald-50/45">
            Something we haven&apos;t answered?{" "}
            <Link href="/contact" className="text-gold-200 underline underline-offset-4">
              Ask us directly
            </Link>
            .
          </p>
        </div>
      </section>
    </div>
  );
}
