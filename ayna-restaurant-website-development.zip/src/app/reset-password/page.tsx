import type { Metadata } from "next";
import { ResetPasswordForm } from "@/components/auth-forms";

export const metadata: Metadata = {
  title: "Set a new password",
  description: "Choose a new password for your Ayna account using your single-use recovery link.",
  alternates: { canonical: "/reset-password" },
  robots: { index: false, follow: false },
};

export default async function ResetPasswordPage({
  searchParams,
}: {
  searchParams: Promise<{ token?: string }>;
}) {
  const { token } = await searchParams;

  return (
    <div className="flex min-h-[100svh] items-center justify-center px-5 py-32">
      <div className="w-full max-w-md rounded-3xl glass p-8">
        <p className="script gold-text text-4xl">New password</p>
        <p className="mt-2 text-sm text-emerald-50/65">
          Recovery links are single-use and expire 60 minutes after they are issued.
        </p>
        <div className="mt-7">
          <ResetPasswordForm token={token ?? ""} />
        </div>
      </div>
    </div>
  );
}
