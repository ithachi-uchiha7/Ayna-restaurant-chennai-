import { eq } from "drizzle-orm";
import { db } from "@/db";
import { menuItems, preOrders } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { clientKey, rateLimit, safeError, tooMany } from "@/lib/rate-limit";
import { fail, invalid, ok, readJson } from "@/lib/api";
import { preOrderSchema } from "@/lib/validation";
import { referenceCode, summariseCart } from "@/lib/cart";

export async function POST(request: Request) {
  const limit = rateLimit(clientKey(request, "preorder"), { limit: 8, windowSeconds: 600 });
  if (!limit.ok) return tooMany(limit);

  const body = await readJson(request);
  if (!body.ok) return body.response;

  const parsed = preOrderSchema.safeParse(body.data);
  if (!parsed.success) return invalid(parsed.error);
  const data = parsed.data;

  const user = await getCurrentUser();
  const rows = await db.select().from(menuItems).where(eq(menuItems.available, true));
  const bySlug = new Map(rows.map((r) => [r.slug, r]));

  const items: { slug: string; name: string; qty: number; priceMinor: number; indicative: boolean }[] = [];
  for (const line of data.items) {
    const row = bySlug.get(line.slug);
    if (!row) continue;
    items.push({
      slug: row.slug,
      name: row.name,
      qty: line.qty,
      priceMinor: row.priceMinor,
      indicative: true,
    });
  }
  if (items.length === 0) return fail("None of the selected dishes are currently available. Please refresh.", 422);

  const indicativeTotalMinor = items.reduce((sum, item) => sum + item.priceMinor * item.qty, 0);

  try {
    const reference = referenceCode("AYO");
    const inserted = await db
      .insert(preOrders)
      .values({
        reference,
        userId: user?.id ?? null,
        fullName: data.fullName,
        email: data.email,
        phone: data.phone,
        serviceType: data.serviceType,
        preferredDate: data.preferredDate ? data.preferredDate : null,
        preferredTime: data.preferredTime ? data.preferredTime : null,
        guests: data.guests ?? null,
        items,
        indicativeTotalMinor,
        notes: data.notes ? data.notes : null,
        status: "received",
        // No payment gateway is configured for this project: nothing is charged.
        paymentStatus: "not-applicable",
      })
      .returning();

    const summary = summariseCart(data.items);
    return ok(
      {
        reference: inserted[0].reference,
        indicativeTotal: summary.indicativeTotal,
        itemCount: summary.count,
        message:
          "Pre-order received and stored. Ayna's team will confirm it by phone or WhatsApp. Delivery orders are handled on Zomato.",
      },
      201,
    );
  } catch {
    return safeError("We could not save your pre-order. Please try WhatsApp on +91 95000 11940.");
  }
}


