import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import {
  contactMessages,
  eventEnquiries,
  newsletterSubscribers,
  preOrders,
  reservationRequests,
} from "@/db/schema";
import { requireAdmin } from "@/lib/auth";
import { fail, ok } from "@/lib/api";

export const dynamic = "force-dynamic";

export async function GET() {
  const admin = await requireAdmin();
  if (!admin) return fail("Admin access required.", 403);

  const [reservations, orders, messages, events, subscribers] = await Promise.all([
    db.select().from(reservationRequests).orderBy(desc(reservationRequests.createdAt)).limit(100),
    db.select().from(preOrders).orderBy(desc(preOrders.createdAt)).limit(100),
    db.select().from(contactMessages).orderBy(desc(contactMessages.createdAt)).limit(100),
    db.select().from(eventEnquiries).orderBy(desc(eventEnquiries.createdAt)).limit(100),
    db.select().from(newsletterSubscribers).orderBy(desc(newsletterSubscribers.createdAt)).limit(100),
  ]);

  return ok({
    reservations,
    orders,
    messages,
    events,
    subscribers,
    counts: {
      reservations: reservations.length,
      newReservations: reservations.filter((r) => r.status === "new").length,
      orders: orders.length,
      newOrders: orders.filter((o) => o.status === "received").length,
      messages: messages.length,
      newMessages: messages.filter((m) => m.status === "new").length,
      events: events.length,
      subscribers: subscribers.length,
    },
  });
}

const allowed = ["new", "contacted", "confirmed", "cancelled", "received", "closed"] as const;

export async function PATCH(request: Request) {
  const admin = await requireAdmin();
  if (!admin) return fail("Admin access required.", 403);

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return fail("Invalid body.", 400);
  }

  const { kind, id, status } = (body ?? {}) as { kind?: string; id?: number; status?: string };
  if (!kind || typeof id !== "number" || !status || !(allowed as readonly string[]).includes(status)) {
    return fail("Provide kind, id and a valid status.", 422);
  }

  const table =
    kind === "reservation"
      ? reservationRequests
      : kind === "order"
        ? preOrders
        : kind === "message"
          ? contactMessages
          : kind === "event"
            ? eventEnquiries
            : null;
  if (!table) return fail("Unknown record type.", 400);

  await db.update(table).set({ status }).where(eq(table.id, id));
  return ok({ updated: { kind, id, status } });
}
