import { db } from "@/db";
import { contactMessages } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { clientKey, rateLimit, safeError, tooMany } from "@/lib/rate-limit";
import { invalid, ok, readJson } from "@/lib/api";
import { contactSchema } from "@/lib/validation";
import { referenceCode } from "@/lib/cart";

export async function POST(request: Request) {
  const limit = rateLimit(clientKey(request, "contact"), { limit: 6, windowSeconds: 600 });
  if (!limit.ok) return tooMany(limit);

  const body = await readJson(request);
  if (!body.ok) return body.response;

  const parsed = contactSchema.safeParse(body.data);
  if (!parsed.success) return invalid(parsed.error);
  const data = parsed.data;
  const user = await getCurrentUser();

  try {
    const reference = referenceCode("AYC");
    await db.insert(contactMessages).values({
      reference,
      userId: user?.id ?? null,
      fullName: data.fullName,
      email: data.email,
      phone: data.phone ? data.phone : null,
      topic: data.topic,
      message: data.message,
    });
    return ok(
      {
        reference,
        message:
          "Message stored. The Hilton Chennai team responds to enquiries during working hours — for anything urgent please call +91 44 2225 5555.",
      },
      201,
    );
  } catch {
    return safeError("We could not send your message. Please WhatsApp +91 95000 11940.");
  }
}
