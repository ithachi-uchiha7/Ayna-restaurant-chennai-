import { computeOpenStatus } from "@/lib/hours";
import { ok } from "@/lib/api";

export const dynamic = "force-dynamic";

export async function GET() {
  const status = computeOpenStatus(new Date());
  return ok({
    isOpen: status.isOpen,
    label: status.label,
    detail: status.detail,
    closesInMinutes: status.closesInMinutes,
    serverIsoTime: new Date().toISOString(),
  });
}
