import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { menuItems } from "@/db/schema";
import { ok } from "@/lib/api";

export const dynamic = "force-dynamic";

/** Public, read-only menu feed used by the menu page and the pre-order flow. */
export async function GET(request: Request) {
  const url = new URL(request.url);
  const category = url.searchParams.get("category");
  const diet = url.searchParams.get("diet");
  const q = url.searchParams.get("q")?.trim().toLowerCase();

  const rows = await db
    .select()
    .from(menuItems)
    .where(eq(menuItems.available, true))
    .orderBy(asc(menuItems.category), asc(menuItems.name));

  const filtered = rows.filter((row) => {
    if (category && category !== "all" && row.category !== category) return false;
    if (diet && diet !== "all" && row.diet !== diet) return false;
    if (q) {
      const haystack = `${row.name} ${row.description} ${row.region} ${row.category}`.toLowerCase();
      if (!haystack.includes(q)) return false;
    }
    return true;
  });

  return ok({
    count: filtered.length,
    items: filtered.map((row) => ({
      slug: row.slug,
      name: row.name,
      category: row.category,
      region: row.region,
      description: row.description,
      diet: row.diet,
      spice: row.spice,
      price: row.priceMinor / 100,
      signature: row.signature,
      source: row.source,
    })),
  });
}
