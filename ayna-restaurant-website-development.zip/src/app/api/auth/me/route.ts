import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { getCurrentUser, toPublicUser } from "@/lib/auth";
import { ok } from "@/lib/api";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return ok({ user: null });
  const fresh = await db.select().from(users).where(eq(users.id, user.id)).limit(1);
  return ok({ user: toPublicUser(fresh[0] ?? user) });
}
