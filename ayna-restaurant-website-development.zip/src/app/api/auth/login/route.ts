import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { createSession, toPublicUser, verifyPassword } from "@/lib/auth";
import { clientKey, rateLimit, tooMany } from "@/lib/rate-limit";
import { fail, invalid, ok, readJson } from "@/lib/api";
import { loginSchema } from "@/lib/validation";

export async function POST(request: Request) {
  const limit = rateLimit(clientKey(request, "login"), { limit: 10, windowSeconds: 300 });
  if (!limit.ok) return tooMany(limit);

  const body = await readJson(request);
  if (!body.ok) return body.response;

  const parsed = loginSchema.safeParse(body.data);
  if (!parsed.success) return invalid(parsed.error);

  const rows = await db.select().from(users).where(eq(users.email, parsed.data.email)).limit(1);
  const user = rows[0];
  // Always return a generic message so we do not reveal which e-mails exist.
  if (!user || !(await verifyPassword(parsed.data.password, user.passwordHash))) {
    return fail("Those details did not match an account. Please try again.", 401);
  }

  await createSession(user.id, request.headers.get("user-agent"));
  return ok({ user: toPublicUser(user) });
}
