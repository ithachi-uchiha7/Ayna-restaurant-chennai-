import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { getCurrentUser, toPublicUser } from "@/lib/auth";
import { clientKey, rateLimit, tooMany, safeError } from "@/lib/rate-limit";
import { fail, invalid, ok, readJson } from "@/lib/api";
import { profileSchema } from "@/lib/validation";

export async function PATCH(request: Request) {
  const limit = rateLimit(clientKey(request, "profile"), { limit: 20, windowSeconds: 300 });
  if (!limit.ok) return tooMany(limit);

  const user = await getCurrentUser();
  if (!user) return fail("Please sign in to update your profile.", 401);

  const body = await readJson(request);
  if (!body.ok) return body.response;

  const parsed = profileSchema.safeParse(body.data);
  if (!parsed.success) return invalid(parsed.error);

  const { fullName, phone, dietaryPreference, marketingOptIn, notes } = parsed.data;
  const updated = await db
    .update(users)
    .set({
      fullName,
      phone: phone ? phone : null,
      dietaryPreference: dietaryPreference && dietaryPreference !== "none" ? dietaryPreference : null,
      marketingOptIn: Boolean(marketingOptIn),
      notes: notes ? notes : null,
      updatedAt: new Date(),
    })
    .where(eq(users.id, user.id))
    .returning();

  if (!updated[0]) return safeError();
  return ok({ user: toPublicUser(updated[0]) });
}
