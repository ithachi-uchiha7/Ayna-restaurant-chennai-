import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { consumeResetToken, createSession, hashPassword, toPublicUser } from "@/lib/auth";
import { clientKey, rateLimit, safeError, tooMany } from "@/lib/rate-limit";
import { fail, invalid, ok, readJson } from "@/lib/api";
import { resetPasswordSchema } from "@/lib/validation";

export async function POST(request: Request) {
  const limit = rateLimit(clientKey(request, "reset"), { limit: 10, windowSeconds: 900 });
  if (!limit.ok) return tooMany(limit);

  const body = await readJson(request);
  if (!body.ok) return body.response;

  const parsed = resetPasswordSchema.safeParse(body.data);
  if (!parsed.success) return invalid(parsed.error);

  try {
    const userId = await consumeResetToken(parsed.data.token);
    if (!userId) return fail("That recovery link is invalid or has expired. Request a new one.", 400);

    const updated = await db
      .update(users)
      .set({ passwordHash: await hashPassword(parsed.data.password), updatedAt: new Date() })
      .where(eq(users.id, userId))
      .returning();

    if (!updated[0]) return safeError();
    await createSession(userId, request.headers.get("user-agent"));
    return ok({ user: toPublicUser(updated[0]), message: "Password updated. You are signed in." });
  } catch {
    return safeError();
  }
}
