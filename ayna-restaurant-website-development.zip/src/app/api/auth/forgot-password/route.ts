import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { issueResetToken } from "@/lib/auth";
import { clientKey, rateLimit, safeError, tooMany } from "@/lib/rate-limit";
import { invalid, ok, readJson } from "@/lib/api";
import { forgotPasswordSchema } from "@/lib/validation";

async function sendResetEmail(to: string, link: string): Promise<boolean> {
  const apiKey = process.env.RESEND_API_KEY;
  const from = process.env.RESET_EMAIL_FROM;
  if (!apiKey || !from) return false;
  try {
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        from,
        to,
        subject: "Reset your Ayna Chennai account password",
        html: `<p>We received a request to reset the password for your Ayna Chennai account.</p>
               <p>This one-time link is valid for 60 minutes:<br/><a href="${link}">${link}</a></p>
               <p>If you did not request this, you can ignore this e-mail.</p>`,
      }),
    });
    return res.ok;
  } catch {
    return false;
  }
}

export async function POST(request: Request) {
  const limit = rateLimit(clientKey(request, "forgot"), { limit: 5, windowSeconds: 900 });
  if (!limit.ok) return tooMany(limit);

  const body = await readJson(request);
  if (!body.ok) return body.response;

  const parsed = forgotPasswordSchema.safeParse(body.data);
  if (!parsed.success) return invalid(parsed.error);

  const rows = await db.select().from(users).where(eq(users.email, parsed.data.email)).limit(1);
  const user = rows[0];

  if (!user) {
    // Do not reveal whether the account exists.
    return ok({ delivered: "email-or-nothing", message: "If that e-mail has an account, a recovery link is on its way." });
  }

  const { token } = await issueResetToken(user.id);
  const origin = process.env.NEXT_PUBLIC_SITE_URL ?? new URL(request.url).origin;
  const link = `${origin}/reset-password?token=${token}`;
  const emailed = await sendResetEmail(user.email, link);

  if (emailed) {
    return ok({
      delivered: "email",
      message: "Check your inbox — a one-time recovery link is valid for 60 minutes.",
    });
  }

  // No e-mail provider configured on this deployment. Surface the link directly
  // so password recovery still works, and say so plainly.
  return ok({
    delivered: "manual",
    message:
      "E-mail delivery is not configured on this deployment, so your one-time recovery link is shown here instead of being e-mailed. It is valid for 60 minutes.",
    resetLink: link,
  });
}
