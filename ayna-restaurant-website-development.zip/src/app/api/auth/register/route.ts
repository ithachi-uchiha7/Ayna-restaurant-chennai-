import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { createSession, hashPassword, toPublicUser } from "@/lib/auth";
import { clientKey, rateLimit, tooMany } from "@/lib/rate-limit";
import { fail, invalid, ok, readJson } from "@/lib/api";
import { registerSchema } from "@/lib/validation";

export async function POST(request: Request) {
  const limit = rateLimit(clientKey(request, "register"), { limit: 6, windowSeconds: 600 });
  if (!limit.ok) return tooMany(limit);

  const body = await readJson(request);
  if (!body.ok) return body.response;

  const parsed = registerSchema.safeParse(body.data);
  if (!parsed.success) return invalid(parsed.error);
  const { fullName, email, phone, password, marketingOptIn } = parsed.data;

  const existing = await db.select({ id: users.id }).from(users).where(eq(users.email, email)).limit(1);
  if (existing.length > 0) {
    return fail("An account with that e-mail already exists. Try signing in instead.", 409);
  }

  const inserted = await db
    .insert(users)
    .values({
      email,
      fullName,
      phone: phone ? phone : null,
      passwordHash: await hashPassword(password),
      marketingOptIn: Boolean(marketingOptIn),
    })
    .returning();

  const user = inserted[0];
  await createSession(user.id, request.headers.get("user-agent"));
  return ok({ user: toPublicUser(user) }, 201);
}
