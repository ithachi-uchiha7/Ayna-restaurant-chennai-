import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { menuItems, reservationRequests } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { clientKey, rateLimit, safeError, tooMany } from "@/lib/rate-limit";
import { fail, invalid, ok, readJson } from "@/lib/api";
import { reservationSchema } from "@/lib/validation";
import { referenceCode } from "@/lib/cart";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return fail("Please sign in to view your reservation enquiries.", 401);
  const rows = await db
    .select()
    .from(reservationRequests)
    .where(eq(reservationRequests.userId, user.id))
    .orderBy(desc(reservationRequests.createdAt))
    .limit(50);
  return ok({ reservations: rows });
}

export async function POST(request: Request) {
  const limit = rateLimit(clientKey(request, "reservation"), { limit: 6, windowSeconds: 600 });
  if (!limit.ok) return tooMany(limit);

  const body = await readJson(request);
  if (!body.ok) return body.response;

  const parsed = reservationSchema.safeParse(body.data);
  if (!parsed.success) return invalid(parsed.error);
  const data = parsed.data;

  const user = await getCurrentUser();

  // Attach pre-order lines to the enquiry (validated against the menu table).
  let preOrder: { slug: string; name: string; qty: number }[] | null = null;
  if (data.items && data.items.length > 0) {
    const rows = await db.select().from(menuItems);
    const bySlug = new Map(rows.map((r) => [r.slug, r]));
    preOrder = data.items
      .map((line) => {
        const item = bySlug.get(line.slug);
        return item ? { slug: item.slug, name: item.name, qty: line.qty } : null;
      })
      .filter((v): v is { slug: string; name: string; qty: number } => v !== null);
    if (preOrder.length === 0) return fail("The dishes you selected are no longer on the menu. Please refresh.", 422);
  }

  try {
    const reference = referenceCode("AYR");
    const inserted = await db
      .insert(reservationRequests)
      .values({
        reference,
        userId: user?.id ?? null,
        fullName: data.fullName,
        email: data.email,
        phone: data.phone,
        date: data.date,
        time: data.time,
        guests: data.guests,
        occasion: data.occasion && data.occasion !== "none" ? data.occasion : null,
        seating: data.seating && data.seating !== "no-preference" ? data.seating : null,
        message: data.message ? data.message : null,
        preOrder,
        channel: "website-enquiry",
        status: "new",
      })
      .returning();

    return ok(
      {
        reference: inserted[0].reference,
        createdAt: inserted[0].createdAt,
        message:
          "Enquiry saved. Ayna's team at Hilton Chennai handles final confirmation — use the official Google reservation page for an instant booking.",
      },
      201,
    );
  } catch {
    return safeError("We could not save your enquiry right now. Please call +91 44 2225 5555.");
  }
}
