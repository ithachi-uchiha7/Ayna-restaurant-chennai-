import { db } from "@/db";
import { newsletterSubscribers } from "@/db/schema";
import { clientKey, rateLimit, safeError, tooMany } from "@/lib/rate-limit";
import { invalid, ok, readJson } from "@/lib/api";
import { newsletterSchema } from "@/lib/validation";

export async function POST(request: Request) {
  const limit = rateLimit(clientKey(request, "newsletter"), { limit: 5, windowSeconds: 600 });
  if (!limit.ok) return tooMany(limit);

  const body = await readJson(request);
  if (!body.ok) return body.response;

  const parsed = newsletterSchema.safeParse(body.data);
  if (!parsed.success) return invalid(parsed.error);

  try {
    await db
      .insert(newsletterSubscribers)
      .values({
        email: parsed.data.email,
        source: parsed.data.source ?? "footer",
      })
      .onConflictDoUpdate({
        target: newsletterSubscribers.email,
        set: { unsubscribedAt: null },
      });
    return ok({
      message:
        "You're on the list. We store only your e-mail address and the page you subscribed from — no payment or identity data.",
    });
  } catch {
    return safeError("Could not subscribe right now. Please try again later.");
  }
}
