import { db } from "@/db";
import { eventEnquiries } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { clientKey, rateLimit, safeError, tooMany } from "@/lib/rate-limit";
import { invalid, ok, readJson } from "@/lib/api";
import { eventSchema } from "@/lib/validation";
import { referenceCode } from "@/lib/cart";

export async function POST(request: Request) {
  const limit = rateLimit(clientKey(request, "events"), { limit: 6, windowSeconds: 600 });
  if (!limit.ok) return tooMany(limit);

  const body = await readJson(request);
  if (!body.ok) return body.response;

  const parsed = eventSchema.safeParse(body.data);
  if (!parsed.success) return invalid(parsed.error);
  const data = parsed.data;
  const user = await getCurrentUser();

  try {
    const reference = referenceCode("AYE");
    await db.insert(eventEnquiries).values({
      reference,
      userId: user?.id ?? null,
      fullName: data.fullName,
      email: data.email,
      phone: data.phone,
      eventType: data.eventType,
      preferredDate: data.preferredDate ? data.preferredDate : null,
      guests: data.guests,
      budget: data.budget ?? null,
      message: data.message ? data.message : null,
    });
    return ok(
      {
        reference,
        message:
          "Event enquiry stored. Ayna's banqueting team at Hilton Chennai will follow up — this form does not confirm a booking.",
      },
      201,
    );
  } catch {
    return safeError("We could not send your enquiry. Please call +91 44 2225 5555.");
  }
}
