import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { LoginForm } from "@/components/auth-forms";
import { getCurrentUser } from "@/lib/auth";

export const metadata: Metadata = {
  title: "Sign in",
  description: "Sign in to your Ayna account to manage your profile, pre-orders and reservation enquiries.",
  alternates: { canonical: "/login" },
  robots: { index: false, follow: false },
};

export default async function LoginPage() {
  const user = await getCurrentUser();
  if (user) redirect(user.role === "admin" ? "/admin" : "/account");

  return (
    <div className="relative flex min-h-[100svh] items-center justify-center overflow-hidden px-5 py-32">
      <div className="absolute inset-0 -z-10">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src="/images/bar-wine.jpg" alt="" aria-hidden className="h-full w-full object-cover opacity-25" />
        <div aria-hidden className="absolute inset-0 bg-gradient-to-b from-forest-950/90 via-forest-950/95 to-forest-950" />
      </div>

      <div className="w-full max-w-md rounded-3xl glass p-8">
        <p className="script gold-text text-4xl">Welcome back</p>
        <p className="mt-2 text-sm text-emerald-50/65">
          Sign in to see your reservation enquiries, pre-orders and saved preferences.
        </p>
        <div className="mt-7">
          <LoginForm />
        </div>
        <p className="mt-6 border-t border-gold-400/15 pt-5 text-xs leading-relaxed text-emerald-50/45">
          Signing in is optional — you can browse the menu, reserve on Google and pre-order without an
          account.{" "}
          <Link href="/" className="text-gold-200/85 underline underline-offset-4">
            Back to the restaurant
          </Link>
        </p>
      </div>
    </div>
  );
}
