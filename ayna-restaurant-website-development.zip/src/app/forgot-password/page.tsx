import type { Metadata } from "next";
import { ForgotPasswordForm } from "@/components/auth-forms";

export const metadata: Metadata = {
  title: "Password recovery",
  description: "Request a single-use password recovery link for your Ayna account.",
  alternates: { canonical: "/forgot-password" },
  robots: { index: false, follow: false },
};

export default function ForgotPasswordPage() {
  return (
    <div className="flex min-h-[100svh] items-center justify-center px-5 py-32">
      <div className="w-full max-w-md rounded-3xl glass p-8">
        <p className="script gold-text text-4xl">Reset your password</p>
        <p className="mt-2 text-sm text-emerald-50/65">
          Enter the e-mail on your account and we&apos;ll issue a single-use recovery link.
        </p>
        <div className="mt-7">
          <ForgotPasswordForm />
        </div>
      </div>
    </div>
  );
}
