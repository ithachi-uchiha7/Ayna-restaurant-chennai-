import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { RegisterForm } from "@/components/auth-forms";
import { getCurrentUser } from "@/lib/auth";

export const metadata: Metadata = {
  title: "Create an account",
  description:
    "Create an Ayna account to keep your pre-order history, dietary preferences and reservation enquiries in one place.",
  alternates: { canonical: "/register" },
  robots: { index: false, follow: false },
};

export default async function RegisterPage() {
  const user = await getCurrentUser();
  if (user) redirect("/account");

  return (
    <div className="relative flex min-h-[100svh] items-center justify-center px-5 py-32">
      <div className="absolute inset-0 -z-10">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src="/images/ambience-table.jpg" alt="" aria-hidden className="h-full w-full object-cover opacity-25" />
        <div aria-hidden className="absolute inset-0 bg-gradient-to-b from-forest-950/90 via-forest-950/95 to-forest-950" />
      </div>

      <div className="w-full max-w-md rounded-3xl glass p-8">
        <p className="script gold-text text-4xl">Join the table</p>
        <p className="mt-2 text-sm text-emerald-50/65">
          One account keeps your dietary preferences, pre-order history and enquiries together.
        </p>
        <div className="mt-7">
          <RegisterForm />
        </div>
      </div>
    </div>
  );
}
