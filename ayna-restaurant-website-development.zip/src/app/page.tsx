import Link from "next/link";
import type { Metadata } from "next";
import { HomeHero } from "@/components/home-hero";
import { CountUp, Parallax, Reveal, TiltCard } from "@/components/motion";
import { DishCard } from "@/components/dish-card";
import { DeliveryButton, ReserveButton, SectionHeading, SourceNote, WhatsAppButton } from "@/components/ui";
import { menu, signatureDishes } from "@/lib/menu-data";
import { aboutFacts, experienceHighlights, gallery } from "@/lib/content";
import { reviews } from "@/lib/reviews-data";
import { address, contact, externalLinks, priceGuidance } from "@/lib/site-config";

export const metadata: Metadata = {
  title: "Ayna — Pan-Indian Fine Dining at Hilton Chennai, Guindy",
  description:
    "Cinematic guide to Ayna, the Indian specialty restaurant on the 3rd floor of Hilton Chennai. Verified menu highlights, signature dishes, hours, reviews, reservations and delivery.",
};

export default function HomePage() {
  const categories = [...new Set(menu.map((item) => item.category))];
  const heroGallery = gallery.slice(0, 5);

  return (
    <>
      <HomeHero />

      {/* ---------------- verified facts strip ---------------- */}
      <section className="relative border-y border-gold-400/15 bg-forest-900/50">
        <div className="mx-auto grid max-w-7xl gap-px px-5 py-12 sm:grid-cols-2 lg:grid-cols-4 lg:px-8">
          {[
            { k: "Cuisine", v: "Pan-Indian · Seafood · Desserts" },
            { k: "Setting", v: "3rd floor, Hilton Chennai" },
            { k: "Meal for two", v: "₹3,000 – ₹3,500 (excl. taxes)" },
            { k: "Dinner", v: "6:30 pm – 11:00 pm daily" },
          ].map((fact, i) => (
            <Reveal key={fact.k} delay={i * 90}>
              <div className="px-2">
                <p className="eyebrow">{fact.k}</p>
                <p className="mt-2 font-[family-name:var(--font-cormorant)] text-xl text-gold-100">{fact.v}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* ---------------- about / discover ---------------- */}
      <section className="relative overflow-hidden py-24" aria-labelledby="discover-heading">
        <div
          aria-hidden
          className="pointer-events-none absolute -left-40 top-20 h-[30rem] w-[30rem] rounded-full opacity-25 blur-3xl"
          style={{ background: "radial-gradient(circle,#1a5438,transparent 70%)" }}
        />
        <div className="mx-auto grid max-w-7xl items-center gap-14 px-5 lg:grid-cols-2 lg:px-8">
          <Reveal>
            <div>
              <p className="eyebrow">Discover Ayna</p>
              <p className="script gold-text mt-3 text-4xl">A mirror of India</p>
              <h2 id="discover-heading" className="mt-2 text-4xl font-light text-gold-50 sm:text-5xl">
                One dining room, <br className="hidden sm:block" />
                four corners of India
              </h2>
              <p className="mt-6 text-base leading-relaxed text-emerald-50/72">
                Ayna takes its name from the Hindi word for mirror — and the kitchen cooks like one.
                Since 2011 it has been Hilton Chennai&apos;s Indian specialty restaurant, and in 2015 it
                became the first Hilton restaurant in India to serve pan-Indian cuisine, adding
                Rajasthani, Bengali, Kashmiri, Goan and Awadhi sections to the existing northern and
                southern repertoire.
              </p>
              <p className="mt-4 text-base leading-relaxed text-emerald-50/72">
                The room is velvet and brass, low-lit and quiet, with a serious wine list and a
                tandoor that never really cools. Guests come for anniversaries, for business dinners,
                and for the Dal Ayna.
              </p>

              <div className="mt-8 grid gap-4 sm:grid-cols-2">
                {aboutFacts.slice(0, 4).map((fact) => (
                  <div key={fact.label} className="rounded-2xl glass-soft px-4 py-3">
                    <p className="text-[0.6rem] uppercase tracking-[0.22em] text-gold-200/65">{fact.label}</p>
                    <p className="mt-1 text-sm text-gold-50/90">{fact.value}</p>
                  </div>
                ))}
              </div>

              <div className="mt-9 flex flex-wrap gap-3">
                <Link href="/about" className="btn-gold">
                  Our story
                </Link>
                <Link href="/venue" className="btn-ghost">
                  See the venue
                </Link>
              </div>
            </div>
          </Reveal>

          <Reveal delay={140}>
            <Parallax speed={0.12}>
              <div className="relative">
                <div className="overflow-hidden rounded-[2rem] gold-border">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src="/images/ambience-table.jpg"
                    alt="AI-generated illustration of a candle-lit fine dining table at Ayna"
                    loading="lazy"
                    className="h-[32rem] w-full object-cover"
                  />
                </div>
                <div className="absolute -bottom-8 -left-4 w-56 overflow-hidden rounded-3xl glass p-4 sm:-left-10">
                  <p className="text-[0.6rem] uppercase tracking-[0.2em] text-gold-200/70">Tripadvisor</p>
                  <p className="mt-1 font-[family-name:var(--font-cormorant)] text-3xl text-gold-100">
                    <CountUp to={169} /> reviews
                  </p>
                  <p className="text-xs text-emerald-50/60">4.7 / 5 · #44 of 5,591 in Chennai</p>
                </div>
                <span className="absolute right-4 top-4 rounded-full bg-forest-950/75 px-2.5 py-1 text-[0.6rem] uppercase tracking-[0.18em] text-gold-200/80 ring-1 ring-gold-400/25">
                  AI-generated illustration
                </span>
              </div>
            </Parallax>
          </Reveal>
        </div>
      </section>

      {/* ---------------- signatures ---------------- */}
      <section className="relative py-24" aria-labelledby="signature-heading">
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <Reveal>
            <SectionHeading
              eyebrow="Our specials"
              script="Chef's signatures"
              title="The dishes Ayna is known for"
              intro="Every plate below appears in published guest reviews or press coverage of Ayna's kitchen — from the dal that simmers for hours to the Hyderabadi biryani whose lamb is marinated for a full day."
            />
          </Reveal>

          <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {signatureDishes.slice(0, 6).map((item, i) => (
              <Reveal key={item.slug} delay={i * 80}>
                <DishCard item={item} priority={i < 3} />
              </Reveal>
            ))}
          </div>

          <div className="mt-10 flex flex-wrap justify-center gap-3">
            <Link href="/specials" className="btn-gold">
              All specials
            </Link>
            <Link href="/menu" className="btn-ghost">
              Full menu & filters
            </Link>
          </div>
        </div>
      </section>

      {/* ---------------- gallery strip ---------------- */}
      <section className="relative py-24" aria-labelledby="gallery-heading">
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <Reveal>
            <SectionHeading
              eyebrow="The room"
              script="Green velvet & gold"
              title="Atmosphere, first"
              intro="Every image here is AI-generated illustration created for this guide — clearly labelled. For genuine photographs taken inside Ayna, Tripadvisor hosts 91 candid guest photos."
            />
          </Reveal>

          <div className="mt-14 grid auto-rows-[13rem] grid-cols-2 gap-4 md:grid-cols-4">
            {heroGallery.map((shot, i) => (
              <Reveal
                key={shot.src}
                delay={i * 70}
                className={shot.span === "wide" ? "col-span-2" : shot.span === "tall" ? "row-span-2" : ""}
              >
                <TiltCard className="h-full overflow-hidden rounded-2xl" intensity={6}>
                  <Link href="/gallery" className="group block h-full">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={shot.src}
                      alt={shot.alt}
                      loading="lazy"
                      className="h-full w-full object-cover transition duration-[1400ms] group-hover:scale-110"
                    />
                    <span className="pointer-events-none absolute inset-0 bg-gradient-to-t from-forest-950/85 via-transparent to-transparent" />
                    <span className="pointer-events-none absolute bottom-3 left-3 right-3 text-[0.68rem] uppercase tracking-[0.16em] text-gold-100/85">
                      {shot.caption}
                    </span>
                  </Link>
                </TiltCard>
              </Reveal>
            ))}
          </div>

          <div className="mt-10 flex flex-wrap justify-center gap-3">
            <Link href="/gallery" className="btn-gold">
              Open the gallery
            </Link>
            <a
              href={externalLinks.tripadvisorPhotos}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-ghost"
            >
              Real photos on Tripadvisor ↗
            </a>
          </div>
        </div>
      </section>

      {/* ---------------- experience / facilities ---------------- */}
      <section className="relative overflow-hidden py-24" aria-labelledby="experience-heading">
        <div
          aria-hidden
          className="pointer-events-none absolute inset-0 -z-10 opacity-90"
          style={{
            background:
              "linear-gradient(160deg, rgba(74,18,32,.55) 0%, rgba(10,36,24,.85) 45%, rgba(4,18,12,1) 100%)",
          }}
        />
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <Reveal>
            <SectionHeading
              eyebrow="Dining experience"
              script="Slow fire, sharp spice"
              title="What a table at Ayna feels like"
              intro="Verified facilities and service details, plus the cooking philosophy the kitchen has described in press interviews."
            />
          </Reveal>

          <div className="mt-14 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
            {experienceHighlights.map((item, i) => (
              <Reveal key={item.title} delay={i * 70}>
                <div className="h-full rounded-3xl glass-soft p-6">
                  <p className="font-[family-name:var(--font-cormorant)] text-2xl text-gold-100">{item.title}</p>
                  <p className="mt-3 text-sm leading-relaxed text-emerald-50/70">{item.body}</p>
                </div>
              </Reveal>
            ))}
          </div>

          <div className="mt-10 flex flex-wrap justify-center gap-3">
            <Link href="/venue" className="btn-ghost">
              Facilities & accessibility
            </Link>
            <Link href="/events" className="btn-ghost">
              Private dining & celebrations
            </Link>
          </div>
        </div>
      </section>

      {/* ---------------- reviews ---------------- */}
      <section className="relative py-24" aria-labelledby="reviews-heading">
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <Reveal>
            <SectionHeading
              eyebrow="Guest reviews"
              script="In their words"
              title="Real reviews, real sources"
              intro="Nothing on this page is invented. Every quote links back to the platform where it was published."
            />
          </Reveal>

          <div className="mt-14 grid gap-6 md:grid-cols-3">
            {reviews.slice(0, 3).map((review, i) => (
              <Reveal key={review.id} delay={i * 90}>
                <figure className="flex h-full flex-col rounded-3xl glass p-6">
                  <div aria-hidden className="text-gold-300">
                    ★★★★★
                  </div>
                  <blockquote className="mt-4 flex-1 text-sm leading-relaxed text-emerald-50/78">
                    “{review.quote}”
                  </blockquote>
                  <figcaption className="mt-5 border-t border-gold-400/15 pt-4">
                    <p className="text-sm text-gold-100">{review.title}</p>
                    <p className="mt-1 text-xs text-emerald-50/50">
                      {review.platform} · {review.date}
                    </p>
                    <a
                      href={review.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="mt-2 inline-block text-xs uppercase tracking-[0.18em] text-gold-300/80 transition hover:text-gold-100"
                    >
                      Read the original ↗
                    </a>
                  </figcaption>
                </figure>
              </Reveal>
            ))}
          </div>

          <div className="mt-10 text-center">
            <Link href="/reviews" className="btn-ghost">
              All verified reviews & press
            </Link>
          </div>
        </div>
      </section>

      {/* ---------------- reservations ---------------- */}
      <section className="relative overflow-hidden py-24" aria-labelledby="reserve-heading">
        <div className="absolute inset-0 -z-10">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src="/images/private-dining.jpg"
            alt=""
            aria-hidden
            loading="lazy"
            className="h-full w-full object-cover opacity-35"
          />
          <div aria-hidden className="absolute inset-0 bg-gradient-to-b from-forest-950 via-forest-950/85 to-forest-950" />
        </div>

        <div className="mx-auto max-w-4xl px-5 text-center lg:px-8">
          <Reveal>
            <p className="eyebrow">Reservations</p>
            <p className="script gold-text mt-3 text-4xl">Your table is waiting</p>
            <h2 id="reserve-heading" className="mt-2 text-4xl font-light text-gold-50 sm:text-5xl">
              Two ways to book
            </h2>
            <p className="mx-auto mt-6 max-w-2xl text-base leading-relaxed text-emerald-50/72">
              Ayna&apos;s live bookings run on its official Google reservation page — every{" "}
              <strong className="text-gold-200">Book a table</strong> button here opens it in a new tab.
              This website also offers an <strong className="text-gold-200">enquiry form</strong> that
              saves your request for the restaurant team; it is an enquiry, not a confirmed booking.
            </p>

            <div className="mt-9 flex flex-wrap justify-center gap-3">
              <ReserveButton label="Reserve on Google" />
              <Link href="/reservations" className="btn-ghost">
                Send an enquiry
              </Link>
              <WhatsAppButton message="Hello Ayna! I'd like to enquire about a table." label="WhatsApp" />
            </div>

            <div className="mx-auto mt-12 grid max-w-3xl gap-4 text-left sm:grid-cols-3">
              <div className="rounded-2xl glass-soft p-5">
                <p className="text-[0.6rem] uppercase tracking-[0.2em] text-gold-200/70">Call</p>
                <a href={contact.hotelPhoneHref} className="mt-1 block text-sm text-gold-100">
                  {contact.hotelPhoneDisplay}
                </a>
                <a href={contact.restaurantPhoneHref} className="text-sm text-gold-100">
                  {contact.restaurantPhoneDisplay}
                </a>
              </div>
              <div className="rounded-2xl glass-soft p-5">
                <p className="text-[0.6rem] uppercase tracking-[0.2em] text-gold-200/70">Address</p>
                <p className="mt-1 text-sm text-emerald-50/75">{address.line1}</p>
                <p className="text-sm text-emerald-50/75">{address.line2}</p>
                <p className="text-sm text-emerald-50/75">
                  {address.city} {address.postalCode}
                </p>
              </div>
              <div className="rounded-2xl glass-soft p-5">
                <p className="text-[0.6rem] uppercase tracking-[0.2em] text-gold-200/70">Cost guidance</p>
                <p className="mt-1 text-sm text-emerald-50/75">{priceGuidance.costForTwo}</p>
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      {/* ---------------- delivery ---------------- */}
      <section className="relative py-24" aria-labelledby="order-heading">
        <div className="mx-auto grid max-w-7xl items-center gap-12 px-5 lg:grid-cols-2 lg:px-8">
          <Reveal>
            <div>
              <p className="eyebrow">Delivery & pre-order</p>
              <p className="script gold-text mt-3 text-4xl">Ayna at your table</p>
              <h2 id="order-heading" className="mt-2 text-4xl font-light text-gold-50 sm:text-5xl">
                Order on Zomato, or pre-order for dinner
              </h2>
              <p className="mt-6 text-base leading-relaxed text-emerald-50/72">
                Delivery is fulfilled through Ayna&apos;s official Zomato listing — buttons here open it
                directly. If you&apos;d rather have the kitchen start preparing before you arrive, build a
                pre-order basket: choose dishes, set quantities, and send it with your reservation
                enquiry. No payment is taken on this website.
              </p>
              <div className="mt-8 flex flex-wrap gap-3">
                <DeliveryButton className="btn-gold" label="Order delivery" />
                <Link href="/order" className="btn-ghost">
                  Pre-order for dine-in
                </Link>
                <Link href="/cart" className="btn-ghost">
                  View basket
                </Link>
              </div>
            </div>
          </Reveal>

          <Reveal delay={120}>
            <div className="grid gap-4 sm:grid-cols-2">
              {menu.slice(0, 4).map((item) => (
                <div key={item.slug} className="rounded-3xl glass-soft p-5">
                  <p className="font-[family-name:var(--font-cormorant)] text-lg text-gold-100">{item.name}</p>
                  <p className="mt-2 line-clamp-2 text-xs leading-relaxed text-emerald-50/60">{item.description}</p>
                  <SourceNote>{item.source}</SourceNote>
                </div>
              ))}
            </div>
          </Reveal>
        </div>
      </section>
    </>
  );
}
