/**
 * Seed script — run after `npx drizzle-kit push`:
 *   npx tsx --env-file=.env src/db/seed.ts
 *
 * Idempotent: safe to run repeatedly.
 */
import "dotenv/config";
import { eq } from "drizzle-orm";
import { db, pool } from "./index";
import { menuItems } from "./schema";
import { menu } from "../lib/menu-data";
import { ensureAdminUser } from "../lib/auth";

async function seedMenu() {
  let inserted = 0;
  let updated = 0;
  for (const item of menu) {
    const values = {
      slug: item.slug,
      name: item.name,
      category: item.category,
      region: item.region,
      description: item.description,
      diet: item.diet,
      spice: item.spice,
      priceMinor: Math.round(item.price * 100),
      signature: Boolean(item.signature),
      source: item.source,
      available: true,
    };
    const existing = await db.select({ id: menuItems.id }).from(menuItems).where(eq(menuItems.slug, item.slug)).limit(1);
    if (existing.length > 0) {
      await db.update(menuItems).set(values).where(eq(menuItems.id, existing[0].id));
      updated += 1;
    } else {
      await db.insert(menuItems).values(values);
      inserted += 1;
    }
  }
  console.log(`menu: ${inserted} inserted, ${updated} updated (${menu.length} total)`);
}

async function main() {
  await seedMenu();
  await ensureAdminUser();
  const adminEmail = process.env.ADMIN_EMAIL;
  console.log(`admin: ${adminEmail ? `ready for ${adminEmail}` : "set ADMIN_EMAIL + ADMIN_PASSWORD in .env to create"}`);
  await pool.end();
}

main().catch(async (error) => {
  console.error(error);
  await pool.end();
  process.exit(1);
});
