import {
  boolean,
  index,
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/pg-core";

/* ----------------------------- Auth ----------------------------- */

export const users = pgTable(
  "users",
  {
    id: serial("id").primaryKey(),
    email: varchar("email", { length: 320 }).notNull(),
    fullName: varchar("full_name", { length: 160 }).notNull(),
    phone: varchar("phone", { length: 32 }),
    passwordHash: text("password_hash").notNull(),
    role: varchar("role", { length: 24 }).notNull().default("guest"),
    marketingOptIn: boolean("marketing_opt_in").notNull().default(false),
    dietaryPreference: varchar("dietary_preference", { length: 32 }),
    notes: text("notes"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [uniqueIndex("users_email_unique").on(table.email)],
);

export const sessions = pgTable(
  "sessions",
  {
    id: varchar("id", { length: 64 }).primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    userAgent: varchar("user_agent", { length: 256 }),
  },
  (table) => [index("sessions_user_idx").on(table.userId)],
);

export const passwordResetTokens = pgTable(
  "password_reset_tokens",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    tokenHash: varchar("token_hash", { length: 128 }).notNull(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    usedAt: timestamp("used_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    uniqueIndex("password_reset_token_unique").on(table.tokenHash),
    index("password_reset_user_idx").on(table.userId),
  ],
);

/* ---------------------------- Menu ------------------------------ */

export const menuItems = pgTable(
  "menu_items",
  {
    id: serial("id").primaryKey(),
    slug: varchar("slug", { length: 120 }).notNull(),
    name: varchar("name", { length: 180 }).notNull(),
    category: varchar("category", { length: 60 }).notNull(),
    region: varchar("region", { length: 120 }).notNull(),
    description: text("description").notNull(),
    diet: varchar("diet", { length: 16 }).notNull(),
    spice: integer("spice").notNull().default(0),
    /** Indicative price in paise to avoid float issues. */
    priceMinor: integer("price_minor").notNull(),
    signature: boolean("signature").notNull().default(false),
    source: text("source").notNull(),
    available: boolean("available").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [uniqueIndex("menu_items_slug_unique").on(table.slug)],
);

/* ------------------------ Reservations -------------------------- */

export const reservationRequests = pgTable(
  "reservation_requests",
  {
    id: serial("id").primaryKey(),
    reference: varchar("reference", { length: 24 }).notNull(),
    userId: integer("user_id").references(() => users.id, { onDelete: "set null" }),
    fullName: varchar("full_name", { length: 160 }).notNull(),
    email: varchar("email", { length: 320 }).notNull(),
    phone: varchar("phone", { length: 32 }).notNull(),
    date: varchar("date", { length: 10 }).notNull(),
    time: varchar("time", { length: 5 }).notNull(),
    guests: integer("guests").notNull(),
    occasion: varchar("occasion", { length: 60 }),
    seating: varchar("seating", { length: 40 }),
    message: text("message"),
    /** enquiry = this website's form. google = guest clicked the official Google page. */
    channel: varchar("channel", { length: 24 }).notNull().default("website-enquiry"),
    status: varchar("status", { length: 24 }).notNull().default("new"),
    preOrder: jsonb("pre_order").$type<{ slug: string; name: string; qty: number }[]>(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    uniqueIndex("reservation_reference_unique").on(table.reference),
    index("reservation_created_idx").on(table.createdAt),
  ],
);

/* -------------------------- Pre-orders -------------------------- */

export const preOrders = pgTable(
  "pre_orders",
  {
    id: serial("id").primaryKey(),
    reference: varchar("reference", { length: 24 }).notNull(),
    userId: integer("user_id").references(() => users.id, { onDelete: "set null" }),
    fullName: varchar("full_name", { length: 160 }).notNull(),
    email: varchar("email", { length: 320 }).notNull(),
    phone: varchar("phone", { length: 32 }).notNull(),
    serviceType: varchar("service_type", { length: 32 }).notNull().default("dine-in-preorder"),
    preferredDate: varchar("preferred_date", { length: 10 }),
    preferredTime: varchar("preferred_time", { length: 5 }),
    guests: integer("guests"),
    items: jsonb("items")
      .$type<{ slug: string; name: string; qty: number; priceMinor: number; indicative: boolean }[]>()
      .notNull(),
    /** Indicative total in paise. NOT a payment amount. */
    indicativeTotalMinor: integer("indicative_total_minor").notNull().default(0),
    notes: text("notes"),
    status: varchar("status", { length: 24 }).notNull().default("received"),
    /** payment_provider | null — no gateway is configured in this project. */
    paymentStatus: varchar("payment_status", { length: 32 }).notNull().default("not-applicable"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    uniqueIndex("pre_orders_reference_unique").on(table.reference),
    index("pre_orders_created_idx").on(table.createdAt),
  ],
);

/* ------------------------ Contact & news ------------------------ */

export const contactMessages = pgTable(
  "contact_messages",
  {
    id: serial("id").primaryKey(),
    reference: varchar("reference", { length: 24 }).notNull(),
    userId: integer("user_id").references(() => users.id, { onDelete: "set null" }),
    fullName: varchar("full_name", { length: 160 }).notNull(),
    email: varchar("email", { length: 320 }).notNull(),
    phone: varchar("phone", { length: 32 }),
    topic: varchar("topic", { length: 48 }).notNull(),
    message: text("message").notNull(),
    status: varchar("status", { length: 24 }).notNull().default("new"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    uniqueIndex("contact_reference_unique").on(table.reference),
    index("contact_created_idx").on(table.createdAt),
  ],
);

export const eventEnquiries = pgTable(
  "event_enquiries",
  {
    id: serial("id").primaryKey(),
    reference: varchar("reference", { length: 24 }).notNull(),
    userId: integer("user_id").references(() => users.id, { onDelete: "set null" }),
    fullName: varchar("full_name", { length: 160 }).notNull(),
    email: varchar("email", { length: 320 }).notNull(),
    phone: varchar("phone", { length: 32 }).notNull(),
    eventType: varchar("event_type", { length: 60 }).notNull(),
    preferredDate: varchar("preferred_date", { length: 10 }),
    guests: integer("guests").notNull(),
    budget: varchar("budget", { length: 48 }),
    message: text("message"),
    status: varchar("status", { length: 24 }).notNull().default("new"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [uniqueIndex("event_reference_unique").on(table.reference)],
);

export const newsletterSubscribers = pgTable(
  "newsletter_subscribers",
  {
    id: serial("id").primaryKey(),
    email: varchar("email", { length: 320 }).notNull(),
    source: varchar("source", { length: 48 }).notNull().default("footer"),
    confirmed: boolean("confirmed").notNull().default(false),
    unsubscribedAt: timestamp("unsubscribed_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [uniqueIndex("newsletter_email_unique").on(table.email)],
);

export type User = typeof users.$inferSelect;
export type MenuItemRow = typeof menuItems.$inferSelect;
export type ReservationRow = typeof reservationRequests.$inferSelect;
export type PreOrderRow = typeof preOrders.$inferSelect;
export type ContactRow = typeof contactMessages.$inferSelect;
export type EventRow = typeof eventEnquiries.$inferSelect;
